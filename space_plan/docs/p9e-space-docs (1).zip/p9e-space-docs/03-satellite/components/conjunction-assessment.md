# Conjunction Assessment

## State Machine
```
SCREENING → DISMISSED (Pc < 1e-7)
          → MONITORING (Pc >= 1e-7)
             → ELEVATED (Pc >= 1e-4)
                → MITIGATING (Pc >= 1e-3 AND TCA < 72h)
                   → MANEUVER_PLANNED
                   → ACCEPTED_RISK
                   → RESOLVED
```

## Thresholds
| Status | Probability (Pc) | Action |
|--------|------------------|--------|
| Dismiss | < 1e-7 | No action |
| Monitor | >= 1e-7 | Track updates |
| Elevated | >= 1e-4 | Prepare options |
| Mitigate | >= 1e-3 AND TCA < 72h | Execute CAM |
