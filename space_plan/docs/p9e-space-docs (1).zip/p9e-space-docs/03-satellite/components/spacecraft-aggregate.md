# Spacecraft Aggregate

## Structure
```
SpacecraftAggregate
├── Spacecraft (root)
│   ├── ID, Name, NoradID
│   ├── BusType, DryMassKg, DesignLifeYears
│   └── Status
└── Subsystems[]
    ├── ADCS (Attitude Determination & Control)
    ├── EPS (Electrical Power System)
    ├── CDH (Command & Data Handling)
    ├── COMMS (Communications)
    ├── THERMAL (Thermal Control)
    └── PAYLOAD (Mission Payload)
```

## Subsystem Status
- NOMINAL: Operating within limits
- DEGRADED: Reduced capability
- FAILED: Non-operational
- UNKNOWN: No recent data
