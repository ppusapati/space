# Satellite Module

> Spacecraft Management, Flight Dynamics & Conjunction Assessment

## Services

| Service | RPCs | Description |
|---------|------|-------------|
| [SpacecraftService](./api/spacecraft-service.md) | 8 | Spacecraft configuration |
| [FlightDynamicsService](./api/flightdynamics-service.md) | 10 | Orbits, maneuvers |
| **Total** | **18** | |

## Key Concepts

### Spacecraft Aggregate
```
SpacecraftAggregate
├── Spacecraft (root)
│   ├── BusType, Mass, Dimensions
│   └── Status (COMMISSIONING, OPERATIONAL, DEGRADED)
└── Subsystems[]
    ├── ADCS, EPS, CDH, COMMS, THERMAL, PAYLOAD
```

### Conjunction Assessment States
```
INITIAL_SCREENING → DISMISSED (Pc < 1e-7)
                  → MONITORING (Pc >= 1e-7)
                     → ELEVATED (Pc >= 1e-4)
                        → MITIGATING (TCA < 72h AND Pc >= 1e-3)
                           → MANEUVER_PLANNED / ACCEPTED_RISK / RESOLVED
```

## Data Model
| Table | Description |
|-------|-------------|
| spacecraft | Configuration |
| subsystems | Subsystem definitions |
| orbit_states | Position/velocity |
| maneuvers | Planned/executed |
| conjunctions | Collision assessments |
