# Satellite Module - Data Model

## Tables

### spacecraft
```sql
CREATE TABLE satellite.spacecraft (
    id UUID PRIMARY KEY,
    tenant_id UUID NOT NULL,
    norad_id INTEGER NOT NULL,
    name VARCHAR(255) NOT NULL,
    bus_type VARCHAR(100),
    dry_mass_kg DECIMAL(10,2),
    design_life_years INTEGER,
    status spacecraft_status NOT NULL DEFAULT 'commissioning'
);
```

### subsystems
```sql
CREATE TABLE satellite.subsystems (
    id UUID PRIMARY KEY,
    spacecraft_id UUID NOT NULL REFERENCES satellite.spacecraft(id),
    type subsystem_type NOT NULL,
    name VARCHAR(100) NOT NULL,
    status subsystem_status NOT NULL DEFAULT 'nominal',
    parameters JSONB NOT NULL DEFAULT '{}'
);
```

### orbit_states
```sql
CREATE TABLE satellite.orbit_states (
    id UUID PRIMARY KEY,
    spacecraft_id UUID NOT NULL,
    epoch TIMESTAMPTZ NOT NULL,
    position_x_km DOUBLE PRECISION NOT NULL,
    position_y_km DOUBLE PRECISION NOT NULL,
    position_z_km DOUBLE PRECISION NOT NULL,
    velocity_x_km_s DOUBLE PRECISION NOT NULL,
    velocity_y_km_s DOUBLE PRECISION NOT NULL,
    velocity_z_km_s DOUBLE PRECISION NOT NULL,
    covariance DOUBLE PRECISION[36],
    source VARCHAR(50) NOT NULL
);
```

### conjunctions
```sql
CREATE TABLE satellite.conjunctions (
    id UUID PRIMARY KEY,
    spacecraft_id UUID NOT NULL,
    secondary_object VARCHAR(100) NOT NULL,
    tca TIMESTAMPTZ NOT NULL,
    miss_distance_m DOUBLE PRECISION NOT NULL,
    collision_probability DOUBLE PRECISION NOT NULL,
    status conjunction_status NOT NULL DEFAULT 'screening'
);
```
