# Flight Dynamics Service API
> Package: `satellite.v1`

```protobuf
service FlightDynamicsService {
  rpc GetCurrentState(GetCurrentStateRequest) returns (OrbitState);
  rpc PropagateOrbit(PropagateOrbitRequest) returns (PropagateOrbitResponse);
  rpc GetStateHistory(GetStateHistoryRequest) returns (StateHistoryResponse);
  rpc CreateManeuver(CreateManeuverRequest) returns (Maneuver);
  rpc ListManeuvers(ListManeuversRequest) returns (ListManeuversResponse);
  rpc ExecuteManeuver(ExecuteManeuverRequest) returns (Maneuver);
  rpc ListConjunctions(ListConjunctionsRequest) returns (ListConjunctionsResponse);
  rpc GetConjunction(GetConjunctionRequest) returns (Conjunction);
  rpc AssessConjunction(AssessConjunctionRequest) returns (ConjunctionAssessment);
  rpc PlanCollisionAvoidance(PlanCollisionAvoidanceRequest) returns (Maneuver);
}
```

## Messages
```protobuf
message Conjunction {
  string id = 1;
  string spacecraft_id = 2;
  string secondary_object = 3;
  google.protobuf.Timestamp tca = 4;
  double miss_distance_m = 5;
  double collision_probability = 6;
  ConjunctionStatus status = 7;
}
```
