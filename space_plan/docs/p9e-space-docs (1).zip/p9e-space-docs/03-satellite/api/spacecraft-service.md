# Spacecraft Service API
> Package: `satellite.v1`

```protobuf
service SpacecraftService {
  rpc CreateSpacecraft(CreateSpacecraftRequest) returns (Spacecraft);
  rpc GetSpacecraft(GetSpacecraftRequest) returns (Spacecraft);
  rpc UpdateSpacecraft(UpdateSpacecraftRequest) returns (Spacecraft);
  rpc ListSpacecraft(ListSpacecraftRequest) returns (ListSpacecraftResponse);
  rpc GetSubsystemStatus(GetSubsystemStatusRequest) returns (SubsystemStatus);
  rpc UpdateSubsystemStatus(UpdateSubsystemStatusRequest) returns (SubsystemStatus);
  rpc GetHealthSummary(GetHealthSummaryRequest) returns (HealthSummary);
  rpc ListSubsystems(ListSubsystemsRequest) returns (ListSubsystemsResponse);
}
```
