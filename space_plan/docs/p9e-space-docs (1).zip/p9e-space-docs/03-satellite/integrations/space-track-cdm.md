# Space-Track CDM Integration

## Overview
Conjunction Data Messages from 18th Space Defense Squadron.

## CDM Fields
- Message ID, Creation Date
- Originator (primary/secondary)
- TCA (Time of Closest Approach)
- Miss Distance
- Collision Probability
- State Vectors & Covariance

## Processing
```go
func (s *CDMProcessor) ProcessCDM(cdm CDM) error {
    // Find or create conjunction
    conj, _ := s.repo.FindByTCA(cdm.PrimaryNoradID, cdm.TCA)
    
    // Update with latest data
    conj.MissDistance = cdm.MissDistance
    conj.CollisionProbability = cdm.Pc
    
    // Evaluate status transition
    newStatus := s.evaluateStatus(conj)
    if newStatus != conj.Status {
        s.eventPublisher.Publish(ConjunctionStatusChanged{...})
    }
    
    return s.repo.Save(conj)
}
```
