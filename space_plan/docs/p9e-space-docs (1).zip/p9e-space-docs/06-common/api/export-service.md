# Export Service API
> Package: `common.v1`

```protobuf
service ExportService {
  rpc CreateExport(CreateExportRequest) returns (Export);
  rpc GetExport(GetExportRequest) returns (Export);
  rpc ListExports(ListExportsRequest) returns (ListExportsResponse);
  rpc CancelExport(CancelExportRequest) returns (Export);
  rpc GetDownloadURL(GetDownloadURLRequest) returns (DownloadURL);
}
```

## Messages
```protobuf
message Export {
  string id = 1;
  ExportType type = 2;
  ExportFormat format = 3;
  ExportStatus status = 4;
  string query = 5;
  int64 total_records = 6;
  int64 processed_records = 7;
  string download_url = 8;
  google.protobuf.Timestamp expires_at = 9;
}

enum ExportFormat {
  EXPORT_FORMAT_CSV = 1;
  EXPORT_FORMAT_JSON = 2;
  EXPORT_FORMAT_PARQUET = 3;
  EXPORT_FORMAT_GEOJSON = 4;
}
```

## Flow
1. CreateExport → returns Export with status=PENDING
2. Background worker processes query in batches
3. Writes to S3 with streaming
4. Updates status=COMPLETED
5. GetDownloadURL returns presigned URL
