# Scheduler Service API
> Package: `common.v1`

```protobuf
service SchedulerService {
  rpc CreateSchedule(CreateScheduleRequest) returns (Schedule);
  rpc GetSchedule(GetScheduleRequest) returns (Schedule);
  rpc UpdateSchedule(UpdateScheduleRequest) returns (Schedule);
  rpc DeleteSchedule(DeleteScheduleRequest) returns (google.protobuf.Empty);
  rpc ListSchedules(ListSchedulesRequest) returns (ListSchedulesResponse);
  rpc PauseSchedule(PauseScheduleRequest) returns (Schedule);
  rpc ResumeSchedule(ResumeScheduleRequest) returns (Schedule);
  rpc TriggerNow(TriggerNowRequest) returns (ScheduleRun);
  rpc ListRuns(ListRunsRequest) returns (ListRunsResponse);
}
```

## Messages
```protobuf
message Schedule {
  string id = 1;
  string name = 2;
  string cron_expression = 3;
  string job_type = 4;
  google.protobuf.Struct job_params = 5;
  ScheduleStatus status = 6;
  google.protobuf.Timestamp next_run = 7;
  google.protobuf.Timestamp last_run = 8;
}
```

## Built-in Jobs
| Job | Default Schedule | Description |
|-----|-----------------|-------------|
| tle_refresh | 0 */6 * * * | Refresh TLEs |
| pass_prediction | 0 0 * * * | Predict passes |
| telemetry_rollup | */15 * * * * | Aggregate telemetry |
| export_cleanup | 0 3 * * * | Delete expired exports |
