# Dashboard Service API
> Package: `common.v1`

```protobuf
service DashboardService {
  rpc CreateDashboard(CreateDashboardRequest) returns (Dashboard);
  rpc GetDashboard(GetDashboardRequest) returns (Dashboard);
  rpc UpdateDashboard(UpdateDashboardRequest) returns (Dashboard);
  rpc DeleteDashboard(DeleteDashboardRequest) returns (google.protobuf.Empty);
  rpc ListDashboards(ListDashboardsRequest) returns (ListDashboardsResponse);
  rpc AddWidget(AddWidgetRequest) returns (Widget);
  rpc RemoveWidget(RemoveWidgetRequest) returns (google.protobuf.Empty);
}
```

## Messages
```protobuf
message Dashboard {
  string id = 1;
  string name = 2;
  DashboardLayout layout = 3;
  repeated Widget widgets = 4;
  bool is_default = 5;
}

message Widget {
  string id = 1;
  WidgetType type = 2;
  string title = 3;
  string query = 4;
  WidgetPosition position = 5;
  google.protobuf.Struct config = 6;
}
```

## Widget Types
- METRIC: Single value
- TIMESERIES: Line/area chart
- TABLE: Data table
- MAP: Geographic view
- GAUGE: Progress indicator
