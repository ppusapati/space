# Health Service API
> Package: `common.v1`

```protobuf
service HealthService {
  rpc Check(HealthCheckRequest) returns (HealthCheckResponse);
  rpc Watch(HealthCheckRequest) returns (stream HealthCheckResponse);
  rpc GetServiceInfo(google.protobuf.Empty) returns (ServiceInfo);
  rpc ListDependencies(google.protobuf.Empty) returns (ListDependenciesResponse);
}
```

## Messages
```protobuf
message HealthCheckResponse {
  ServingStatus status = 1;
  map<string, DependencyHealth> dependencies = 2;
  string version = 3;
  int64 uptime_seconds = 4;
}

message DependencyHealth {
  ServingStatus status = 1;
  int64 latency_ms = 2;
  string message = 3;
}

enum ServingStatus {
  UNKNOWN = 0;
  SERVING = 1;
  NOT_SERVING = 2;
}
```

## Endpoints
| Endpoint | Purpose | Response |
|----------|---------|----------|
| /healthz | Liveness | 200 OK |
| /readyz | Readiness | 200 OK if deps ready |
| /v1/health | Detailed | JSON with deps |
