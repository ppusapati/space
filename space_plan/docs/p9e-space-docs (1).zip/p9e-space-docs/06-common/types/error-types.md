# Error Types

## Error Detail

```protobuf
message ErrorDetail {
  string code = 1;
  string message = 2;
  string field = 3;
  map<string, string> metadata = 4;
}
```

## Validation Error

```protobuf
message ValidationError {
  repeated FieldError field_errors = 1;
}

message FieldError {
  string field = 1;
  string code = 2;
  string message = 3;
  string constraint = 4;
}
```

## Standard Error Codes

| Code | HTTP | gRPC | Description |
|------|------|------|-------------|
| NOT_FOUND | 404 | NOT_FOUND | Resource not found |
| ALREADY_EXISTS | 409 | ALREADY_EXISTS | Resource exists |
| INVALID_ARGUMENT | 400 | INVALID_ARGUMENT | Invalid input |
| PERMISSION_DENIED | 403 | PERMISSION_DENIED | No permission |
| UNAUTHENTICATED | 401 | UNAUTHENTICATED | Not authenticated |
| RESOURCE_EXHAUSTED | 429 | RESOURCE_EXHAUSTED | Rate limited |
| INTERNAL | 500 | INTERNAL | Server error |

## Go Implementation

```go
type Error interface {
    error
    Code() string
    Message() string
    HTTPStatus() int
    GRPCCode() codes.Code
    WithDetails(map[string]string) Error
}

var (
    ErrNotFound = NewError("NOT_FOUND", "Resource not found", 404, codes.NotFound)
    ErrAlreadyExists = NewError("ALREADY_EXISTS", "Resource already exists", 409, codes.AlreadyExists)
    ErrInvalidArgument = NewError("INVALID_ARGUMENT", "Invalid argument", 400, codes.InvalidArgument)
    ErrPermissionDenied = NewError("PERMISSION_DENIED", "Permission denied", 403, codes.PermissionDenied)
    ErrUnauthenticated = NewError("UNAUTHENTICATED", "Not authenticated", 401, codes.Unauthenticated)
)
```
