# Common Types

## Identifiers

```protobuf
message UUID {
  string value = 1 [(validate.rules).string.uuid = true];
}
```

## Pagination

```protobuf
message PageRequest {
  int32 page_size = 1 [(validate.rules).int32 = {gte: 1, lte: 100}];
  string page_token = 2;
}

message PageInfo {
  string next_page_token = 1;
  int32 total_count = 2;
  bool has_more = 3;
}
```

## Time

```protobuf
message TimeRange {
  google.protobuf.Timestamp start = 1;
  google.protobuf.Timestamp end = 2;
}

message DateRange {
  google.type.Date start = 1;
  google.type.Date end = 2;
}
```

## Geometry

```protobuf
message BoundingBox {
  double min_lon = 1 [(validate.rules).double = {gte: -180, lte: 180}];
  double min_lat = 2 [(validate.rules).double = {gte: -90, lte: 90}];
  double max_lon = 3 [(validate.rules).double = {gte: -180, lte: 180}];
  double max_lat = 4 [(validate.rules).double = {gte: -90, lte: 90}];
}

message Point {
  double longitude = 1;
  double latitude = 2;
  double altitude = 3;
}

message GeoJSON {
  string type = 1;
  bytes coordinates = 2;
}
```

## Sorting

```protobuf
message SortOrder {
  string field = 1;
  Direction direction = 2;
  
  enum Direction {
    DIRECTION_UNSPECIFIED = 0;
    DIRECTION_ASC = 1;
    DIRECTION_DESC = 2;
  }
}
```
