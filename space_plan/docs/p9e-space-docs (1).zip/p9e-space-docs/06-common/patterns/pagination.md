# Pagination Pattern

## Cursor-Based Pagination

```go
func (r *Repository) List(ctx context.Context, pageSize int, cursor string) ([]Item, string, error) {
    var lastID uuid.UUID
    if cursor != "" {
        lastID, _ = decodeCursor(cursor)
    }
    
    query := `SELECT * FROM items WHERE id > $1 ORDER BY id LIMIT $2`
    rows, _ := r.db.Query(ctx, query, lastID, pageSize+1)
    
    items := make([]Item, 0, pageSize)
    for rows.Next() {
        var item Item
        rows.Scan(&item)
        items = append(items, item)
    }
    
    var nextCursor string
    if len(items) > pageSize {
        items = items[:pageSize]
        nextCursor = encodeCursor(items[len(items)-1].ID)
    }
    
    return items, nextCursor, nil
}
```

## Cursor Encoding

```go
func encodeCursor(id uuid.UUID) string {
    return base64.URLEncoding.EncodeToString(id[:])
}

func decodeCursor(cursor string) (uuid.UUID, error) {
    data, err := base64.URLEncoding.DecodeString(cursor)
    if err != nil {
        return uuid.Nil, err
    }
    return uuid.FromBytes(data)
}
```

## gRPC Handler

```go
func (h *Handler) ListItems(ctx context.Context, req *connect.Request[ListItemsRequest]) (*connect.Response[ListItemsResponse], error) {
    items, nextCursor, err := h.service.List(ctx, int(req.Msg.PageSize), req.Msg.PageToken)
    if err != nil {
        return nil, err
    }
    
    return connect.NewResponse(&ListItemsResponse{
        Items: toProto(items),
        PageInfo: &PageInfo{
            NextPageToken: nextCursor,
            HasMore:       nextCursor != "",
        },
    }), nil
}
```
