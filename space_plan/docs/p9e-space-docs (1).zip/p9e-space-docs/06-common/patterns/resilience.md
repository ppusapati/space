# Resilience Pattern

## Circuit Breaker

```go
type CircuitBreaker struct {
    maxFailures int           // 5
    timeout     time.Duration // 30s
    halfOpenMax int           // 3
    
    state       State
    failures    int
    lastFailure time.Time
    mu          sync.RWMutex
}

func (cb *CircuitBreaker) Execute(fn func() error) error {
    if !cb.canExecute() {
        return ErrCircuitOpen
    }
    
    err := fn()
    cb.recordResult(err)
    return err
}
```

## Retry with Exponential Backoff

```go
type RetryConfig struct {
    MaxAttempts    int           // 3
    InitialBackoff time.Duration // 100ms
    MaxBackoff     time.Duration // 10s
    BackoffFactor  float64       // 2.0
    Jitter         float64       // 0.3
}

func Retry(ctx context.Context, cfg RetryConfig, fn func() error) error {
    backoff := cfg.InitialBackoff
    
    for attempt := 1; attempt <= cfg.MaxAttempts; attempt++ {
        err := fn()
        if err == nil {
            return nil
        }
        
        if !isRetryable(err) || attempt == cfg.MaxAttempts {
            return err
        }
        
        jitter := time.Duration(float64(backoff) * cfg.Jitter * (rand.Float64()*2 - 1))
        sleep := backoff + jitter
        
        select {
        case <-ctx.Done():
            return ctx.Err()
        case <-time.After(sleep):
        }
        
        backoff = time.Duration(float64(backoff) * cfg.BackoffFactor)
        if backoff > cfg.MaxBackoff {
            backoff = cfg.MaxBackoff
        }
    }
    return nil
}
```

## Timeout

```go
func WithTimeout(ctx context.Context, timeout time.Duration, fn func(context.Context) error) error {
    ctx, cancel := context.WithTimeout(ctx, timeout)
    defer cancel()
    
    done := make(chan error, 1)
    go func() {
        done <- fn(ctx)
    }()
    
    select {
    case err := <-done:
        return err
    case <-ctx.Done():
        return ctx.Err()
    }
}
```

## Bulkhead

```go
type Bulkhead struct {
    sem chan struct{}
}

func NewBulkhead(maxConcurrent int) *Bulkhead {
    return &Bulkhead{sem: make(chan struct{}, maxConcurrent)}
}

func (b *Bulkhead) Execute(ctx context.Context, fn func() error) error {
    select {
    case b.sem <- struct{}{}:
        defer func() { <-b.sem }()
        return fn()
    case <-ctx.Done():
        return ctx.Err()
    }
}
```
