# Streaming Pattern

## gRPC Server Streaming

```go
func (h *Handler) StreamTelemetry(ctx context.Context, req *connect.Request[StreamTelemetryRequest], stream *connect.ServerStream[TelemetryFrame]) error {
    sub, err := h.nats.Subscribe(fmt.Sprintf("telemetry.%s", req.Msg.SatelliteId))
    if err != nil {
        return err
    }
    defer sub.Unsubscribe()
    
    for {
        select {
        case <-ctx.Done():
            return nil
        case msg := <-sub.Channel():
            var frame TelemetryFrame
            proto.Unmarshal(msg.Data, &frame)
            if err := stream.Send(&frame); err != nil {
                return err
            }
        }
    }
}
```

## WebSocket (Gorilla)

```go
func (h *Handler) HandleWebSocket(w http.ResponseWriter, r *http.Request) {
    conn, err := h.upgrader.Upgrade(w, r, nil)
    if err != nil {
        return
    }
    defer conn.Close()
    
    satelliteID := r.URL.Query().Get("satellite_id")
    sub, _ := h.nats.Subscribe(fmt.Sprintf("telemetry.%s", satelliteID))
    defer sub.Unsubscribe()
    
    for msg := range sub.Channel() {
        if err := conn.WriteMessage(websocket.TextMessage, msg.Data); err != nil {
            return
        }
    }
}
```

## Server-Sent Events

```go
func (h *Handler) HandleSSE(w http.ResponseWriter, r *http.Request) {
    w.Header().Set("Content-Type", "text/event-stream")
    w.Header().Set("Cache-Control", "no-cache")
    w.Header().Set("Connection", "keep-alive")
    
    flusher, _ := w.(http.Flusher)
    
    sub, _ := h.nats.Subscribe("alerts.*")
    defer sub.Unsubscribe()
    
    for {
        select {
        case <-r.Context().Done():
            return
        case msg := <-sub.Channel():
            fmt.Fprintf(w, "data: %s\n\n", msg.Data)
            flusher.Flush()
        }
    }
}
```
