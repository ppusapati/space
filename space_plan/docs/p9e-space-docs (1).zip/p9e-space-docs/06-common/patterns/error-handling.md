# Error Handling Pattern

## Overview

Consistent error handling across all services.

## Domain Errors

```go
type DomainError struct {
    code       string
    message    string
    httpStatus int
    grpcCode   codes.Code
    details    map[string]string
}

func (e *DomainError) Error() string { return e.message }
func (e *DomainError) Code() string { return e.code }
func (e *DomainError) HTTPStatus() int { return e.httpStatus }
func (e *DomainError) GRPCCode() codes.Code { return e.grpcCode }

func (e *DomainError) WithDetails(d map[string]string) *DomainError {
    e.details = d
    return e
}
```

## Error Wrapping

```go
func (s *UserService) GetUser(ctx context.Context, id string) (*User, error) {
    user, err := s.repo.FindByID(ctx, id)
    if err != nil {
        if errors.Is(err, sql.ErrNoRows) {
            return nil, ErrNotFound.WithDetails(map[string]string{
                "resource": "User",
                "id": id,
            })
        }
        return nil, fmt.Errorf("get user: %w", err)
    }
    return user, nil
}
```

## ConnectRPC Interceptor

```go
func ErrorInterceptor() connect.UnaryInterceptorFunc {
    return func(next connect.UnaryFunc) connect.UnaryFunc {
        return func(ctx context.Context, req connect.AnyRequest) (connect.AnyResponse, error) {
            resp, err := next(ctx, req)
            if err != nil {
                var domainErr *DomainError
                if errors.As(err, &domainErr) {
                    return nil, connect.NewError(domainErr.GRPCCode(), err)
                }
                return nil, connect.NewError(codes.Internal, err)
            }
            return resp, nil
        }
    }
}
```
