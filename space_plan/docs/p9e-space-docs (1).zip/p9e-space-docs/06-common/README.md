# Common Module

> Shared Services, Types & Patterns

## Services

| Service | RPCs | Description |
|---------|------|-------------|
| [ExportService](./api/export-service.md) | 5 | Async data export |
| [DashboardService](./api/dashboard-service.md) | 7 | Custom dashboards |
| [SchedulerService](./api/scheduler-service.md) | 9 | Cron jobs |
| [HealthService](./api/health-service.md) | 4 | Service health |
| **Total** | **25** | |

## Common Types

### Pagination
```protobuf
message PageRequest {
  int32 page_size = 1;
  string page_token = 2;
}

message PageInfo {
  string next_page_token = 1;
  int32 total_count = 2;
  bool has_more = 3;
}
```

### Geometry
```protobuf
message BoundingBox {
  double min_lon = 1;
  double min_lat = 2;
  double max_lon = 3;
  double max_lat = 4;
}

message Point {
  double longitude = 1;
  double latitude = 2;
}
```

### Time
```protobuf
message TimeRange {
  google.protobuf.Timestamp start = 1;
  google.protobuf.Timestamp end = 2;
}
```

## Patterns
- [Error Handling](./patterns/error-handling.md)
- [Resilience](./patterns/resilience.md)
- [Pagination](./patterns/pagination.md)
- [Streaming](./patterns/streaming.md)

## Types
- [Common Types](./types/common-types.md)
- [Error Types](./types/error-types.md)
