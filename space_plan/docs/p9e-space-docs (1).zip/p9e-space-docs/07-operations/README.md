# Operations

> Deployment, Monitoring & Operational Procedures

## Contents

| Document | Description |
|----------|-------------|
| [Deployment](./deployment.md) | Kubernetes deployment |
| [Monitoring](./monitoring.md) | Observability setup |
| [Configuration](./configuration.md) | Environment config |
| [Troubleshooting](./troubleshooting.md) | Common issues |

## Runbooks

| Runbook | Scenario |
|---------|----------|
| [Incident Response](./runbooks/incident-response.md) | Production incidents |
| [Disaster Recovery](./runbooks/disaster-recovery.md) | DR procedures |
| [Scaling](./runbooks/scaling.md) | Horizontal/vertical scaling |

## Quick Reference

### Health Endpoints

| Endpoint | Purpose |
|----------|---------|
| /healthz | Liveness probe |
| /readyz | Readiness probe |
| /v1/health | Detailed health |
| /metrics | Prometheus metrics |

### Key Metrics

```prometheus
up{job="*"}
rate(http_requests_total[5m])
histogram_quantile(0.95, http_request_duration_seconds)
rate(p9e_telemetry_frames_total[5m])
```

### Alert Severity

| Severity | Response | Channels |
|----------|----------|----------|
| Critical | < 15 min | PagerDuty, Slack |
| Warning | < 1 hour | Slack |
| Info | Daily | Email |
