# Disaster Recovery Runbook

## Overview

This runbook covers disaster recovery procedures for the P9E Space Platform.

## Recovery Objectives

| Metric | Target | Description |
|--------|--------|-------------|
| **RPO** | 1 hour | Maximum data loss |
| **RTO** | 4 hours | Maximum downtime |

## Backup Strategy

### Database (PostgreSQL)

| Type | Frequency | Retention | Location |
|------|-----------|-----------|----------|
| WAL Streaming | Continuous | 30 days | S3 (DR region) |
| Full Backup | Daily | 30 days | S3 (DR region) |
| Snapshot | Weekly | 90 days | S3 Glacier |

### TimescaleDB

| Type | Frequency | Retention |
|------|-----------|-----------|
| Incremental | Daily | 30 days |
| Full | Weekly | 90 days |

### Object Storage (S3)

- Cross-region replication enabled
- Versioning enabled
- Lifecycle policies for archival

## Disaster Scenarios

### Scenario 1: Single Zone Failure

**Impact:** Pods in failed zone unavailable

**Recovery:**
1. Kubernetes automatically reschedules pods
2. Monitor pod status: `kubectl get pods -o wide`
3. Verify service endpoints healthy
4. No data loss expected

**RTO:** < 5 minutes (automatic)

### Scenario 2: Database Failure

**Impact:** All writes fail, potential data loss

**Recovery Procedure:**

```bash
# 1. Verify database status
kubectl exec -it postgres-0 -- pg_isready

# 2. Check replication lag
kubectl exec -it postgres-0 -- psql -c "SELECT * FROM pg_stat_replication"

# 3. If primary failed, promote replica
kubectl exec -it postgres-1 -- pg_ctl promote

# 4. Update connection strings (if not using Patroni)
kubectl patch configmap postgres-config -p '{"data":{"POSTGRES_HOST":"postgres-1"}}'

# 5. Restart dependent services
kubectl rollout restart deployment/platform
kubectl rollout restart deployment/groundstation
```

**RTO:** < 30 minutes

### Scenario 3: Region Failure

**Impact:** Complete regional outage

**Recovery Procedure:**

```bash
# 1. Verify DR site health
kubectl --context=dr-cluster get nodes

# 2. Restore database from latest backup
./scripts/restore-database.sh --backup-id=latest --target=dr

# 3. Update DNS to point to DR site
aws route53 change-resource-record-sets --hosted-zone-id Z123 \
  --change-batch file://dns-failover.json

# 4. Verify application health
curl https://dr.p9e.space/healthz

# 5. Notify users
./scripts/send-notification.sh --template=dr-failover
```

**RTO:** < 4 hours

### Scenario 4: Data Corruption

**Impact:** Application data corrupted

**Recovery Procedure:**

```bash
# 1. Stop writes immediately
kubectl scale deployment --all --replicas=0 -n p9e-space

# 2. Identify corruption extent
./scripts/data-audit.sh --since="2025-01-01T00:00:00Z"

# 3. Point-in-Time Recovery
./scripts/pitr-restore.sh --target-time="2025-01-01T12:00:00Z"

# 4. Validate data integrity
./scripts/validate-data.sh

# 5. Resume operations
kubectl scale deployment --all --replicas=3 -n p9e-space
```

**RTO:** 2-4 hours depending on corruption extent

## Recovery Procedures

### Database Point-in-Time Recovery

```bash
#!/bin/bash
# pitr-restore.sh

TARGET_TIME=$1
BACKUP_BUCKET="s3://p9e-backups/postgres"

# 1. Find nearest base backup
BASE_BACKUP=$(aws s3 ls $BACKUP_BUCKET/base/ | sort | tail -1 | awk '{print $4}')

# 2. Download base backup
aws s3 cp $BACKUP_BUCKET/base/$BASE_BACKUP /tmp/restore/

# 3. Configure recovery
cat > /tmp/restore/recovery.conf << EOF
restore_command = 'aws s3 cp s3://p9e-backups/postgres/wal/%f %p'
recovery_target_time = '$TARGET_TIME'
recovery_target_action = 'promote'
EOF

# 4. Start recovery instance
docker run -d \
  -v /tmp/restore:/var/lib/postgresql/data \
  -e POSTGRES_PASSWORD=recovery \
  --name postgres-recovery \
  postgres:16

# 5. Wait for recovery
docker logs -f postgres-recovery | grep -m1 "database system is ready"
```

### S3 Object Recovery

```bash
#!/bin/bash
# recover-s3-objects.sh

BUCKET=$1
PREFIX=$2
TARGET_DATE=$3

# List all versions
aws s3api list-object-versions \
  --bucket $BUCKET \
  --prefix $PREFIX \
  --query "Versions[?LastModified<='$TARGET_DATE']"

# Restore specific version
aws s3api copy-object \
  --bucket $BUCKET \
  --copy-source "$BUCKET/$PREFIX?versionId=$VERSION_ID" \
  --key "$PREFIX"
```

## Testing Schedule

| Test | Frequency | Duration | Last Test |
|------|-----------|----------|-----------|
| Backup Restore | Monthly | 2 hours | 2025-01-01 |
| Zone Failover | Quarterly | 1 hour | 2024-12-01 |
| Region Failover | Annually | 4 hours | 2024-06-01 |
| Full DR Exercise | Annually | 8 hours | 2024-06-01 |

## DR Contacts

| Role | Primary | Secondary |
|------|---------|-----------|
| DR Coordinator | dr-lead@p9e.space | cto@p9e.space |
| Database Admin | dba@p9e.space | sre@p9e.space |
| Infrastructure | infra@p9e.space | sre@p9e.space |
| Communications | comms@p9e.space | support@p9e.space |
