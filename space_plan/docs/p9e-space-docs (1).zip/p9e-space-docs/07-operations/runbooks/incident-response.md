# Incident Response Runbook

## Overview

This runbook covers procedures for responding to production incidents in the P9E Space Platform.

## Incident Severity Levels

| Severity | Description | Response Time | Examples |
|----------|-------------|---------------|----------|
| **SEV1** | Critical - Complete outage | < 15 min | All services down, data loss |
| **SEV2** | Major - Significant degradation | < 30 min | Core service down, pass failures |
| **SEV3** | Minor - Limited impact | < 2 hours | Single tenant affected, slow queries |
| **SEV4** | Low - Minimal impact | < 24 hours | UI bugs, non-critical alerts |

## Incident Response Process

### 1. Detection & Triage

```
┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│   DETECT     │────▶│    TRIAGE    │────▶│   RESPOND    │
│              │     │              │     │              │
│ • Alerting   │     │ • Severity   │     │ • Mitigate   │
│ • Monitoring │     │ • Impact     │     │ • Communicate│
│ • User report│     │ • Assign IC  │     │ • Fix        │
└──────────────┘     └──────────────┘     └──────────────┘
```

**Triage Questions:**
1. What is the user impact?
2. Which services are affected?
3. When did it start?
4. Is it getting worse?

### 2. Incident Commander (IC) Responsibilities

- Declare incident severity
- Coordinate response team
- Own communication
- Make escalation decisions
- Call for help when needed

### 3. Communication

**Internal:**
- Slack: `#incident-{id}` channel
- Status page: Update every 15 minutes for SEV1/SEV2

**External (SEV1/SEV2):**
- Email to affected tenants
- Status page update

**Template:**
```
INCIDENT: {summary}
SEVERITY: SEV{n}
STATUS: {investigating|identified|mitigating|resolved}
IMPACT: {description}
NEXT UPDATE: {time}
```

## Common Incidents

### Service Unavailable (HTTP 503)

**Symptoms:** API returning 503, health checks failing

**Diagnosis:**
```bash
# Check pod status
kubectl get pods -n p9e-space

# Check logs
kubectl logs -l app=platform --tail=100

# Check resources
kubectl top pods -n p9e-space
```

**Resolution:**
1. Check if deployment is healthy: `kubectl rollout status`
2. Check resource limits (OOM?)
3. Check database connectivity
4. Scale up if needed: `kubectl scale deployment platform --replicas=5`

### Database Connection Exhaustion

**Symptoms:** "too many connections" errors

**Diagnosis:**
```sql
SELECT count(*) FROM pg_stat_activity;
SELECT * FROM pg_stat_activity WHERE state = 'idle';
```

**Resolution:**
1. Identify connection leaks in application
2. Terminate idle connections: `SELECT pg_terminate_backend(pid)`
3. Increase `max_connections` if needed
4. Review connection pool settings

### High Latency

**Symptoms:** p95 > SLO, timeout errors

**Diagnosis:**
```bash
# Check service latency
curl -s "http://prometheus:9090/api/v1/query?query=histogram_quantile(0.95,http_request_duration_seconds_bucket)"

# Check slow queries
kubectl exec -it postgres-0 -- psql -c "SELECT * FROM pg_stat_statements ORDER BY mean_time DESC LIMIT 10"
```

**Resolution:**
1. Identify slow endpoints
2. Check for missing indexes
3. Review recent deployments
4. Add caching if appropriate

### Telemetry Streaming Failure

**Symptoms:** No telemetry during pass, TM gap alerts

**Diagnosis:**
```bash
# Check NATS
kubectl exec -it nats-0 -- nats stream info TELEMETRY

# Check SDR connection
kubectl logs -l app=groundstation --tail=100 | grep -i "sdr\|telemetry"
```

**Resolution:**
1. Verify SDR hardware connectivity
2. Check NATS stream health
3. Restart telemetry decoder if needed
4. Review pass execution logs

### Pass Execution Failure

**Symptoms:** Pass status = FAILED, no contact

**Diagnosis:**
```bash
# Get pass details
curl "https://api.p9e.space/v1/passes/{id}"

# Check antenna logs
kubectl logs -l app=antenna-controller --tail=100

# Check TLE freshness
curl "https://api.p9e.space/v1/satellites/{id}/tle"
```

**Resolution:**
1. Verify TLE is current (< 24h old)
2. Check antenna pointing accuracy
3. Verify ground station status
4. Review doppler compensation

## Post-Incident

### Incident Review Meeting

Schedule within 48 hours for SEV1/SEV2.

**Agenda:**
1. Timeline review
2. What went well?
3. What could improve?
4. Action items

### Post-Mortem Template

```markdown
# Incident Post-Mortem: {title}

## Summary
{brief description}

## Impact
- Duration: {time}
- Users affected: {count}
- Data loss: {yes/no}

## Timeline
| Time (UTC) | Event |
|------------|-------|
| HH:MM | {event} |

## Root Cause
{analysis}

## Resolution
{what fixed it}

## Action Items
| ID | Action | Owner | Due |
|----|--------|-------|-----|
| 1  | {task} | {name}| {date}|

## Lessons Learned
{insights}
```

## Escalation Matrix

| Severity | First Response | Escalate To | Executive |
|----------|---------------|-------------|-----------|
| SEV1 | On-call SRE | SRE Lead → Engineering Lead | CTO |
| SEV2 | On-call SRE | SRE Lead | VP Engineering |
| SEV3 | On-call SRE | Team Lead | - |
| SEV4 | Support team | On-call SRE | - |

## Emergency Contacts

| Role | Contact |
|------|---------|
| SRE On-call | PagerDuty |
| Engineering Lead | Slack @eng-lead |
| Security | security@p9e.space |
| Database Admin | Slack @dba-team |
