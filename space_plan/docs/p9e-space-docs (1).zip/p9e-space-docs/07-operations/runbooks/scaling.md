# Scaling Runbook

## Overview

This runbook covers horizontal and vertical scaling procedures for the P9E Space Platform.

## Auto-Scaling Configuration

### Horizontal Pod Autoscaler (HPA)

```yaml
# Current HPA configuration
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: platform-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: platform
  minReplicas: 3
  maxReplicas: 20
  metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: 70
    - type: Resource
      resource:
        name: memory
        target:
          type: Utilization
          averageUtilization: 80
  behavior:
    scaleUp:
      stabilizationWindowSeconds: 60
      policies:
        - type: Pods
          value: 4
          periodSeconds: 60
    scaleDown:
      stabilizationWindowSeconds: 300
      policies:
        - type: Percent
          value: 10
          periodSeconds: 60
```

### Service-Specific Scaling

| Service | Min | Max | Scale Trigger |
|---------|-----|-----|---------------|
| platform | 3 | 20 | CPU > 70% |
| groundstation | 3 | 15 | Active passes > 3 |
| eo-processing | 2 | 50 | Queue depth > 50 |
| geoint | 2 | 10 | CPU > 70% |
| workers | 3 | 30 | Queue depth > 100 |

## Manual Scaling Procedures

### Scale Deployment

```bash
# Scale specific deployment
kubectl scale deployment platform --replicas=10

# Scale all deployments in namespace
kubectl scale deployment --all --replicas=5 -n p9e-space

# Verify scaling
kubectl get pods -l app=platform -w
```

### Scale Based on Event

```bash
# Scale up for expected high traffic
kubectl scale deployment platform --replicas=15
kubectl scale deployment groundstation --replicas=10

# After event, allow HPA to scale down naturally
# Or manually scale down after 30 minutes
kubectl scale deployment platform --replicas=5
```

## Database Scaling

### Read Replicas

```bash
# Add read replica
kubectl scale statefulset postgres --replicas=3

# Verify replication
kubectl exec -it postgres-0 -- psql -c "SELECT * FROM pg_stat_replication"

# Update connection pool to include replicas
kubectl patch configmap pgbouncer-config \
  -p '{"data":{"read_hosts":"postgres-1,postgres-2"}}'
```

### Vertical Scaling

```bash
# Scale up database resources
kubectl patch statefulset postgres -p '{
  "spec": {
    "template": {
      "spec": {
        "containers": [{
          "name": "postgres",
          "resources": {
            "requests": {"memory": "8Gi", "cpu": "4"},
            "limits": {"memory": "16Gi", "cpu": "8"}
          }
        }]
      }
    }
  }
}'

# Rolling restart
kubectl rollout restart statefulset postgres
```

## Redis Scaling

### Scale Redis Cluster

```bash
# Current: 3 nodes
# Add 3 more nodes
kubectl scale statefulset redis --replicas=6

# Rebalance cluster
kubectl exec -it redis-0 -- redis-cli --cluster rebalance \
  redis-0:6379 --cluster-use-empty-masters
```

## NATS Scaling

```bash
# Scale NATS cluster
kubectl scale statefulset nats --replicas=5

# Verify cluster health
kubectl exec -it nats-0 -- nats server info
```

## Pre-Event Scaling Checklist

For planned high-traffic events:

- [ ] Scale application pods to expected load + 20%
- [ ] Verify database connection pool size
- [ ] Pre-warm caches
- [ ] Increase API rate limits if needed
- [ ] Scale workers for expected queue depth
- [ ] Verify alerting thresholds adjusted
- [ ] Notify on-call team

## Capacity Planning

### Current Capacity

| Resource | Current | Peak | Headroom |
|----------|---------|------|----------|
| Platform API | 1000 req/s | 600 req/s | 40% |
| Database connections | 500 | 300 | 40% |
| Telemetry throughput | 10K frames/s | 5K frames/s | 50% |
| Storage | 50 TB | 30 TB | 40% |

### Scaling Triggers

| Metric | Warning | Critical | Action |
|--------|---------|----------|--------|
| CPU utilization | > 60% | > 80% | Scale pods |
| Memory utilization | > 70% | > 85% | Scale pods |
| DB connections | > 60% | > 80% | Add replicas |
| Queue depth | > 100 | > 500 | Scale workers |
| Storage usage | > 70% | > 85% | Expand volumes |

## Cost Optimization

After high-traffic periods:

1. Allow HPA to naturally scale down (30 min stabilization)
2. Review pod resource requests (right-sizing)
3. Consider spot instances for workers
4. Archive cold data to cheaper storage
