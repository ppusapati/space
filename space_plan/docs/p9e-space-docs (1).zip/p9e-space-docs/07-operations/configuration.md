# Configuration Management

## Environment Variables

```bash
# Core
P9E_ENV=production
P9E_LOG_LEVEL=info
P9E_LOG_FORMAT=json

# Database
DATABASE_URL=postgres://user:pass@host:5432/p9e?sslmode=require
REDIS_URL=redis://host:6379
NATS_URL=nats://host:4222

# Security
JWT_SECRET=${VAULT:secret/data/jwt-key}
ENCRYPTION_KEY=${VAULT:secret/data/encryption-key}

# External Services
SPACETRACK_USERNAME=${VAULT:secret/data/spacetrack}
SPACETRACK_PASSWORD=${VAULT:secret/data/spacetrack}
```

## Vault Integration

```
vault/
├── secret/data/production/
│   ├── database
│   ├── redis
│   ├── jwt
│   ├── encryption
│   ├── spacetrack
│   └── stripe
└── pki/
    └── issue/p9e
```

## ConfigMaps

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: platform-config
data:
  JWT_ACCESS_TOKEN_TTL: "15m"
  JWT_REFRESH_TOKEN_TTL: "168h"
  SESSION_IDLE_TIMEOUT: "15m"
  SESSION_MAX_LIFETIME: "8h"
  PASSWORD_MIN_LENGTH: "12"
  MFA_REQUIRED_ROLES: "admin,operator"
```

## Feature Flags

```yaml
features:
  new_telemetry_pipeline: true
  ml_inference: false
  advanced_analytics: true
```
