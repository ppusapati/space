# Deployment Guide

## Prerequisites

- Kubernetes 1.28+
- Helm 3.x
- kubectl configured
- Container registry access

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     KUBERNETES CLUSTER                          │
├─────────────────────────────────────────────────────────────────┤
│  NAMESPACE: p9e-space                                           │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐          │
│  │ platform │ │groundstn │ │satellite │ │    eo    │          │
│  │ (3 pods) │ │ (3 pods) │ │ (2 pods) │ │ (3 pods) │          │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘          │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐                       │
│  │  geoint  │ │  common  │ │  worker  │                       │
│  │ (2 pods) │ │ (2 pods) │ │ (5 pods) │                       │
│  └──────────┘ └──────────┘ └──────────┘                       │
├─────────────────────────────────────────────────────────────────┤
│  NAMESPACE: p9e-data                                            │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐          │
│  │postgres  │ │  redis   │ │   nats   │ │  minio   │          │
│  │(HA 3-node)│ │(3-node) │ │(3-node)  │ │(4-node)  │          │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘          │
└─────────────────────────────────────────────────────────────────┘
```

## Helm Installation

```bash
# Add Helm repo
helm repo add p9e https://charts.p9e.space
helm repo update

# Install
helm install p9e-space p9e/p9e-space \
  --namespace p9e-space \
  --create-namespace \
  --values values-production.yaml
```

## values-production.yaml

```yaml
global:
  environment: production
  domain: p9e.space

platform:
  replicas: 3
  resources:
    requests:
      cpu: 500m
      memory: 512Mi
    limits:
      cpu: 2000m
      memory: 2Gi

groundstation:
  replicas: 3
  
postgresql:
  enabled: true
  architecture: replication
  primary:
    persistence:
      size: 100Gi
  readReplicas:
    replicaCount: 2

redis:
  enabled: true
  architecture: replication
  replica:
    replicaCount: 3
```

## Rolling Updates

```bash
# Update image
kubectl set image deployment/platform platform=p9e/platform:v1.2.0

# Check rollout status
kubectl rollout status deployment/platform

# Rollback if needed
kubectl rollout undo deployment/platform
```
