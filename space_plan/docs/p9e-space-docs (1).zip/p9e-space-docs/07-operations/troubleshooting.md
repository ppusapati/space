# Troubleshooting Guide

## Common Issues

### Service Won't Start

1. Check pod status
```bash
kubectl get pods -n p9e-space
kubectl describe pod <pod-name> -n p9e-space
```

2. Check logs
```bash
kubectl logs <pod-name> -n p9e-space
```

3. Verify secrets
```bash
kubectl get secrets -n p9e-space
```

### Database Connection Issues

1. Check PostgreSQL status
```bash
kubectl exec -it postgres-0 -n p9e-data -- pg_isready
```

2. Verify connection string
```bash
kubectl exec -it <service-pod> -- env | grep DATABASE_URL
```

3. Check connection pool
```sql
SELECT count(*) FROM pg_stat_activity WHERE datname = 'p9e';
```

### High Latency

1. Check pod resources
```bash
kubectl top pods -n p9e-space
```

2. Check database slow queries
```sql
SELECT query, calls, mean_time FROM pg_stat_statements ORDER BY mean_time DESC LIMIT 10;
```

3. Check Redis memory
```bash
redis-cli INFO memory
```

### Telemetry Not Flowing

1. Check NATS connection
```bash
nats sub telemetry.>
```

2. Verify SDR status
```bash
curl http://sdr-controller:8080/status
```

3. Check telemetry service logs
```bash
kubectl logs -l app=groundstation -n p9e-space | grep telemetry
```

## Useful Commands

```bash
# Get all pods
kubectl get pods -n p9e-space -o wide

# Get events
kubectl get events -n p9e-space --sort-by='.lastTimestamp'

# Port forward to service
kubectl port-forward svc/platform 8080:8080 -n p9e-space

# Execute shell in pod
kubectl exec -it <pod-name> -n p9e-space -- /bin/sh

# Check resource usage
kubectl top pods -n p9e-space
kubectl top nodes
```
