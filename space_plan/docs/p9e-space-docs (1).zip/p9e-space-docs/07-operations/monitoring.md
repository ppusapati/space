# Monitoring Setup

## Stack

| Component | Purpose |
|-----------|---------|
| Prometheus | Metrics collection |
| Grafana | Dashboards |
| Loki | Log aggregation |
| Tempo | Distributed tracing |
| Alertmanager | Alert routing |

## Prometheus Configuration

```yaml
scrape_configs:
  - job_name: 'p9e-services'
    kubernetes_sd_configs:
      - role: pod
        namespaces:
          names: ['p9e-space']
    relabel_configs:
      - source_labels: [__meta_kubernetes_pod_annotation_prometheus_io_scrape]
        action: keep
        regex: true
```

## Key Dashboards

### Operations Dashboard
- Active passes
- Telemetry rate
- Command queue
- Alert summary

### Infrastructure Dashboard
- Pod health
- Resource usage
- Database connections
- Redis memory

## Alert Rules

```yaml
groups:
  - name: p9e-critical
    rules:
      - alert: ServiceDown
        expr: up == 0
        for: 1m
        labels:
          severity: critical
        annotations:
          summary: "Service {{ $labels.job }} is down"
          
      - alert: HighErrorRate
        expr: rate(http_requests_total{status=~"5.."}[5m]) / rate(http_requests_total[5m]) > 0.05
        for: 5m
        labels:
          severity: critical
```

## Alertmanager Routes

```yaml
route:
  group_by: ['alertname', 'severity']
  receiver: 'slack-warnings'
  routes:
    - match:
        severity: critical
      receiver: 'pagerduty-critical'
    - match:
        severity: warning
      receiver: 'slack-warnings'

receivers:
  - name: 'pagerduty-critical'
    pagerduty_configs:
      - service_key: '${PAGERDUTY_KEY}'
  - name: 'slack-warnings'
    slack_configs:
      - channel: '#alerts'
```
