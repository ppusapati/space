# Ground Station Module

> Satellite Tracking, Pass Scheduling, Telemetry & Command Operations

## Overview

The Ground Station module provides comprehensive capabilities for satellite operations including TLE management, pass prediction, real-time telemetry, command and control, anomaly detection, and alerting.

## Services

| Service | RPCs | Description |
|---------|------|-------------|
| [SatelliteService](./api/satellite-service.md) | 8 | Satellite catalog, TLE management |
| [GroundStationService](./api/groundstation-service.md) | 7 | Ground station configuration |
| [PassService](./api/pass-service.md) | 9 | Pass prediction and scheduling |
| [TelemetryService](./api/telemetry-service.md) | 6 | Real-time and historical telemetry |
| [CommandService](./api/command-service.md) | 8 | Command & control with 2-person auth |
| [AnomalyService](./api/anomaly-service.md) | 6 | Anomaly detection and tracking |
| [AlertService](./api/alert-service.md) | 8 | Alert management and routing |
| **Total** | **52** | |

## Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       GROUND STATION MODULE                                │
├─────────────────────────────────────────────────────────────────────────────┤
│  ┌───────────────────────────────────────────────────────────────────────┐ │
│  │                    REAL-TIME OPERATIONS                               │ │
│  │  Telemetry Streaming │ Command Queue │ Alert Manager │ Pass Executor │ │
│  │                              │                                        │ │
│  │                    ┌─────────┴─────────┐                              │ │
│  │                    │   NATS JetStream  │                              │ │
│  │                    └───────────────────┘                              │ │
│  └───────────────────────────────────────────────────────────────────────┘ │
│  ┌───────────────────────────────────────────────────────────────────────┐ │
│  │                    APPLICATION SERVICES                               │ │
│  │  Satellite │ Pass │ Telemetry │ Command │ Anomaly │ Alert            │ │
│  └───────────────────────────────────────────────────────────────────────┘ │
│  ┌───────────────────────────────────────────────────────────────────────┐ │
│  │                    DATA & INTEGRATION                                 │ │
│  │  PostgreSQL │ TimescaleDB │ Space-Track │ SDR │ Antenna │ AWS GS     │ │
│  └───────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Data Model

See [Data Model](./data-model.md)

| Table | Description |
|-------|-------------|
| satellites | Satellite catalog |
| tle_history | TLE history |
| ground_stations | GS locations |
| pass_schedules | Scheduled passes |
| pass_executions | Execution records |
| commands | Command submissions |
| telemetry_raw | Raw telemetry (TimescaleDB) |
| anomalies | Detected anomalies |
| alerts | Active alerts |

## Components

| Component | Description |
|-----------|-------------|
| [Pass Aggregate](./components/pass-aggregate.md) | Pass scheduling and execution |
| [Command Workflow](./components/command-workflow.md) | Two-person authorization |
| [Telemetry Pipeline](./components/telemetry-pipeline.md) | Real-time TM processing |

## Integrations

| Integration | Purpose |
|-------------|---------|
| [Space-Track](./integrations/space-track.md) | TLE and CDM data |
| [AWS Ground Station](./integrations/aws-groundstation.md) | Contact scheduling |
| [SDR Hardware](./integrations/sdr-hardware.md) | RF signal reception |
| [Antenna Controller](./integrations/antenna-controller.md) | Antenna pointing |

## Key Flows

### Pass Execution Flow
1. Scheduler triggers 30 min before AOS
2. Configure SDR, start antenna tracking
3. AOS: Start telemetry capture
4. Pass: Stream telemetry, process commands
5. LOS: Stop capture, park antenna
6. Generate report, detect anomalies

### Command Authorization Flow
1. Operator submits command
2. SAFE → Auto-approved, CRITICAL → Awaiting approval
3. Different approver reviews and approves
4. Command queued for pass
5. Sent during pass, wait for ACK

## Telemetry Architecture

```
SDR → Decoder → NATS JetStream → Archiver (TimescaleDB)
                      │        → Limit Checker → Alerts
                      └────────→ WebSocket Gateway → UI
```
