# Telemetry Pipeline Component

## Overview

The Telemetry Pipeline processes real-time satellite telemetry from acquisition through storage and alerting.

## Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       TELEMETRY PIPELINE                                    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────┐    ┌─────────┐    ┌─────────┐    ┌─────────┐    ┌─────────┐  │
│  │   SDR   │───▶│ DECODER │───▶│  NATS   │───▶│PROCESSOR│───▶│ STORAGE │  │
│  │Hardware │    │(CCSDS)  │    │JetStream│    │         │    │TimescaleDB│ │
│  └─────────┘    └─────────┘    └─────────┘    └────┬────┘    └─────────┘  │
│                                                    │                       │
│                                    ┌───────────────┼───────────────┐       │
│                                    ▼               ▼               ▼       │
│                              ┌─────────┐    ┌─────────┐    ┌─────────┐    │
│                              │ LIMIT   │    │WEBSOCKET│    │ ANOMALY │    │
│                              │ CHECK   │    │ GATEWAY │    │DETECTOR │    │
│                              └────┬────┘    └─────────┘    └─────────┘    │
│                                   │                                        │
│                                   ▼                                        │
│                              ┌─────────┐                                   │
│                              │ ALERTS  │                                   │
│                              └─────────┘                                   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Components

### 1. SDR Interface

Interfaces with Software Defined Radio hardware.

```go
type SDRInterface interface {
    Connect(config SDRConfig) error
    StartCapture(freq float64, bandwidth float64) error
    StopCapture() error
    ReadIQ(buffer []complex64) (int, error)
    GetSignalStrength() float64
    Close() error
}

type SDRConfig struct {
    DeviceID    string
    SampleRate  uint32
    CenterFreq  float64
    Gain        float64
    AGCEnabled  bool
}
```

### 2. Frame Decoder

Decodes CCSDS telemetry frames.

```go
type FrameDecoder interface {
    DecodeFrame(raw []byte) (*TelemetryFrame, error)
    ValidateCRC(frame []byte) bool
    ExtractParameters(frame *TelemetryFrame, params []ParameterDef) ([]ParameterValue, error)
}

type TelemetryFrame struct {
    Version      uint8
    SpacecraftID uint16
    VirtualChan  uint8
    SeqCount     uint16
    Timestamp    time.Time
    Data         []byte
    CRC          uint16
    Quality      FrameQuality
}
```

### 3. NATS Publisher

Publishes frames to NATS JetStream.

```go
type NATSPublisher struct {
    js    nats.JetStreamContext
    topic string
}

func (p *NATSPublisher) Publish(frame *TelemetryFrame) error {
    data, _ := proto.Marshal(frame)
    _, err := p.js.Publish(p.topic, data, nats.MsgId(frame.ID()))
    return err
}

// Stream configuration
const streamConfig = `
name: TELEMETRY
subjects: ["telemetry.>"]
retention: limits
max_msgs: 10000000
max_bytes: 10737418240  # 10GB
max_age: 86400000000000 # 24h
storage: file
replicas: 3
`
```

### 4. Telemetry Processor

Processes frames from NATS.

```go
type TelemetryProcessor struct {
    paramDefs    map[string]ParameterDefinition
    calibrations map[string]Calibration
    archiver     Archiver
    limitChecker LimitChecker
    wsGateway    WebSocketGateway
}

func (p *TelemetryProcessor) Process(frame *TelemetryFrame) error {
    // 1. Decode parameters
    params := p.decodeParameters(frame)
    
    // 2. Apply calibrations
    calibrated := p.applyCalibrations(params)
    
    // 3. Archive to TimescaleDB
    if err := p.archiver.Store(calibrated); err != nil {
        return err
    }
    
    // 4. Check limits
    violations := p.limitChecker.Check(calibrated)
    for _, v := range violations {
        p.handleViolation(v)
    }
    
    // 5. Broadcast to WebSocket clients
    p.wsGateway.Broadcast(frame.SatelliteID, calibrated)
    
    return nil
}
```

### 5. Limit Checker

Checks parameter values against limits.

```go
type LimitChecker struct {
    limits       map[string]ParameterLimits
    persistence  map[string]*PersistenceTracker
    alertService AlertService
}

type ParameterLimits struct {
    RedLow      float64
    YellowLow   float64
    YellowHigh  float64
    RedHigh     float64
    Persistence int // samples before alert
}

func (c *LimitChecker) Check(params []ParameterValue) []LimitViolation {
    var violations []LimitViolation
    
    for _, p := range params {
        limits, ok := c.limits[p.ParameterID]
        if !ok {
            continue
        }
        
        status := c.evaluateStatus(p.Value, limits)
        if status != LimitStatusNominal {
            tracker := c.persistence[p.ParameterID]
            if tracker.Increment(status) >= limits.Persistence {
                violations = append(violations, LimitViolation{
                    ParameterID: p.ParameterID,
                    Value:       p.Value,
                    Status:      status,
                    Limits:      limits,
                })
            }
        } else {
            c.persistence[p.ParameterID].Reset()
        }
    }
    
    return violations
}
```

### 6. TimescaleDB Archiver

Stores telemetry in TimescaleDB.

```go
type TimescaleArchiver struct {
    pool *pgxpool.Pool
}

func (a *TimescaleArchiver) Store(params []ParameterValue) error {
    batch := &pgx.Batch{}
    
    for _, p := range params {
        batch.Queue(`
            INSERT INTO telemetry_raw (time, satellite_id, parameter_id, value, raw_value, quality)
            VALUES ($1, $2, $3, $4, $5, $6)
        `, p.Timestamp, p.SatelliteID, p.ParameterID, p.Value, p.RawValue, p.Quality)
    }
    
    results := a.pool.SendBatch(context.Background(), batch)
    defer results.Close()
    
    return results.Close()
}
```

## Data Flow

### Real-Time Path

```
SDR → Decoder → NATS (< 10ms) → Processor → WebSocket (< 50ms total)
```

### Storage Path

```
NATS → Archiver → TimescaleDB
         ↓
    Continuous Aggregates
    ├── telemetry_1min (real-time)
    └── telemetry_1hour (delayed)
```

## Configuration

```yaml
telemetry:
  pipeline:
    buffer_size: 10000
    workers: 8
    batch_size: 100
    batch_timeout_ms: 50
    
  decoder:
    frame_size: 1115  # CCSDS TM frame
    sync_marker: "1acffc1d"
    crc_polynomial: 0x1021
    
  nats:
    stream_name: TELEMETRY
    subject_pattern: "telemetry.{satellite_id}"
    max_pending: 10000
    
  limits:
    check_interval_ms: 100
    default_persistence: 3
    
  storage:
    batch_size: 1000
    flush_interval_ms: 100
```

## Metrics

| Metric | Type | Description |
|--------|------|-------------|
| `telemetry_frames_received_total` | Counter | Total frames received |
| `telemetry_frames_decoded_total` | Counter | Successfully decoded frames |
| `telemetry_decode_errors_total` | Counter | Decoding errors |
| `telemetry_pipeline_latency_ms` | Histogram | End-to-end latency |
| `telemetry_buffer_usage` | Gauge | Buffer utilization |
| `telemetry_limit_violations_total` | Counter | Limit violations |

## Error Handling

| Error | Handling |
|-------|----------|
| Frame CRC error | Log, increment counter, skip frame |
| NATS publish failure | Retry with backoff, buffer locally |
| DB write failure | Retry, queue to dead letter |
| Parameter decode error | Log, use previous value |
