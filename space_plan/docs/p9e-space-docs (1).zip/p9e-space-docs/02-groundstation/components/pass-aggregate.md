# Pass Aggregate

## Overview
Manages pass scheduling, execution, and lifecycle.

## Aggregate Structure
```
PassAggregate
├── PassSchedule (root)
│   ├── ID, SatelliteID, GroundStationID
│   ├── PredictedAOS, PredictedLOS, PredictedTCA
│   ├── MaxElevation, AOSAzimuth, LOSAzimuth
│   ├── Status, Priority
│   └── CreatedBy, CreatedAt
│
├── PassExecution
│   ├── ActualAOS, ActualLOS
│   ├── TelemetryFrames, TelemetryBytes
│   ├── CommandsSent, CommandsAcked
│   ├── MaxSignalDBM, AvgSignalDBM
│   └── Status, Errors
│
└── Commands[] (queued for pass)
```

## State Machine
```
PREDICTED → SCHEDULED → CONFIRMED → IN_PROGRESS → COMPLETED
              │                           │
              └→ CANCELLED               └→ FAILED
```

## Domain Events
- PassScheduled
- PassConfirmed
- PassStarted (AOS)
- PassCompleted (LOS)
- PassCancelled
- PassFailed
