# Command Workflow

## Overview
Two-person authorization for critical spacecraft commands.

## State Machine
```
DRAFT → PENDING → AWAITING_APPROVAL → APPROVED → QUEUED → SENT → ACKED
                         │                                    │
                         └→ REJECTED                        FAILED
```

## Authorization Rules

| Hazard Level | Auto-Approve | Requires Approval |
|--------------|--------------|-------------------|
| SAFE | Yes | No |
| CAUTION | No | Yes (same user OK) |
| CRITICAL | No | Yes (different user) |

## Implementation
```go
func (s *CommandService) Submit(ctx context.Context, cmd Command) error {
    if cmd.HazardLevel == HazardLevelSafe {
        cmd.Status = CommandStatusApproved
    } else {
        cmd.Status = CommandStatusAwaitingApproval
    }
    return s.repo.Save(ctx, cmd)
}

func (s *CommandService) Approve(ctx context.Context, cmdID, approverID string) error {
    cmd, _ := s.repo.Get(ctx, cmdID)
    
    if cmd.HazardLevel == HazardLevelCritical && cmd.SubmittedBy == approverID {
        return ErrSameUserCannotApprove
    }
    
    cmd.Status = CommandStatusApproved
    cmd.ApprovedBy = approverID
    cmd.ApprovedAt = time.Now()
    
    return s.repo.Save(ctx, cmd)
}
```
