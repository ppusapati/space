# Ground Station Module - Data Model

## Schema: `groundstation`

## Tables

### satellites
```sql
CREATE TABLE groundstation.satellites (
    id UUID PRIMARY KEY,
    tenant_id UUID NOT NULL REFERENCES platform.tenants(id),
    norad_id INTEGER NOT NULL,
    cospar_id VARCHAR(20),
    name VARCHAR(255) NOT NULL,
    mission_type mission_type NOT NULL,
    status satellite_status NOT NULL DEFAULT 'operational',
    downlink_freq_mhz DECIMAL(10,4),
    uplink_freq_mhz DECIMAL(10,4),
    config JSONB NOT NULL DEFAULT '{}',
    CONSTRAINT unique_norad_per_tenant UNIQUE (tenant_id, norad_id)
);
```

### tle_history
```sql
CREATE TABLE groundstation.tle_history (
    id UUID PRIMARY KEY,
    satellite_id UUID NOT NULL REFERENCES groundstation.satellites(id),
    line1 VARCHAR(69) NOT NULL,
    line2 VARCHAR(69) NOT NULL,
    epoch TIMESTAMPTZ NOT NULL,
    source VARCHAR(50) NOT NULL DEFAULT 'space-track',
    fetched_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

### ground_stations
```sql
CREATE TABLE groundstation.ground_stations (
    id UUID PRIMARY KEY,
    tenant_id UUID NOT NULL,
    name VARCHAR(255) NOT NULL,
    code VARCHAR(10) NOT NULL,
    latitude DECIMAL(9,6) NOT NULL,
    longitude DECIMAL(9,6) NOT NULL,
    altitude_m DECIMAL(10,2) NOT NULL DEFAULT 0,
    min_elevation DECIMAL(5,2) NOT NULL DEFAULT 5.0,
    capabilities TEXT[] NOT NULL DEFAULT '{}',
    status gs_status NOT NULL DEFAULT 'operational'
);
```

### pass_schedules
```sql
CREATE TABLE groundstation.pass_schedules (
    id UUID PRIMARY KEY,
    tenant_id UUID NOT NULL,
    satellite_id UUID NOT NULL,
    ground_station_id UUID NOT NULL,
    predicted_aos TIMESTAMPTZ NOT NULL,
    predicted_los TIMESTAMPTZ NOT NULL,
    predicted_tca TIMESTAMPTZ NOT NULL,
    max_elevation DECIMAL(5,2) NOT NULL,
    status pass_status NOT NULL DEFAULT 'scheduled',
    priority INTEGER NOT NULL DEFAULT 5
);
```

### commands
```sql
CREATE TABLE groundstation.commands (
    id UUID PRIMARY KEY,
    tenant_id UUID NOT NULL,
    satellite_id UUID NOT NULL,
    mnemonic VARCHAR(50) NOT NULL,
    parameters JSONB NOT NULL DEFAULT '{}',
    hazard_level hazard_level NOT NULL,
    status command_status NOT NULL DEFAULT 'pending',
    justification TEXT,
    submitted_by UUID NOT NULL,
    submitted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    approved_by UUID,
    approved_at TIMESTAMPTZ,
    sent_at TIMESTAMPTZ,
    acked_at TIMESTAMPTZ,
    CONSTRAINT two_person_auth CHECK (hazard_level IN ('safe','caution') OR approved_by != submitted_by)
);
```

## Telemetry (TimescaleDB)

```sql
CREATE TABLE groundstation.telemetry_raw (
    time TIMESTAMPTZ NOT NULL,
    satellite_id UUID NOT NULL,
    parameter_id VARCHAR(50) NOT NULL,
    value DOUBLE PRECISION NOT NULL,
    quality telemetry_quality NOT NULL DEFAULT 'good',
    PRIMARY KEY (satellite_id, parameter_id, time)
);

SELECT create_hypertable('groundstation.telemetry_raw', 'time',
    chunk_time_interval => INTERVAL '1 minute');

-- Continuous aggregates
CREATE MATERIALIZED VIEW groundstation.telemetry_1min
WITH (timescaledb.continuous) AS
SELECT time_bucket('1 minute', time) AS bucket,
       satellite_id, parameter_id,
       AVG(value), MIN(value), MAX(value), COUNT(*)
FROM groundstation.telemetry_raw
GROUP BY bucket, satellite_id, parameter_id;

-- Retention
SELECT add_retention_policy('groundstation.telemetry_raw', INTERVAL '7 days');
SELECT add_retention_policy('groundstation.telemetry_1min', INTERVAL '90 days');
```

## Enums
```sql
CREATE TYPE satellite_status AS ENUM ('commissioning','operational','degraded','safe_mode','decommissioned');
CREATE TYPE pass_status AS ENUM ('predicted','scheduled','confirmed','in_progress','completed','cancelled','failed');
CREATE TYPE hazard_level AS ENUM ('safe','caution','critical');
CREATE TYPE command_status AS ENUM ('draft','pending','awaiting_approval','approved','rejected','queued','sent','acked','failed','expired');
```
