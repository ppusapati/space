# AWS Ground Station Integration

## Overview
Contact scheduling and data delivery via AWS Ground Station.

## Configuration
- **Regions**: us-east-2, us-west-2, eu-north-1, me-south-1, ap-southeast-2, af-south-1
- **Auth**: IAM SigV4

## Implementation
```go
type AWSGroundStationClient struct {
    client *groundstation.Client
}

func (c *AWSGroundStationClient) ReserveContact(ctx context.Context, req ReserveContactRequest) (*Contact, error) {
    output, err := c.client.ReserveContact(ctx, &groundstation.ReserveContactInput{
        SatelliteArn:      &req.SatelliteArn,
        MissionProfileArn: &req.MissionProfileArn,
        GroundStation:     &req.GroundStation,
        StartTime:         &req.StartTime,
        EndTime:           &req.EndTime,
    })
    // ...
}
```

## Data Flow
```
AWS Ground Station Antenna
    │
    ▼
SDR (at antenna site)
    │
    ▼
Data Endpoint (EC2)
    │
    ▼
NATS JetStream → P9E Platform
```
