# Space-Track Integration

## Overview
TLE and CDM data from 18th Space Defense Squadron.

## Configuration
- **Base URL**: https://www.space-track.org
- **Auth**: Username/Password session cookies (2-hour expiry)
- **Rate Limit**: 200 requests/hour

## Implementation
```go
type SpaceTrackClient struct {
    baseURL   string
    username  string
    password  string
    session   *http.Cookie
    expiresAt time.Time
}

func (c *SpaceTrackClient) FetchTLE(ctx context.Context, noradID int) (*TLE, error) {
    if err := c.ensureSession(ctx); err != nil {
        return nil, err
    }
    
    url := fmt.Sprintf("%s/basicspacedata/query/class/gp/NORAD_CAT_ID/%d/orderby/EPOCH desc/limit/1/format/tle", 
        c.baseURL, noradID)
    
    resp, err := c.httpClient.Get(url)
    // ... parse TLE
}

func (c *SpaceTrackClient) FetchCDM(ctx context.Context, noradID int, since time.Time) ([]CDM, error) {
    // Fetch conjunction data messages
}
```

## Data Refresh
- TLE refresh: Every 6 hours
- CDM check: Every hour for active satellites
