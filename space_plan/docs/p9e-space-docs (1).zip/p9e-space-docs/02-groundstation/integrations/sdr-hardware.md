# SDR Hardware Integration

## Overview
RF signal reception and demodulation.

## Supported Hardware
| Device | Interface | Frequencies |
|--------|-----------|-------------|
| RTL-SDR | USB | 24-1766 MHz |
| HackRF | USB | 1-6000 MHz |
| USRP | USB/Ethernet | Model-dependent |
| BladeRF | USB | 300-3800 MHz |

## Interface
```go
type SDRController interface {
    SetFrequency(freq float64) error
    SetSampleRate(rate float64) error
    SetGain(gain float64) error
    SetBandwidth(bw float64) error
    StartStream(ctx context.Context) (<-chan []complex64, error)
    StopStream() error
    GetStatus() SDRStatus
}
```

## GNU Radio Integration
```go
type GNURadioController struct {
    controlSocket string // tcp://localhost:5555
    dataSocket    string // tcp://localhost:5556
}

func (c *GNURadioController) SetFrequency(freq float64) error {
    return c.sendCommand(fmt.Sprintf("set_freq %.0f", freq))
}
```
