# Antenna Controller Integration

## Overview
Antenna pointing via azimuth/elevation control.

## Supported Hardware
| Hardware | Protocol | Interface |
|----------|----------|-----------|
| Yaesu G-5500 | EasyComm II | Serial |
| SPID | SPID Native | Serial |
| M2 Orion | EasyComm II | Serial |
| Custom | Hamlib | TCP |

## Interface
```go
type RotatorController interface {
    SetPosition(az, el float64) error
    GetPosition() (az, el float64, err error)
    Park() error
    Stop() error
    StartTracking(trajectory []TrajectoryPoint) error
    StopTracking() error
}
```

## Hamlib Implementation
```go
type HamlibController struct {
    conn net.Conn
}

func (c *HamlibController) SetPosition(az, el float64) error {
    cmd := fmt.Sprintf("P %.1f %.1f\n", az, el)
    _, err := c.conn.Write([]byte(cmd))
    return err
}

func (c *HamlibController) GetPosition() (float64, float64, error) {
    _, err := c.conn.Write([]byte("p\n"))
    // Parse response "AZ EL"
}
```

## Tracking Loop
```go
func (c *RotatorController) StartTracking(traj []TrajectoryPoint) {
    ticker := time.NewTicker(500 * time.Millisecond)
    for {
        select {
        case <-ticker.C:
            pos := interpolate(traj, time.Now())
            c.SetPosition(pos.Az, pos.El)
        case <-c.stopCh:
            return
        }
    }
}
```
