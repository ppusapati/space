# PassService API

> Satellite pass scheduling, prediction, and execution

## Service Definition

```protobuf
service PassService {
  // Pass management
  rpc GetPass(GetPassRequest) returns (Pass);
  rpc ListPasses(ListPassesRequest) returns (ListPassesResponse);
  rpc SchedulePass(SchedulePassRequest) returns (Pass);
  rpc CancelPass(CancelPassRequest) returns (Pass);
  rpc UpdatePass(UpdatePassRequest) returns (Pass);
  
  // Pass prediction
  rpc PredictPasses(PredictPassesRequest) returns (PredictPassesResponse);
  rpc GetVisibilityWindows(GetVisibilityWindowsRequest) returns (VisibilityWindowsResponse);
  
  // Pass execution
  rpc GetPassExecution(GetPassExecutionRequest) returns (PassExecution);
  rpc StreamPassStatus(StreamPassStatusRequest) returns (stream PassStatusUpdate);
  
  // Pass reports
  rpc GetPassReport(GetPassReportRequest) returns (PassReport);
}
```

## Messages

### Pass

```protobuf
message Pass {
  string id = 1;
  string tenant_id = 2;
  string satellite_id = 3;
  string ground_station_id = 4;
  
  // Predicted times
  google.protobuf.Timestamp predicted_aos = 5;  // Acquisition of Signal
  google.protobuf.Timestamp predicted_los = 6;  // Loss of Signal
  google.protobuf.Timestamp predicted_tca = 7;  // Time of Closest Approach
  
  // Geometry
  double max_elevation_deg = 8;
  double aos_azimuth_deg = 9;
  double los_azimuth_deg = 10;
  int32 duration_seconds = 11;
  
  // Scheduling
  PassStatus status = 12;
  PassPriority priority = 13;
  string mission_type = 14;
  string notes = 15;
  
  // Metadata
  google.protobuf.Timestamp created_at = 16;
  string created_by = 17;
}

enum PassStatus {
  PASS_STATUS_UNSPECIFIED = 0;
  PASS_STATUS_PREDICTED = 1;    // Auto-generated prediction
  PASS_STATUS_SCHEDULED = 2;    // Manually scheduled
  PASS_STATUS_CONFIRMED = 3;    // Resources allocated
  PASS_STATUS_PREPARING = 4;    // Pre-pass setup
  PASS_STATUS_IN_PROGRESS = 5;  // AOS to LOS
  PASS_STATUS_COMPLETED = 6;    // Successfully executed
  PASS_STATUS_CANCELLED = 7;    // Cancelled before execution
  PASS_STATUS_FAILED = 8;       // Execution failed
}

enum PassPriority {
  PASS_PRIORITY_UNSPECIFIED = 0;
  PASS_PRIORITY_LOW = 1;
  PASS_PRIORITY_NORMAL = 2;
  PASS_PRIORITY_HIGH = 3;
  PASS_PRIORITY_CRITICAL = 4;
}
```

### PassExecution

```protobuf
message PassExecution {
  string id = 1;
  string pass_id = 2;
  
  // Actual times
  google.protobuf.Timestamp actual_aos = 3;
  google.protobuf.Timestamp actual_los = 4;
  
  // Statistics
  int64 telemetry_frames = 5;
  int64 telemetry_bytes = 6;
  int32 commands_sent = 7;
  int32 commands_acked = 8;
  
  // Signal quality
  double max_signal_dbm = 9;
  double avg_signal_dbm = 10;
  int32 doppler_hz = 11;
  
  // Status
  ExecutionStatus status = 12;
  repeated ExecutionError errors = 13;
  string notes = 14;
}

enum ExecutionStatus {
  EXECUTION_STATUS_UNSPECIFIED = 0;
  EXECUTION_STATUS_PENDING = 1;
  EXECUTION_STATUS_PREPARING = 2;
  EXECUTION_STATUS_TRACKING = 3;
  EXECUTION_STATUS_AOS = 4;
  EXECUTION_STATUS_NOMINAL = 5;
  EXECUTION_STATUS_DEGRADED = 6;
  EXECUTION_STATUS_LOS = 7;
  EXECUTION_STATUS_COMPLETED = 8;
  EXECUTION_STATUS_FAILED = 9;
  EXECUTION_STATUS_ABORTED = 10;
}

message ExecutionError {
  string code = 1;
  string message = 2;
  google.protobuf.Timestamp timestamp = 3;
  Severity severity = 4;
}
```

## RPCs

### PredictPasses

Predicts future passes for a satellite/ground station combination.

```protobuf
message PredictPassesRequest {
  string satellite_id = 1 [(validate.rules).string.uuid = true];
  string ground_station_id = 2 [(validate.rules).string.uuid = true];
  common.v1.TimeRange time_range = 3;
  double min_elevation_deg = 4;  // Default: 5.0
  int32 max_passes = 5;          // Default: 100
}

message PredictPassesResponse {
  repeated PassPrediction passes = 1;
  string tle_epoch = 2;
}

message PassPrediction {
  google.protobuf.Timestamp aos = 1;
  google.protobuf.Timestamp los = 2;
  google.protobuf.Timestamp tca = 3;
  double max_elevation_deg = 4;
  double aos_azimuth_deg = 5;
  double los_azimuth_deg = 6;
  int32 duration_seconds = 7;
  bool sun_illuminated = 8;
  bool in_eclipse = 9;
}
```

**Example:**

```bash
curl "https://api.p9e.space/v1/passes/predict" \
  -d '{
    "satellite_id": "sat-uuid",
    "ground_station_id": "gs-uuid",
    "time_range": {
      "start": "2025-01-01T00:00:00Z",
      "end": "2025-01-08T00:00:00Z"
    },
    "min_elevation_deg": 10.0
  }'
```

### SchedulePass

Schedules a pass from a prediction.

```protobuf
message SchedulePassRequest {
  string satellite_id = 1;
  string ground_station_id = 2;
  google.protobuf.Timestamp aos = 3;
  PassPriority priority = 4;
  string mission_type = 5;
  string notes = 6;
  repeated string command_ids = 7;  // Pre-load command queue
}
```

**Authorization:** `passes.schedule`

**Errors:**

| Code | Condition |
|------|-----------|
| `ALREADY_EXISTS` | Pass already scheduled for this window |
| `FAILED_PRECONDITION` | Conflicting pass at same ground station |
| `INVALID_ARGUMENT` | Invalid time range |

### ListPasses

Lists passes with filtering.

```protobuf
message ListPassesRequest {
  string satellite_id = 1;
  string ground_station_id = 2;
  common.v1.TimeRange time_range = 3;
  repeated PassStatus status_filter = 4;
  common.v1.PageRequest page = 5;
}

message ListPassesResponse {
  repeated Pass passes = 1;
  common.v1.PageInfo page_info = 2;
}
```

### StreamPassStatus

Streams real-time pass status updates.

```protobuf
message StreamPassStatusRequest {
  string pass_id = 1;
}

message PassStatusUpdate {
  string pass_id = 1;
  ExecutionStatus status = 2;
  google.protobuf.Timestamp timestamp = 3;
  
  // Current metrics
  double elevation_deg = 4;
  double azimuth_deg = 5;
  double signal_dbm = 6;
  int64 frames_received = 7;
  
  // Events
  repeated PassEvent events = 8;
}

message PassEvent {
  string type = 1;      // "aos", "los", "lock_acquired", "signal_lost"
  string message = 2;
  google.protobuf.Timestamp timestamp = 3;
}
```

### GetPassReport

Gets post-pass execution report.

```protobuf
message GetPassReportRequest {
  string pass_id = 1;
}

message PassReport {
  Pass pass = 1;
  PassExecution execution = 2;
  
  // Summary
  bool successful = 3;
  int32 objectives_completed = 4;
  int32 objectives_total = 5;
  
  // Telemetry summary
  repeated ParameterSummary telemetry_summary = 6;
  repeated LimitViolation limit_violations = 7;
  
  // Command summary
  repeated CommandSummary commands = 8;
  
  // Anomalies detected
  repeated AnomalySummary anomalies = 9;
}
```

## Pass Execution Flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         PASS EXECUTION TIMELINE                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  T-30min         T-5min          T-0 (AOS)        T+duration       LOS      │
│     │               │               │                │              │       │
│     ▼               ▼               ▼                ▼              ▼       │
│  ┌──────┐       ┌──────┐       ┌──────┐         ┌──────┐       ┌──────┐    │
│  │PREPARE│ ────▶│TRACK │ ────▶│ AOS  │ ───────▶│NOMINAL│ ────▶│ LOS  │    │
│  └──────┘       └──────┘       └──────┘         └──────┘       └──────┘    │
│     │               │               │                │              │       │
│     │               │               │                │              │       │
│  • Verify TLE    • Slew to      • Start TM       • Stream TM    • Stop TM  │
│  • Check SDR       predict      • Enable CMD     • Execute CMD  • Park ant │
│  • Load cmds     • Acquire      • Log AOS        • Monitor      • Generate │
│  • Notify          signal                          limits         report   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Events

| Event | Trigger | Payload |
|-------|---------|---------|
| `pass.scheduled` | SchedulePass | Pass |
| `pass.preparing` | T-30min | pass_id |
| `pass.aos` | Signal acquired | pass_id, timestamp |
| `pass.los` | Signal lost | pass_id, timestamp |
| `pass.completed` | Execution done | PassReport |
| `pass.failed` | Execution error | pass_id, errors |

## Metrics

| Metric | Type | Labels | Description |
|--------|------|--------|-------------|
| `passes_total` | Counter | status, ground_station | Pass count |
| `pass_duration_seconds` | Histogram | satellite_id | Pass duration |
| `pass_max_elevation_deg` | Histogram | ground_station | Max elevation |
| `pass_telemetry_frames` | Counter | pass_id | Frames per pass |
