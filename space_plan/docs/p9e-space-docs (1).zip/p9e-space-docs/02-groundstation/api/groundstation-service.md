# Ground Station Service API
> Package: `groundstation.v1`

## Service Definition
```protobuf
service GroundStationService {
  rpc CreateGroundStation(CreateGroundStationRequest) returns (GroundStation);
  rpc GetGroundStation(GetGroundStationRequest) returns (GroundStation);
  rpc UpdateGroundStation(UpdateGroundStationRequest) returns (GroundStation);
  rpc DeleteGroundStation(DeleteGroundStationRequest) returns (google.protobuf.Empty);
  rpc ListGroundStations(ListGroundStationsRequest) returns (ListGroundStationsResponse);
  rpc GetGroundStationStatus(GetGroundStationStatusRequest) returns (GroundStationStatus);
  rpc SetGroundStationMode(SetGroundStationModeRequest) returns (GroundStation);
}
```

## Messages
```protobuf
message GroundStation {
  string id = 1;
  string tenant_id = 2;
  string name = 3;
  string code = 4;
  double latitude = 5;
  double longitude = 6;
  double altitude_m = 7;
  double min_elevation = 8;
  repeated string capabilities = 9;
  GroundStationStatus status = 10;
}
```
