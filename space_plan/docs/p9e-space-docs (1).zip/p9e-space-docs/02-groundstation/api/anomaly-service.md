# Anomaly Service API
> Package: `groundstation.v1`

## Service Definition
```protobuf
service AnomalyService {
  rpc ListAnomalies(ListAnomaliesRequest) returns (ListAnomaliesResponse);
  rpc GetAnomaly(GetAnomalyRequest) returns (Anomaly);
  rpc AcknowledgeAnomaly(AcknowledgeAnomalyRequest) returns (Anomaly);
  rpc ResolveAnomaly(ResolveAnomalyRequest) returns (Anomaly);
  rpc CreateAnomalyRule(CreateAnomalyRuleRequest) returns (AnomalyRule);
  rpc ListAnomalyRules(ListAnomalyRulesRequest) returns (ListAnomalyRulesResponse);
}
```

## Messages
```protobuf
message Anomaly {
  string id = 1;
  string satellite_id = 2;
  AnomalyType type = 3;
  SeverityLevel severity = 4;
  AnomalyStatus status = 5;
  string title = 6;
  string description = 7;
  string parameter_id = 8;
  double expected_value = 9;
  double actual_value = 10;
  google.protobuf.Timestamp detected_at = 11;
}

enum AnomalyType {
  ANOMALY_TYPE_LIMIT_VIOLATION = 1;
  ANOMALY_TYPE_TREND = 2;
  ANOMALY_TYPE_MISSING_DATA = 3;
  ANOMALY_TYPE_CORRELATION = 4;
}
```
