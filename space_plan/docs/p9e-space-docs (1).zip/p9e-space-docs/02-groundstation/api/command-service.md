# CommandService API

> Spacecraft commanding with two-person authorization

## Service Definition

```protobuf
service CommandService {
  // Command lifecycle
  rpc SubmitCommand(SubmitCommandRequest) returns (Command);
  rpc GetCommand(GetCommandRequest) returns (Command);
  rpc ListCommands(ListCommandsRequest) returns (ListCommandsResponse);
  
  // Authorization workflow
  rpc ApproveCommand(ApproveCommandRequest) returns (Command);
  rpc RejectCommand(RejectCommandRequest) returns (Command);
  rpc CancelCommand(CancelCommandRequest) returns (Command);
  
  // Command catalog
  rpc GetCommandDefinition(GetCommandDefinitionRequest) returns (CommandDefinition);
  rpc ListCommandDefinitions(ListCommandDefinitionsRequest) returns (ListCommandDefinitionsResponse);
  rpc CreateCommandDefinition(CreateCommandDefinitionRequest) returns (CommandDefinition);
  rpc UpdateCommandDefinition(UpdateCommandDefinitionRequest) returns (CommandDefinition);
  
  // Queue management
  rpc GetCommandQueue(GetCommandQueueRequest) returns (CommandQueue);
  rpc ReorderQueue(ReorderQueueRequest) returns (CommandQueue);
}
```

## Messages

### Command

```protobuf
message Command {
  string id = 1;
  string tenant_id = 2;
  string satellite_id = 3;
  string command_definition_id = 4;
  string mnemonic = 5;
  google.protobuf.Struct parameters = 6;
  HazardLevel hazard_level = 7;
  CommandStatus status = 8;
  string justification = 9;
  
  // Scheduling
  google.protobuf.Timestamp scheduled_for = 10;
  string pass_id = 11;
  
  // Submission
  string submitted_by = 12;
  google.protobuf.Timestamp submitted_at = 13;
  
  // Authorization (two-person)
  string approved_by = 14;
  google.protobuf.Timestamp approved_at = 15;
  string rejected_by = 16;
  google.protobuf.Timestamp rejected_at = 17;
  string rejection_reason = 18;
  
  // Execution
  google.protobuf.Timestamp sent_at = 19;
  google.protobuf.Timestamp acked_at = 20;
  google.protobuf.Struct response = 21;
  
  // Expiry
  google.protobuf.Timestamp expires_at = 22;
}

enum HazardLevel {
  HAZARD_LEVEL_UNSPECIFIED = 0;
  HAZARD_LEVEL_SAFE = 1;      // Auto-approved
  HAZARD_LEVEL_CAUTION = 2;   // Requires justification
  HAZARD_LEVEL_CRITICAL = 3;  // Requires two-person auth
}

enum CommandStatus {
  COMMAND_STATUS_UNSPECIFIED = 0;
  COMMAND_STATUS_DRAFT = 1;
  COMMAND_STATUS_PENDING = 2;
  COMMAND_STATUS_AWAITING_APPROVAL = 3;
  COMMAND_STATUS_APPROVED = 4;
  COMMAND_STATUS_REJECTED = 5;
  COMMAND_STATUS_QUEUED = 6;
  COMMAND_STATUS_SENT = 7;
  COMMAND_STATUS_ACKED = 8;
  COMMAND_STATUS_FAILED = 9;
  COMMAND_STATUS_EXPIRED = 10;
  COMMAND_STATUS_CANCELLED = 11;
}
```

### CommandDefinition

```protobuf
message CommandDefinition {
  string id = 1;
  string satellite_id = 2;
  string mnemonic = 3;
  string name = 4;
  string description = 5;
  HazardLevel hazard_level = 6;
  repeated ParameterDefinition parameters = 7;
  bool requires_approval = 8;
  bool enabled = 9;
  google.protobuf.Timestamp created_at = 10;
}

message ParameterDefinition {
  string name = 1;
  string description = 2;
  ParameterType type = 3;
  bool required = 4;
  google.protobuf.Value default_value = 5;
  google.protobuf.Value min_value = 6;
  google.protobuf.Value max_value = 7;
  repeated google.protobuf.Value allowed_values = 8;
  string unit = 9;
}

enum ParameterType {
  PARAMETER_TYPE_UNSPECIFIED = 0;
  PARAMETER_TYPE_INT = 1;
  PARAMETER_TYPE_FLOAT = 2;
  PARAMETER_TYPE_STRING = 3;
  PARAMETER_TYPE_BOOL = 4;
  PARAMETER_TYPE_ENUM = 5;
  PARAMETER_TYPE_BYTES = 6;
}
```

## RPCs

### SubmitCommand

Submits a command for execution.

```protobuf
message SubmitCommandRequest {
  string satellite_id = 1 [(validate.rules).string.uuid = true];
  string mnemonic = 2 [(validate.rules).string = {min_len: 1, max_len: 50}];
  google.protobuf.Struct parameters = 3;
  string justification = 4 [(validate.rules).string.max_len = 1000];
  google.protobuf.Timestamp scheduled_for = 5;
  string pass_id = 6;
}
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `satellite_id` | string | Yes | Target satellite UUID |
| `mnemonic` | string | Yes | Command mnemonic |
| `parameters` | Struct | No | Command parameters |
| `justification` | string | Caution/Critical | Reason for command |
| `scheduled_for` | Timestamp | No | When to send (next pass if empty) |
| `pass_id` | string | No | Specific pass to use |

**Response:** `Command` with initial status

**Status Flow:**
```
SAFE command:        PENDING → QUEUED → SENT → ACKED
CAUTION command:     PENDING → QUEUED → SENT → ACKED
CRITICAL command:    PENDING → AWAITING_APPROVAL → APPROVED → QUEUED → SENT → ACKED
```

**Errors:**

| Code | Condition |
|------|-----------|
| `NOT_FOUND` | Satellite or command definition not found |
| `INVALID_ARGUMENT` | Parameter validation failed |
| `FAILED_PRECONDITION` | Satellite not operational |
| `PERMISSION_DENIED` | Missing `commands.submit` permission |

**Example:**

```bash
curl -X POST https://api.p9e.space/v1/satellites/{id}/commands \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "mnemonic": "SET_MODE",
    "parameters": {"mode": "NOMINAL"},
    "justification": "Restoring normal operations after anomaly investigation"
  }'
```

### ApproveCommand

Approves a command awaiting authorization.

```protobuf
message ApproveCommandRequest {
  string command_id = 1 [(validate.rules).string.uuid = true];
  string comment = 2;
}
```

**Authorization:** 
- User must have `commands.approve` permission
- User must NOT be the same as `submitted_by` (two-person rule)

**Errors:**

| Code | Condition |
|------|-----------|
| `NOT_FOUND` | Command not found |
| `FAILED_PRECONDITION` | Not in AWAITING_APPROVAL status |
| `PERMISSION_DENIED` | Same user as submitter, or missing permission |

### RejectCommand

Rejects a command with reason.

```protobuf
message RejectCommandRequest {
  string command_id = 1 [(validate.rules).string.uuid = true];
  string reason = 2 [(validate.rules).string = {min_len: 1, max_len: 1000}];
}
```

### ListCommands

Lists commands with filtering.

```protobuf
message ListCommandsRequest {
  string satellite_id = 1;
  common.v1.PageRequest page = 2;
  repeated CommandStatus status_filter = 3;
  repeated HazardLevel hazard_filter = 4;
  common.v1.TimeRange time_range = 5;
  string submitted_by = 6;
}

message ListCommandsResponse {
  repeated Command commands = 1;
  common.v1.PageInfo page_info = 2;
}
```

### GetCommandQueue

Gets the command queue for a satellite or pass.

```protobuf
message GetCommandQueueRequest {
  oneof scope {
    string satellite_id = 1;
    string pass_id = 2;
  }
}

message CommandQueue {
  string scope_id = 1;
  repeated QueuedCommand commands = 2;
  int32 total_count = 3;
}

message QueuedCommand {
  string command_id = 1;
  string mnemonic = 2;
  int32 position = 3;
  google.protobuf.Timestamp scheduled_for = 4;
  CommandStatus status = 5;
}
```

## Two-Person Authorization

Commands classified as `CRITICAL` require approval from a different user than the submitter.

### Flow

```
┌──────────────┐     ┌──────────────────────┐     ┌──────────────┐
│   Operator   │────▶│  Submit CRITICAL     │────▶│   AWAITING   │
│   (User A)   │     │  command             │     │   APPROVAL   │
└──────────────┘     └──────────────────────┘     └──────┬───────┘
                                                         │
                     ┌──────────────────────┐            │
                     │  REJECTED            │◀───────────┤ User B rejects
                     └──────────────────────┘            │
                                                         │
┌──────────────┐     ┌──────────────────────┐            │
│  Supervisor  │────▶│  Approve command     │◀───────────┘ User B approves
│   (User B)   │     │  (must be ≠ User A)  │
└──────────────┘     └──────────────────────┘
                              │
                              ▼
                     ┌──────────────────────┐
                     │      APPROVED        │
                     │  → QUEUED → SENT     │
                     └──────────────────────┘
```

### Configuration

```yaml
commands:
  authorization:
    safe:
      auto_approve: true
      requires_justification: false
    caution:
      auto_approve: true
      requires_justification: true
    critical:
      auto_approve: false
      requires_justification: true
      two_person_required: true
      approval_timeout_hours: 24
  
  expiry:
    default_hours: 72
    max_hours: 168
```

## Events

| Event | Trigger | Payload |
|-------|---------|---------|
| `command.submitted` | SubmitCommand | Command |
| `command.awaiting_approval` | CRITICAL submitted | Command |
| `command.approved` | ApproveCommand | Command, approver |
| `command.rejected` | RejectCommand | Command, reason |
| `command.queued` | Added to queue | Command, position |
| `command.sent` | Transmitted | Command, pass_id |
| `command.acked` | Acknowledgment received | Command, response |
| `command.failed` | Execution failed | Command, error |
| `command.expired` | TTL exceeded | Command |

## Metrics

| Metric | Type | Labels | Description |
|--------|------|--------|-------------|
| `commands_total` | Counter | satellite_id, status, hazard | Command count |
| `commands_pending` | Gauge | satellite_id | Pending commands |
| `command_approval_duration_seconds` | Histogram | hazard | Time to approve |
| `command_execution_duration_seconds` | Histogram | mnemonic | Send → ack time |
