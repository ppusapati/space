# TelemetryService API

> Real-time and historical telemetry data access

## Service Definition

```protobuf
service TelemetryService {
  // Real-time streaming
  rpc StreamTelemetry(StreamTelemetryRequest) returns (stream TelemetryFrame);
  rpc StreamParameters(StreamParametersRequest) returns (stream ParameterUpdate);
  
  // Historical queries
  rpc QueryTelemetry(QueryTelemetryRequest) returns (QueryTelemetryResponse);
  rpc GetLatestValues(GetLatestValuesRequest) returns (LatestValuesResponse);
  
  // Parameter definitions
  rpc GetParameter(GetParameterRequest) returns (ParameterDefinition);
  rpc ListParameters(ListParametersRequest) returns (ListParametersResponse);
  rpc CreateParameter(CreateParameterRequest) returns (ParameterDefinition);
  rpc UpdateParameter(UpdateParameterRequest) returns (ParameterDefinition);
  
  // Limit checking
  rpc GetParameterLimits(GetParameterLimitsRequest) returns (ParameterLimits);
  rpc UpdateParameterLimits(UpdateParameterLimitsRequest) returns (ParameterLimits);
  
  // Statistics
  rpc GetStatistics(GetStatisticsRequest) returns (TelemetryStatistics);
}
```

## Messages

### TelemetryFrame

```protobuf
message TelemetryFrame {
  string satellite_id = 1;
  google.protobuf.Timestamp timestamp = 2;
  int64 sequence_number = 3;
  bytes raw_data = 4;
  repeated ParameterValue parameters = 5;
  FrameQuality quality = 6;
  string pass_id = 7;
}

message ParameterValue {
  string parameter_id = 1;
  double value = 2;
  int64 raw_value = 3;
  TelemetryQuality quality = 4;
  google.protobuf.Timestamp timestamp = 5;
}

enum TelemetryQuality {
  TELEMETRY_QUALITY_UNSPECIFIED = 0;
  TELEMETRY_QUALITY_GOOD = 1;
  TELEMETRY_QUALITY_SUSPECT = 2;
  TELEMETRY_QUALITY_BAD = 3;
  TELEMETRY_QUALITY_MISSING = 4;
}

enum FrameQuality {
  FRAME_QUALITY_UNSPECIFIED = 0;
  FRAME_QUALITY_VALID = 1;
  FRAME_QUALITY_CRC_ERROR = 2;
  FRAME_QUALITY_SYNC_LOSS = 3;
  FRAME_QUALITY_PARTIAL = 4;
}
```

### ParameterDefinition

```protobuf
message ParameterDefinition {
  string id = 1;
  string satellite_id = 2;
  string name = 3;
  string mnemonic = 4;
  string description = 5;
  string subsystem = 6;
  ParameterType type = 7;
  string unit = 8;
  Calibration calibration = 9;
  ParameterLimits limits = 10;
  bool derived = 11;
  string derivation_expression = 12;
}

message Calibration {
  CalibrationType type = 1;
  repeated double coefficients = 2;  // Polynomial coefficients
  map<int64, double> points = 3;     // For point-pair calibration
  string expression = 4;              // For expression-based
}

enum CalibrationType {
  CALIBRATION_TYPE_UNSPECIFIED = 0;
  CALIBRATION_TYPE_NONE = 1;
  CALIBRATION_TYPE_POLYNOMIAL = 2;
  CALIBRATION_TYPE_POINT_PAIR = 3;
  CALIBRATION_TYPE_EXPRESSION = 4;
}
```

### ParameterLimits

```protobuf
message ParameterLimits {
  string parameter_id = 1;
  
  // Static limits (Red/Yellow zones)
  double red_low = 2;
  double yellow_low = 3;
  double yellow_high = 4;
  double red_high = 5;
  
  // Persistence before alerting
  int32 persistence_samples = 6;
}
```

## RPCs

### StreamTelemetry

Streams raw telemetry frames in real-time.

```protobuf
message StreamTelemetryRequest {
  string satellite_id = 1 [(validate.rules).string.uuid = true];
  bool include_raw = 2;
  bool decode_parameters = 3;
}
```

**Server Streaming:** Returns `TelemetryFrame` as received from ground station

**Example (Go client):**

```go
stream, err := client.StreamTelemetry(ctx, &StreamTelemetryRequest{
    SatelliteId:      satelliteID,
    DecodeParameters: true,
})
for {
    frame, err := stream.Recv()
    if err == io.EOF {
        break
    }
    for _, param := range frame.Parameters {
        fmt.Printf("%s = %.2f\n", param.ParameterId, param.Value)
    }
}
```

### QueryTelemetry

Queries historical telemetry data with aggregation.

```protobuf
message QueryTelemetryRequest {
  string satellite_id = 1;
  repeated string parameter_ids = 2;
  common.v1.TimeRange time_range = 3;
  
  // Aggregation
  AggregationType aggregation = 4;
  google.protobuf.Duration bucket_size = 5;  // e.g., "60s", "3600s"
  
  common.v1.PageRequest page = 6;
}

message QueryTelemetryResponse {
  repeated TimeSeries series = 1;
  common.v1.PageInfo page_info = 2;
}

message TimeSeries {
  string parameter_id = 1;
  string unit = 2;
  repeated DataPoint points = 3;
}

message DataPoint {
  google.protobuf.Timestamp timestamp = 1;
  double value = 2;
  double min = 3;
  double max = 4;
  int32 count = 5;
}

enum AggregationType {
  AGGREGATION_TYPE_RAW = 0;
  AGGREGATION_TYPE_AVG = 1;
  AGGREGATION_TYPE_MIN = 2;
  AGGREGATION_TYPE_MAX = 3;
}
```

**Example:**

```bash
curl "https://api.p9e.space/v1/satellites/{id}/telemetry/query" \
  -d '{
    "parameter_ids": ["EPS.BAT_VOLT"],
    "time_range": {"start": "2025-01-01T00:00:00Z", "end": "2025-01-02T00:00:00Z"},
    "aggregation": "AGGREGATION_TYPE_AVG",
    "bucket_size": "3600s"
  }'
```

### GetLatestValues

Gets the most recent value for each parameter.

```protobuf
message GetLatestValuesRequest {
  string satellite_id = 1;
  repeated string parameter_ids = 2;  // Empty = all
}

message LatestValuesResponse {
  repeated LatestValue values = 1;
  google.protobuf.Timestamp as_of = 2;
}

message LatestValue {
  string parameter_id = 1;
  double value = 2;
  string unit = 3;
  TelemetryQuality quality = 4;
  LimitStatus limit_status = 5;
  google.protobuf.Timestamp timestamp = 6;
}

enum LimitStatus {
  LIMIT_STATUS_NOMINAL = 0;
  LIMIT_STATUS_YELLOW_LOW = 1;
  LIMIT_STATUS_YELLOW_HIGH = 2;
  LIMIT_STATUS_RED_LOW = 3;
  LIMIT_STATUS_RED_HIGH = 4;
}
```

## Data Architecture

### TimescaleDB Hypertables

```
┌─────────────────────────────────────────────────────────────────┐
│                     TELEMETRY DATA FLOW                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  SDR ──▶ Decoder ──▶ NATS ──┬──▶ telemetry_raw (hypertable)    │
│                             │    └── Retained 7 days           │
│                             │                                   │
│                             ├──▶ telemetry_1min (aggregate)    │
│                             │    └── Retained 90 days          │
│                             │                                   │
│                             └──▶ telemetry_1hour (aggregate)   │
│                                  └── Retained 5 years          │
└─────────────────────────────────────────────────────────────────┘
```

### Query Resolution

| Time Range | Resolution | Source |
|------------|------------|--------|
| < 7 days | Raw | telemetry_raw |
| 7 - 90 days | 1 minute | telemetry_1min |
| > 90 days | 1 hour | telemetry_1hour |

## Events

| Event | Trigger | Payload |
|-------|---------|---------|
| `telemetry.frame_received` | Frame decoded | satellite_id, frame_id |
| `telemetry.limit_violation` | Limit exceeded | parameter_id, value, limit |
| `telemetry.gap_detected` | Missing data | satellite_id, duration |

## Metrics

| Metric | Type | Labels | Description |
|--------|------|--------|-------------|
| `telemetry_frames_total` | Counter | satellite_id, quality | Frames received |
| `telemetry_bytes_total` | Counter | satellite_id | Bytes received |
| `telemetry_latency_seconds` | Histogram | satellite_id | Receipt latency |
