# Alert Service API
> Package: `groundstation.v1`

## Service Definition
```protobuf
service AlertService {
  rpc ListAlerts(ListAlertsRequest) returns (ListAlertsResponse);
  rpc GetAlert(GetAlertRequest) returns (Alert);
  rpc AcknowledgeAlert(AcknowledgeAlertRequest) returns (Alert);
  rpc ResolveAlert(ResolveAlertRequest) returns (Alert);
  rpc SilenceAlert(SilenceAlertRequest) returns (Alert);
  rpc CreateAlertRule(CreateAlertRuleRequest) returns (AlertRule);
  rpc ListAlertRules(ListAlertRulesRequest) returns (ListAlertRulesResponse);
  rpc StreamAlerts(StreamAlertsRequest) returns (stream Alert);
}
```

## Messages
```protobuf
message Alert {
  string id = 1;
  string satellite_id = 2;
  AlertType type = 3;
  SeverityLevel severity = 4;
  AlertStatus status = 5;
  string title = 6;
  string description = 7;
  google.protobuf.Timestamp triggered_at = 8;
  google.protobuf.Timestamp acknowledged_at = 9;
}
```
