# Satellite Service API
> Package: `groundstation.v1`

## Service Definition
```protobuf
service SatelliteService {
  rpc CreateSatellite(CreateSatelliteRequest) returns (Satellite);
  rpc GetSatellite(GetSatelliteRequest) returns (Satellite);
  rpc UpdateSatellite(UpdateSatelliteRequest) returns (Satellite);
  rpc DeleteSatellite(DeleteSatelliteRequest) returns (google.protobuf.Empty);
  rpc ListSatellites(ListSatellitesRequest) returns (ListSatellitesResponse);
  rpc GetLatestTLE(GetLatestTLERequest) returns (TLE);
  rpc ListTLEHistory(ListTLEHistoryRequest) returns (ListTLEHistoryResponse);
  rpc RefreshTLE(RefreshTLERequest) returns (TLE);
}
```

## Messages
```protobuf
message Satellite {
  string id = 1;
  string tenant_id = 2;
  int32 norad_id = 3;
  string cospar_id = 4;
  string name = 5;
  MissionType mission_type = 6;
  SatelliteStatus status = 7;
  double downlink_freq_mhz = 8;
  double uplink_freq_mhz = 9;
  TLE latest_tle = 10;
}

message TLE {
  string line1 = 1;
  string line2 = 2;
  google.protobuf.Timestamp epoch = 3;
  string source = 4;
}
```
