# Ground Station Module - High-Level Design

## Overview

The Ground Station module manages satellite tracking, telemetry acquisition, command uplink, and anomaly detection.

## Component Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       GROUND STATION MODULE                                 │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                         API LAYER                                    │   │
│  │  ┌───────────┐ ┌───────────┐ ┌───────────┐ ┌───────────┐           │   │
│  │  │ Satellite │ │   Pass    │ │ Telemetry │ │  Command  │           │   │
│  │  │  Service  │ │  Service  │ │  Service  │ │  Service  │           │   │
│  │  └─────┬─────┘ └─────┬─────┘ └─────┬─────┘ └─────┬─────┘           │   │
│  └────────┼─────────────┼─────────────┼─────────────┼───────────────────┘   │
│           │             │             │             │                       │
│  ┌────────┼─────────────┼─────────────┼─────────────┼───────────────────┐   │
│  │        ▼             ▼             ▼             ▼                   │   │
│  │                    APPLICATION LAYER                                 │   │
│  │  ┌───────────────────────────────────────────────────────────────┐  │   │
│  │  │                    Pass Aggregate                              │  │   │
│  │  │  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐             │  │   │
│  │  │  │Schedule │ │Execution│ │Commands │ │ Report  │             │  │   │
│  │  │  └─────────┘ └─────────┘ └─────────┘ └─────────┘             │  │   │
│  │  └───────────────────────────────────────────────────────────────┘  │   │
│  │                                                                      │   │
│  │  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐                   │   │
│  │  │  TLE       │ │  Telemetry  │ │  Command    │                   │   │
│  │  │  Manager   │ │  Pipeline   │ │  Workflow   │                   │   │
│  │  └─────────────┘ └─────────────┘ └─────────────┘                   │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │                    INFRASTRUCTURE LAYER                              │   │
│  │  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐       │   │
│  │  │PostgreSQL│ │Timescale│ │  NATS   │ │  SDR    │ │ Antenna │       │   │
│  │  │         │ │   DB    │ │JetStream│ │Interface│ │Controller│      │   │
│  │  └─────────┘ └─────────┘ └─────────┘ └─────────┘ └─────────┘       │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Core Components

### Pass Aggregate

The Pass Aggregate is the central domain model for managing satellite contact windows.

```go
type PassAggregate struct {
    Pass          *Pass
    Execution     *PassExecution
    CommandQueue  []*Command
    TelemetryGaps []TimeRange
    Report        *PassReport
}

// Invariants:
// - Pass.LOS > Pass.AOS
// - Execution.Status follows state machine
// - Commands only queued when Pass.Status == SCHEDULED or CONFIRMED
```

### Pass State Machine

```
                    ┌──────────────┐
         ┌─────────│  PREDICTED   │
         │         └──────┬───────┘
         │                │ schedule()
         │                ▼
         │         ┌──────────────┐
         │    ┌────│  SCHEDULED   │────┐
         │    │    └──────┬───────┘    │
         │    │           │ confirm()  │ cancel()
         │    │           ▼            │
         │    │    ┌──────────────┐    │
         │    │    │  CONFIRMED   │────┤
         │    │    └──────┬───────┘    │
         │    │           │ T-30min    │
         │    │           ▼            │
         │    │    ┌──────────────┐    │
         │    │    │  PREPARING   │────┤
         │    │    └──────┬───────┘    │
         │    │           │ AOS        │
         │    │           ▼            ▼
         │    │    ┌──────────────┐ ┌──────────────┐
         │    │    │ IN_PROGRESS  │ │  CANCELLED   │
         │    │    └──────┬───────┘ └──────────────┘
         │    │           │ LOS
         │    │           ▼
         │    │    ┌──────────────┐
         └────┴───▶│  COMPLETED   │
                   └──────────────┘
                          │ error
                          ▼
                   ┌──────────────┐
                   │    FAILED    │
                   └──────────────┘
```

### TLE Manager

Manages Two-Line Element sets for orbit prediction.

```go
type TLEManager struct {
    repo        TLERepository
    spaceTrack  SpaceTrackClient
    propagator  Propagator
}

func (m *TLEManager) RefreshTLE(satelliteID string) error {
    // 1. Fetch from Space-Track
    tle, err := m.spaceTrack.GetTLE(satelliteID)
    if err != nil {
        return err
    }
    
    // 2. Validate TLE age
    if time.Since(tle.Epoch) > 72*time.Hour {
        log.Warn("TLE is stale", "age", time.Since(tle.Epoch))
    }
    
    // 3. Store in repository
    return m.repo.Save(satelliteID, tle)
}

func (m *TLEManager) PredictPasses(
    satelliteID string,
    gsID string,
    timeRange TimeRange,
) ([]PassPrediction, error) {
    tle, _ := m.repo.GetLatest(satelliteID)
    gs, _ := m.getGroundStation(gsID)
    
    return m.propagator.PredictPasses(tle, gs, timeRange)
}
```

### Command Workflow

Two-person authorization workflow for critical commands.

```go
type CommandWorkflow struct {
    repo          CommandRepository
    definitions   CommandDefinitionRepository
    notifications NotificationService
}

func (w *CommandWorkflow) Submit(cmd *Command) error {
    // 1. Validate against definition
    def, _ := w.definitions.Get(cmd.Mnemonic)
    if err := w.validate(cmd, def); err != nil {
        return err
    }
    
    // 2. Set hazard level
    cmd.HazardLevel = def.HazardLevel
    
    // 3. Auto-approve SAFE commands
    if cmd.HazardLevel == HazardLevelSafe {
        cmd.Status = CommandStatusQueued
    } else if cmd.HazardLevel == HazardLevelCritical {
        cmd.Status = CommandStatusAwaitingApproval
        w.notifications.NotifyApprovers(cmd)
    } else {
        cmd.Status = CommandStatusPending
    }
    
    return w.repo.Save(cmd)
}

func (w *CommandWorkflow) Approve(cmdID, approverID string) error {
    cmd, _ := w.repo.Get(cmdID)
    
    // Enforce two-person rule
    if cmd.SubmittedBy == approverID {
        return ErrSameUserApproval
    }
    
    cmd.ApprovedBy = approverID
    cmd.ApprovedAt = time.Now()
    cmd.Status = CommandStatusApproved
    
    return w.repo.Save(cmd)
}
```

## Sequences

### Pass Execution Sequence

```
┌────────┐    ┌────────┐    ┌────────┐    ┌────────┐    ┌────────┐
│Scheduler│   │Executor│    │Antenna │    │  SDR   │    │Pipeline│
└───┬────┘    └───┬────┘    └───┬────┘    └───┬────┘    └───┬────┘
    │             │             │             │             │
    │ T-30min     │             │             │             │
    │────────────▶│             │             │             │
    │             │ Point       │             │             │
    │             │────────────▶│             │             │
    │             │             │◀────────────│             │
    │             │             │ Tracking    │             │
    │             │ Configure   │             │             │
    │             │─────────────┼────────────▶│             │
    │             │             │             │             │
    │ AOS         │             │             │             │
    │────────────▶│             │             │             │
    │             │ Start capture             │             │
    │             │─────────────┼────────────▶│             │
    │             │             │             │────────────▶│
    │             │             │             │  Telemetry  │
    │             │             │             │────────────▶│
    │             │             │             │             │
    │ LOS         │             │             │             │
    │────────────▶│             │             │             │
    │             │ Stop capture│             │             │
    │             │─────────────┼────────────▶│             │
    │             │ Park        │             │             │
    │             │────────────▶│             │             │
    │             │             │             │             │
```

## Error Handling

| Error Type | Handling Strategy |
|------------|-------------------|
| TLE too old | Alert, use prediction with lower confidence |
| SDR failure | Abort pass, alert operator |
| Antenna fault | Safe mode, alert maintenance |
| Frame decode error | Skip frame, log, continue |
| Command NACK | Retry once, then escalate |
| Database failure | Buffer locally, retry |

## Security Considerations

1. **Command Authorization**
   - All critical commands require two-person approval
   - Approver must have `commands.approve` permission
   - Approver must be different from submitter

2. **Telemetry Access**
   - Row-level security on all queries
   - Real-time streams filtered by tenant

3. **Hardware Access**
   - SDR and antenna controls isolated
   - All commands logged
