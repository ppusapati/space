# Sentinel Hub Integration

## Overview
ESA Copernicus imagery via Sentinel Hub APIs.

## Configuration
- **Base URL**: https://services.sentinel-hub.com
- **Auth**: OAuth 2.0 Client Credentials
- **Rate Limit**: 300 requests/minute

## APIs Used
- Catalog API (STAC)
- Process API (custom evalscripts)
- Statistical API (time-series stats)

## Implementation
```go
type SentinelHubClient struct {
    baseURL      string
    clientID     string
    clientSecret string
    token        *oauth2.Token
}

func (c *SentinelHubClient) SearchCatalog(ctx context.Context, req SearchRequest) ([]Item, error) {
    // STAC search
}

func (c *SentinelHubClient) Process(ctx context.Context, bbox BBox, evalscript string) ([]byte, error) {
    // Custom processing
}
```
