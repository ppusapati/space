# Object Storage Integration

## Overview
S3/MinIO for imagery and artifact storage.

## Bucket Structure
```
p9e-{env}-imagery/
├── collections/{collection_id}/
│   └── {item_id}/
│       ├── thumbnail.png
│       └── {asset_key}.tif

p9e-{env}-ml-artifacts/
├── models/{model_id}/{version}/
│   └── model.onnx
└── datasets/{dataset_id}/
```

## Lifecycle Policies
| Bucket | Transition | Action |
|--------|------------|--------|
| imagery | 90 days | → STANDARD_IA |
| imagery | 365 days | → GLACIER |
| ml-artifacts | - | No tiering |
