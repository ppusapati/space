# Collection Aggregate

## Structure
```
CollectionAggregate
├── Collection (root)
│   ├── ID, StacID, Title
│   ├── ExtentSpatial, ExtentTemporal
│   └── ItemCount
└── Items[]
    ├── ID, StacID, Geometry
    ├── DateTime, Properties
    └── Assets[]
```

## STAC Compliance
Implements OGC STAC 1.0.0 specification.
