# Earth Observation Module

> Imagery Catalog, Processing Pipelines & ML Inference

## Services

| Service | RPCs | Description |
|---------|------|-------------|
| [CatalogService](./api/catalog-service.md) | 7 | STAC catalog search |
| [ProcessingService](./api/processing-service.md) | 8 | Image processing |
| [MLService](./api/ml-service.md) | 10 | Model inference |
| **Total** | **25** | |

## Key Concepts

### STAC Compliance
- **Collections**: Groups of related items (e.g., Sentinel-2 L2A)
- **Items**: Individual scenes with metadata
- **Assets**: Actual data files (COG, GeoTIFF)

### Processing Pipelines
- Orthorectification
- Pansharpening
- Atmospheric correction
- Index calculation (NDVI, NDWI)
- Mosaicking

### ML Workflows
- Model registration and versioning
- Batch and streaming inference
- Object detection, classification, segmentation

## Job States
```
PENDING → RUNNING → COMPLETED
                  → FAILED → RETRYING
       → CANCELLED
```

## Data Model
| Table | Description |
|-------|-------------|
| collections | STAC collections |
| items | STAC items |
| assets | Item assets |
| processing_jobs | Job queue |
| models | ML models |
| model_versions | Model versions |
