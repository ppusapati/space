# EO Module - Data Model

## Tables

### collections
```sql
CREATE TABLE eo.collections (
    id UUID PRIMARY KEY,
    tenant_id UUID NOT NULL,
    stac_id VARCHAR(255) NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    extent_spatial GEOMETRY(POLYGON, 4326),
    extent_temporal TSTZRANGE,
    item_count INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT unique_stac_id UNIQUE (tenant_id, stac_id)
);
```

### items
```sql
CREATE TABLE eo.items (
    id UUID PRIMARY KEY,
    tenant_id UUID NOT NULL,
    collection_id UUID NOT NULL REFERENCES eo.collections(id),
    stac_id VARCHAR(255) NOT NULL,
    geometry GEOMETRY(GEOMETRY, 4326) NOT NULL,
    datetime TIMESTAMPTZ NOT NULL,
    properties JSONB NOT NULL DEFAULT '{}',
    cloud_cover DECIMAL(5,2)
);

CREATE INDEX idx_items_geometry ON eo.items USING GIST (geometry);
CREATE INDEX idx_items_datetime ON eo.items (datetime DESC);
```

### processing_jobs
```sql
CREATE TABLE eo.processing_jobs (
    id UUID PRIMARY KEY,
    tenant_id UUID NOT NULL,
    workflow_id VARCHAR(100) NOT NULL,
    input_items UUID[] NOT NULL,
    parameters JSONB NOT NULL DEFAULT '{}',
    status job_status NOT NULL DEFAULT 'pending',
    progress INTEGER NOT NULL DEFAULT 0,
    output_items UUID[],
    error TEXT,
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ
);
```

### models
```sql
CREATE TABLE eo.models (
    id UUID PRIMARY KEY,
    tenant_id UUID NOT NULL,
    name VARCHAR(255) NOT NULL,
    type model_type NOT NULL,
    description TEXT,
    latest_version_id UUID,
    status model_status NOT NULL DEFAULT 'draft'
);
```
