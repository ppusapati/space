# ML Service API
> Package: `eo.v1`

```protobuf
service MLService {
  rpc CreateModel(CreateModelRequest) returns (Model);
  rpc GetModel(GetModelRequest) returns (Model);
  rpc ListModels(ListModelsRequest) returns (ListModelsResponse);
  rpc CreateModelVersion(CreateModelVersionRequest) returns (ModelVersion);
  rpc DeployModel(DeployModelRequest) returns (Deployment);
  rpc UndeployModel(UndeployModelRequest) returns (google.protobuf.Empty);
  rpc RunInference(RunInferenceRequest) returns (InferenceResult);
  rpc BatchInference(BatchInferenceRequest) returns (BatchJob);
  rpc GetDeploymentStatus(GetDeploymentStatusRequest) returns (DeploymentStatus);
  rpc ListDeployments(ListDeploymentsRequest) returns (ListDeploymentsResponse);
}
```

## Model Types
- OBJECT_DETECTION
- CLASSIFICATION
- SEGMENTATION
- CHANGE_DETECTION
