# Processing Service API
> Package: `eo.v1`

```protobuf
service ProcessingService {
  rpc CreateJob(CreateJobRequest) returns (Job);
  rpc GetJob(GetJobRequest) returns (Job);
  rpc ListJobs(ListJobsRequest) returns (ListJobsResponse);
  rpc CancelJob(CancelJobRequest) returns (Job);
  rpc RetryJob(RetryJobRequest) returns (Job);
  rpc ListWorkflows(ListWorkflowsRequest) returns (ListWorkflowsResponse);
  rpc GetWorkflow(GetWorkflowRequest) returns (Workflow);
  rpc StreamJobProgress(StreamJobProgressRequest) returns (stream JobProgress);
}
```

## Workflows
| Workflow | Description |
|----------|-------------|
| orthorectify | Terrain correction |
| pansharpen | Resolution enhancement |
| atmospheric | Atmospheric correction |
| ndvi | NDVI calculation |
| mosaic | Multi-image mosaicking |
