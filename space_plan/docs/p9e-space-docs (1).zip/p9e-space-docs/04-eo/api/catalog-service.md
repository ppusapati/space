# CatalogService API

> STAC-compliant Earth Observation catalog management

## Service Definition

```protobuf
service CatalogService {
  // Collections (STAC Collection)
  rpc CreateCollection(CreateCollectionRequest) returns (Collection);
  rpc GetCollection(GetCollectionRequest) returns (Collection);
  rpc UpdateCollection(UpdateCollectionRequest) returns (Collection);
  rpc DeleteCollection(DeleteCollectionRequest) returns (google.protobuf.Empty);
  rpc ListCollections(ListCollectionsRequest) returns (ListCollectionsResponse);
  
  // Items (STAC Item)
  rpc CreateItem(CreateItemRequest) returns (Item);
  rpc GetItem(GetItemRequest) returns (Item);
  rpc UpdateItem(UpdateItemRequest) returns (Item);
  rpc DeleteItem(DeleteItemRequest) returns (google.protobuf.Empty);
  rpc SearchItems(SearchItemsRequest) returns (SearchItemsResponse);
  
  // Assets
  rpc GetAsset(GetAssetRequest) returns (Asset);
  rpc ListAssets(ListAssetsRequest) returns (ListAssetsResponse);
  rpc GetAssetDownloadUrl(GetAssetDownloadUrlRequest) returns (AssetDownloadUrl);
  
  // Bulk operations
  rpc BulkIngestItems(BulkIngestItemsRequest) returns (BulkIngestItemsResponse);
}
```

## Messages

### Collection

STAC Collection representing a group of related items.

```protobuf
message Collection {
  string id = 1;
  string tenant_id = 2;
  string stac_version = 3;  // "1.0.0"
  string type = 4;          // "Collection"
  string title = 5;
  string description = 6;
  repeated string keywords = 7;
  string license = 8;
  
  // Spatial extent
  BoundingBox bbox = 9;
  
  // Temporal extent
  TimeRange temporal_extent = 10;
  
  // Provider info
  repeated Provider providers = 11;
  
  // Additional properties
  google.protobuf.Struct properties = 12;
  
  // Links
  repeated Link links = 13;
  
  // Statistics
  int64 item_count = 14;
  google.protobuf.Timestamp created_at = 15;
  google.protobuf.Timestamp updated_at = 16;
}

message Provider {
  string name = 1;
  string description = 2;
  repeated string roles = 3;  // "producer", "processor", "host"
  string url = 4;
}

message Link {
  string href = 1;
  string rel = 2;    // "self", "root", "parent", "child", "item"
  string type = 3;   // MIME type
  string title = 4;
}
```

### Item

STAC Item representing a single scene/granule.

```protobuf
message Item {
  string id = 1;
  string tenant_id = 2;
  string stac_version = 3;
  string type = 4;           // "Feature"
  string collection_id = 5;
  
  // Geometry (GeoJSON)
  GeoJSON geometry = 6;
  BoundingBox bbox = 7;
  
  // Core properties
  google.protobuf.Timestamp datetime = 8;
  google.protobuf.Timestamp start_datetime = 9;
  google.protobuf.Timestamp end_datetime = 10;
  
  // Common metadata
  string platform = 11;       // "sentinel-2a"
  string constellation = 12;  // "sentinel-2"
  repeated string instruments = 13;
  double gsd = 14;           // Ground sample distance (meters)
  double cloud_cover = 15;   // 0-100%
  double sun_elevation = 16;
  double sun_azimuth = 17;
  double view_angle = 18;
  
  // Processing info
  string processing_level = 19;  // "L1C", "L2A"
  
  // Additional properties
  google.protobuf.Struct properties = 20;
  
  // Assets
  map<string, Asset> assets = 21;
  
  // Links
  repeated Link links = 22;
  
  google.protobuf.Timestamp created_at = 23;
  google.protobuf.Timestamp updated_at = 24;
}

message GeoJSON {
  string type = 1;        // "Polygon", "MultiPolygon"
  bytes coordinates = 2;  // JSON-encoded coordinates
}

message BoundingBox {
  double west = 1;   // Min longitude
  double south = 2;  // Min latitude
  double east = 3;   // Max longitude
  double north = 4;  // Max latitude
}
```

### Asset

STAC Asset representing a downloadable file.

```protobuf
message Asset {
  string key = 1;           // "visual", "B04", "thumbnail"
  string href = 2;          // S3 or HTTP URL
  string title = 3;
  string description = 4;
  string type = 5;          // MIME type
  repeated string roles = 6; // "data", "thumbnail", "overview", "metadata"
  
  // File info
  int64 file_size_bytes = 7;
  string checksum = 8;      // SHA-256
  
  // Raster info (for COGs)
  RasterInfo raster = 9;
  
  // EO Band info
  repeated Band bands = 10;
}

message RasterInfo {
  int32 width = 1;
  int32 height = 2;
  string dtype = 3;        // "uint16", "float32"
  int32 band_count = 4;
  string crs = 5;          // "EPSG:32633"
  repeated double transform = 6;  // Affine transform
}

message Band {
  string name = 1;
  string common_name = 2;   // "red", "green", "blue", "nir"
  double center_wavelength = 3;
  double full_width_half_max = 4;
}
```

## RPCs

### SearchItems

STAC-compliant search with spatial, temporal, and property filters.

```protobuf
message SearchItemsRequest {
  // Collections to search
  repeated string collection_ids = 1;
  
  // Spatial filter (GeoJSON geometry)
  oneof spatial {
    BoundingBox bbox = 2;
    GeoJSON intersects = 3;
  }
  
  // Temporal filter
  oneof temporal {
    TimeRange datetime_range = 4;
    google.protobuf.Timestamp datetime = 5;
  }
  
  // Property filters (CQL2)
  string filter = 6;
  string filter_lang = 7;  // "cql2-json" or "cql2-text"
  
  // Sorting
  repeated SortBy sortby = 8;
  
  // Pagination
  int32 limit = 9;
  string token = 10;
  
  // Field selection
  repeated string fields = 11;
}

message SortBy {
  string field = 1;
  SortDirection direction = 2;
}

message SearchItemsResponse {
  string type = 1;  // "FeatureCollection"
  repeated Item features = 2;
  int32 number_matched = 3;
  int32 number_returned = 4;
  string next_token = 5;
  repeated Link links = 6;
}
```

**Example: Search by bounding box and cloud cover**

```bash
curl "https://api.p9e.space/v1/catalog/search" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "collection_ids": ["sentinel-2-l2a"],
    "bbox": {"west": 77.5, "south": 12.9, "east": 77.7, "north": 13.1},
    "datetime_range": {
      "start": "2025-01-01T00:00:00Z",
      "end": "2025-01-31T23:59:59Z"
    },
    "filter": "cloud_cover < 20",
    "filter_lang": "cql2-text",
    "limit": 10,
    "sortby": [{"field": "datetime", "direction": "SORT_DIRECTION_DESC"}]
  }'
```

### CreateCollection

Creates a new collection.

```protobuf
message CreateCollectionRequest {
  string id = 1 [(validate.rules).string = {pattern: "^[a-z0-9-]+$"}];
  string title = 2;
  string description = 3;
  repeated string keywords = 4;
  string license = 5;
  repeated Provider providers = 6;
  google.protobuf.Struct properties = 7;
}
```

**Authorization:** `catalog.collections.create`

### BulkIngestItems

Bulk ingests multiple items.

```protobuf
message BulkIngestItemsRequest {
  string collection_id = 1;
  repeated ItemInput items = 2;
  bool skip_validation = 3;
}

message ItemInput {
  string id = 1;
  GeoJSON geometry = 2;
  google.protobuf.Timestamp datetime = 3;
  google.protobuf.Struct properties = 4;
  map<string, AssetInput> assets = 5;
}

message BulkIngestItemsResponse {
  int32 total = 1;
  int32 succeeded = 2;
  int32 failed = 3;
  repeated IngestError errors = 4;
}

message IngestError {
  string item_id = 1;
  string error = 2;
}
```

### GetAssetDownloadUrl

Generates a presigned download URL.

```protobuf
message GetAssetDownloadUrlRequest {
  string item_id = 1;
  string asset_key = 2;
  int32 expiry_seconds = 3;  // Default: 3600
}

message AssetDownloadUrl {
  string url = 1;
  google.protobuf.Timestamp expires_at = 2;
}
```

## STAC Extensions Supported

| Extension | Description |
|-----------|-------------|
| `eo` | Electro-Optical (bands, cloud cover) |
| `sat` | Satellite (orbit, platform) |
| `view` | View geometry (angles) |
| `proj` | Projection (CRS, transform) |
| `raster` | Raster info (statistics) |
| `processing` | Processing info |

## Events

| Event | Trigger | Payload |
|-------|---------|---------|
| `catalog.collection.created` | CreateCollection | Collection |
| `catalog.item.created` | CreateItem | Item |
| `catalog.item.updated` | UpdateItem | Item, changes |
| `catalog.bulk_ingest.completed` | BulkIngestItems | collection_id, counts |

## Metrics

| Metric | Type | Labels | Description |
|--------|------|--------|-------------|
| `catalog_items_total` | Gauge | collection_id | Item count |
| `catalog_search_duration_seconds` | Histogram | collection_id | Search latency |
| `catalog_search_results` | Histogram | collection_id | Results per search |
| `catalog_ingest_total` | Counter | collection_id, status | Ingest count |
