# P9E Space Technology Platform

> **Chetana Space Technologies Division** - P9E Microsystems Pvt Ltd

## Overview

The P9E Space Technology Platform is a comprehensive, multi-tenant satellite operations platform providing end-to-end capabilities for ground station management, satellite operations, Earth observation processing, and geospatial intelligence analysis.

## Documentation Structure

```
docs/
├── 00-architecture/     # Enterprise-level cross-cutting concerns
├── 01-platform/         # Identity, Tenant, User, Audit, Notifications
├── 02-groundstation/    # Satellite tracking, Passes, Telemetry, Commands
├── 03-satellite/        # Spacecraft management, Flight dynamics
├── 04-eo/               # Earth Observation catalog, processing, ML
├── 05-geoint/           # AOI, Analysis, Reports, Workspaces
├── 06-common/           # Shared services, types, patterns
└── 07-operations/       # Deployment, monitoring, runbooks
```

## Module Overview

| Module | Services | Description | Primary Users |
|--------|----------|-------------|---------------|
| [Platform](./01-platform/) | 5 | Multi-tenant identity, access control, audit | All users |
| [Ground Station](./02-groundstation/) | 7 | Satellite tracking, pass scheduling, TM/TC | GS Operators |
| [Satellite](./03-satellite/) | 2 | Spacecraft config, flight dynamics, conjunctions | Flight Dynamics |
| [Earth Observation](./04-eo/) | 3 | Imagery catalog, processing pipelines, ML inference | EO Analysts |
| [GEOINT](./05-geoint/) | 4 | AOI monitoring, analysis, reporting, collaboration | Intelligence Analysts |
| [Common](./06-common/) | 4 | Export, dashboards, scheduling, health | All services |

## Quick Links

### Architecture
- [System Overview](./00-architecture/system-overview.md)
- [Security Architecture](./00-architecture/security-architecture.md)
- [Data Architecture](./00-architecture/data-architecture.md)
- [Integration Patterns](./00-architecture/integration-patterns.md)
- [Observability](./00-architecture/observability.md)
- [Architecture Decision Records](./00-architecture/adr/)

### API Reference
- [Platform APIs](./01-platform/api/)
- [Ground Station APIs](./02-groundstation/api/)
- [Satellite APIs](./03-satellite/api/)
- [EO APIs](./04-eo/api/)
- [GEOINT APIs](./05-geoint/api/)

### Operations
- [Deployment Guide](./07-operations/deployment.md)
- [Monitoring](./07-operations/monitoring.md)
- [Runbooks](./07-operations/runbooks/)

## Technology Stack

| Layer | Technology |
|-------|------------|
| **Frontend** | SvelteKit 2.x, Tailwind CSS, MapLibre GL |
| **Desktop** | Tauri 2.x (Rust) |
| **API** | ConnectRPC (gRPC + gRPC-Web + HTTP/JSON) |
| **Backend** | Go 1.23, Clean Architecture |
| **Database** | PostgreSQL 16 + TimescaleDB + PostGIS |
| **Cache** | Redis 7.x (Dragonfly compatible) |
| **Messaging** | NATS JetStream |
| **Storage** | S3 / MinIO |
| **Auth** | JWT + OIDC Federation |
| **Observability** | OpenTelemetry, Prometheus, Grafana, Loki |

## Service Summary

| Package | Services | RPCs | Description |
|---------|----------|------|-------------|
| `platform.v1` | 5 | 43 | Identity, Tenant, User, Audit, Notification |
| `groundstation.v1` | 7 | 52 | Satellite, GS, Pass, Telemetry, Command, Anomaly, Alert |
| `satellite.v1` | 2 | 18 | Spacecraft, FlightDynamics |
| `eo.v1` | 3 | 25 | Catalog, Processing, ML |
| `geoint.v1` | 4 | 32 | AOI, Analysis, Report, Workspace |
| `common.v1` | 4 | 25 | Export, Dashboard, Scheduler, Health |
| **Total** | **25** | **195** | |

## Database Summary

| Module | Tables | Key Entities |
|--------|--------|--------------|
| Platform | 12 | users, tenants, roles, sessions, audit_logs |
| Ground Station | 15 | satellites, ground_stations, passes, telemetry, commands |
| Satellite | 8 | spacecraft, subsystems, orbit_states, maneuvers, conjunctions |
| EO | 10 | collections, items, assets, processing_jobs, models |
| GEOINT | 10 | aois, observations, patterns, reports, workspaces |
| **Total** | **55** | |

---

**P9E Microsystems Pvt Ltd** | Chetana Space Technologies Division
