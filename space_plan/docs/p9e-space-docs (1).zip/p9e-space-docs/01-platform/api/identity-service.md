# Identity Service API

> Package: `platform.v1`

## Service Definition

```protobuf
service IdentityService {
  rpc Login(LoginRequest) returns (LoginResponse);
  rpc RefreshToken(RefreshTokenRequest) returns (TokenPair);
  rpc Logout(LogoutRequest) returns (google.protobuf.Empty);
  rpc RequestPasswordReset(RequestPasswordResetRequest) returns (google.protobuf.Empty);
  rpc ResetPassword(ResetPasswordRequest) returns (google.protobuf.Empty);
  rpc ChangePassword(ChangePasswordRequest) returns (google.protobuf.Empty);
  rpc EnrollMFA(EnrollMFARequest) returns (EnrollMFAResponse);
  rpc VerifyMFA(VerifyMFARequest) returns (TokenPair);
  rpc DisableMFA(DisableMFARequest) returns (google.protobuf.Empty);
  rpc GetCurrentUser(google.protobuf.Empty) returns (User);
  rpc ListSessions(ListSessionsRequest) returns (ListSessionsResponse);
  rpc RevokeSession(RevokeSessionRequest) returns (google.protobuf.Empty);
}
```

## RPCs

### Login

```protobuf
message LoginRequest {
  string email = 1;
  string password = 2;
  string device_id = 3;
}

message LoginResponse {
  oneof result {
    TokenPair tokens = 1;
    MFAChallenge mfa_challenge = 2;
  }
}

message TokenPair {
  string access_token = 1;
  string refresh_token = 2;
  int32 expires_in = 3;
  string token_type = 4;
}
```

**HTTP:** `POST /v1/auth/login`

**Errors:**
| Code | Description |
|------|-------------|
| INVALID_ARGUMENT | Invalid email/password format |
| UNAUTHENTICATED | Invalid credentials |
| FAILED_PRECONDITION | Account locked |

### RefreshToken

```protobuf
message RefreshTokenRequest {
  string refresh_token = 1;
}
```

**HTTP:** `POST /v1/auth/refresh`

**Behavior:** Single-use token rotation

### EnrollMFA

```protobuf
message EnrollMFARequest {
  MFAMethod method = 1; // TOTP, WEBAUTHN
}

message EnrollMFAResponse {
  string secret = 1;
  string qr_code_uri = 2;
  repeated string backup_codes = 3;
}
```

**HTTP:** `POST /v1/auth/mfa/enroll` (Authenticated)

### VerifyMFA

```protobuf
message VerifyMFARequest {
  string session_id = 1;
  string code = 2;
}
```

**HTTP:** `POST /v1/auth/mfa/verify`

## Rate Limits

| Endpoint | Limit |
|----------|-------|
| Login | 10/min per IP |
| VerifyMFA | 5/min per session |
| PasswordReset | 3/hour per email |
