# Audit Service API

> Package: `platform.v1`

## Service Definition

```protobuf
service AuditService {
  rpc ListAuditLogs(ListAuditLogsRequest) returns (ListAuditLogsResponse);
  rpc GetAuditLog(GetAuditLogRequest) returns (AuditLog);
  rpc SearchAuditLogs(SearchAuditLogsRequest) returns (ListAuditLogsResponse);
  rpc ExportAuditLogs(ExportAuditLogsRequest) returns (Export);
  rpc VerifyIntegrity(VerifyIntegrityRequest) returns (IntegrityReport);
}
```

## Messages

```protobuf
message AuditLog {
  string id = 1;
  string tenant_id = 2;
  string user_id = 3;
  string session_id = 4;
  string action = 5;
  string resource_type = 6;
  string resource_id = 7;
  AuditOutcome outcome = 8;
  google.protobuf.Struct details = 9;
  string ip_address = 10;
  google.protobuf.Timestamp timestamp = 11;
  string signature = 12;
}

message SearchAuditLogsRequest {
  string user_id = 1;
  string action = 2;
  string resource_type = 3;
  common.v1.TimeRange time_range = 4;
  AuditOutcome outcome = 5;
  common.v1.PageRequest pagination = 6;
}
```

## Audit Actions

| Action | Description |
|--------|-------------|
| user.login | User logged in |
| user.logout | User logged out |
| user.mfa_enrolled | MFA enabled |
| user.created | User created |
| role.assigned | Role assigned |
| command.submitted | Command submitted |
| command.approved | Command approved |
| pass.scheduled | Pass scheduled |

## VerifyIntegrity

Verifies hash chain integrity for compliance audits.

```protobuf
message IntegrityReport {
  bool valid = 1;
  int64 total_records = 2;
  int64 verified_records = 3;
  repeated IntegrityViolation violations = 4;
}
```
