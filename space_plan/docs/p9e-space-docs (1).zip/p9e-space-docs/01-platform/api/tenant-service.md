# Tenant Service API

> Package: `platform.v1`

## Service Definition

```protobuf
service TenantService {
  rpc CreateTenant(CreateTenantRequest) returns (Tenant);
  rpc GetTenant(GetTenantRequest) returns (Tenant);
  rpc UpdateTenant(UpdateTenantRequest) returns (Tenant);
  rpc ListTenants(ListTenantsRequest) returns (ListTenantsResponse);
  rpc SuspendTenant(SuspendTenantRequest) returns (Tenant);
  rpc ActivateTenant(ActivateTenantRequest) returns (Tenant);
  rpc GetQuotaUsage(GetQuotaUsageRequest) returns (QuotaUsage);
  rpc UpdateQuotas(UpdateQuotasRequest) returns (Tenant);
  rpc ConfigureIdP(ConfigureIdPRequest) returns (IdPConfig);
}
```

## Messages

```protobuf
message Tenant {
  string id = 1;
  string name = 2;
  string slug = 3;
  TenantStatus status = 4;
  SubscriptionTier tier = 5;
  TenantSettings settings = 6;
  Quotas quotas = 7;
  google.protobuf.Timestamp created_at = 8;
}

message Quotas {
  int32 max_users = 1;
  int32 max_satellites = 2;
  int64 max_storage_bytes = 3;
  int32 max_api_keys = 4;
}

message QuotaUsage {
  int32 users = 1;
  int32 satellites = 2;
  int64 storage_bytes = 3;
  int32 api_keys = 4;
}
```

## RPCs

### CreateTenant

**HTTP:** `POST /v1/tenants`

**Required Role:** `system_admin`

### GetTenant

**HTTP:** `GET /v1/tenants/{id}`

**Required Role:** `tenant_admin` or `system_admin`

### UpdateQuotas

**HTTP:** `PUT /v1/tenants/{id}/quotas`

**Required Role:** `system_admin`
