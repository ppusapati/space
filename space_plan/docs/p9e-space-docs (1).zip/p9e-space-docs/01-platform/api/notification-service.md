# Notification Service API

> Package: `platform.v1`

## Service Definition

```protobuf
service NotificationService {
  rpc SendNotification(SendNotificationRequest) returns (Notification);
  rpc ListNotifications(ListNotificationsRequest) returns (ListNotificationsResponse);
  rpc MarkAsRead(MarkAsReadRequest) returns (Notification);
  rpc GetPreferences(google.protobuf.Empty) returns (NotificationPreferences);
  rpc UpdatePreferences(UpdatePreferencesRequest) returns (NotificationPreferences);
  rpc StreamNotifications(StreamNotificationsRequest) returns (stream Notification);
}
```

## Messages

```protobuf
message Notification {
  string id = 1;
  string user_id = 2;
  NotificationType type = 3;
  NotificationChannel channel = 4;
  string title = 5;
  string body = 6;
  google.protobuf.Struct data = 7;
  bool read = 8;
  google.protobuf.Timestamp created_at = 9;
}

enum NotificationType {
  NOTIFICATION_TYPE_UNSPECIFIED = 0;
  NOTIFICATION_TYPE_PASS_SCHEDULED = 1;
  NOTIFICATION_TYPE_PASS_AOS = 2;
  NOTIFICATION_TYPE_COMMAND_PENDING = 3;
  NOTIFICATION_TYPE_ANOMALY_DETECTED = 4;
  NOTIFICATION_TYPE_ALERT = 5;
}

enum NotificationChannel {
  NOTIFICATION_CHANNEL_UNSPECIFIED = 0;
  NOTIFICATION_CHANNEL_IN_APP = 1;
  NOTIFICATION_CHANNEL_EMAIL = 2;
  NOTIFICATION_CHANNEL_SMS = 3;
  NOTIFICATION_CHANNEL_WEBHOOK = 4;
}
```

## StreamNotifications

Real-time notification streaming via gRPC server streaming.

```protobuf
message StreamNotificationsRequest {
  repeated NotificationType types = 1;
}
```
