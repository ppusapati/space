# User Service API

> Package: `platform.v1`

## Service Definition

```protobuf
service UserService {
  rpc CreateUser(CreateUserRequest) returns (User);
  rpc GetUser(GetUserRequest) returns (User);
  rpc UpdateUser(UpdateUserRequest) returns (User);
  rpc DeleteUser(DeleteUserRequest) returns (google.protobuf.Empty);
  rpc ListUsers(ListUsersRequest) returns (ListUsersResponse);
  rpc AssignRole(AssignRoleRequest) returns (User);
  rpc RemoveRole(RemoveRoleRequest) returns (User);
  rpc CreateAPIKey(CreateAPIKeyRequest) returns (APIKeyResponse);
  rpc ListAPIKeys(ListAPIKeysRequest) returns (ListAPIKeysResponse);
  rpc RevokeAPIKey(RevokeAPIKeyRequest) returns (google.protobuf.Empty);
  rpc InviteUser(InviteUserRequest) returns (Invitation);
}
```

## Messages

```protobuf
message User {
  string id = 1;
  string tenant_id = 2;
  string email = 3;
  string first_name = 4;
  string last_name = 5;
  UserStatus status = 6;
  bool mfa_enabled = 7;
  repeated Role roles = 8;
  google.protobuf.Timestamp created_at = 9;
}

message APIKeyResponse {
  string id = 1;
  string name = 2;
  string key = 3; // Only returned on creation
  string prefix = 4;
  repeated string permissions = 5;
  google.protobuf.Timestamp expires_at = 6;
}
```

## RPCs

### CreateUser

**HTTP:** `POST /v1/users`

**Required Role:** `tenant_admin`

### AssignRole

```protobuf
message AssignRoleRequest {
  string user_id = 1;
  string role_id = 2;
}
```

**HTTP:** `POST /v1/users/{user_id}/roles`

### CreateAPIKey

```protobuf
message CreateAPIKeyRequest {
  string name = 1;
  repeated string permissions = 2;
  google.protobuf.Timestamp expires_at = 3;
}
```

**HTTP:** `POST /v1/api-keys`

**Note:** Key is only returned once on creation
