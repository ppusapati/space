# Platform Module - Data Model

## Schema: `platform`

### ERD

```
tenants ◄─── users ──► user_roles ──► roles
   │           │
   │           └──► sessions
   │           └──► api_keys
   └───────────────► audit_logs
```

## Tables

### tenants

```sql
CREATE TABLE platform.tenants (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name            VARCHAR(255) NOT NULL,
    slug            VARCHAR(100) NOT NULL UNIQUE,
    status          tenant_status NOT NULL DEFAULT 'pending',
    tier            subscription_tier NOT NULL DEFAULT 'free',
    settings        JSONB NOT NULL DEFAULT '{}',
    quotas          JSONB NOT NULL DEFAULT '{}',
    stripe_customer_id VARCHAR(100),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

| Column | Type | Description |
|--------|------|-------------|
| id | UUID | Primary key |
| slug | VARCHAR(100) | URL-safe identifier |
| status | tenant_status | pending, active, suspended, deleted |
| tier | subscription_tier | free, starter, professional, enterprise |
| quotas | JSONB | Resource quotas |

### users

```sql
CREATE TABLE platform.users (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES platform.tenants(id),
    email           VARCHAR(255) NOT NULL,
    password_hash   VARCHAR(255),
    first_name      VARCHAR(100),
    last_name       VARCHAR(100),
    status          user_status NOT NULL DEFAULT 'active',
    mfa_enabled     BOOLEAN NOT NULL DEFAULT FALSE,
    mfa_secret      VARCHAR(255),
    idp_subject     VARCHAR(255),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT unique_email_per_tenant UNIQUE (tenant_id, email)
);

ALTER TABLE platform.users ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON platform.users
    USING (tenant_id = current_setting('app.tenant_id')::uuid);
```

### roles

```sql
CREATE TABLE platform.roles (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id   UUID REFERENCES platform.tenants(id),
    name        VARCHAR(100) NOT NULL,
    description TEXT,
    permissions TEXT[] NOT NULL DEFAULT '{}',
    is_system   BOOLEAN NOT NULL DEFAULT FALSE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

**System Roles:**
| Role | Permissions |
|------|-------------|
| system_admin | `*` |
| tenant_admin | `tenant.*`, `users.*` |
| operator | `passes.*`, `telemetry.*`, `commands.*` |
| analyst | `catalog.read`, `processing.*`, `geoint.*` |
| viewer | `*.read` |

### sessions

```sql
CREATE TABLE platform.sessions (
    id              VARCHAR(64) PRIMARY KEY,
    user_id         UUID NOT NULL REFERENCES platform.users(id),
    tenant_id       UUID NOT NULL REFERENCES platform.tenants(id),
    refresh_token   VARCHAR(64) NOT NULL UNIQUE,
    ip_address      INET,
    user_agent      TEXT,
    device_id       VARCHAR(64),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at      TIMESTAMPTZ NOT NULL,
    last_active_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

### audit_logs

```sql
CREATE TABLE platform.audit_logs (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id     UUID NOT NULL,
    user_id       UUID,
    session_id    VARCHAR(64),
    action        VARCHAR(100) NOT NULL,
    resource_type VARCHAR(100),
    resource_id   UUID,
    outcome       audit_outcome NOT NULL,
    details       JSONB,
    ip_address    INET,
    timestamp     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    signature     VARCHAR(64) NOT NULL
);

CREATE INDEX idx_audit_tenant_time ON platform.audit_logs(tenant_id, timestamp DESC);
```

### api_keys

```sql
CREATE TABLE platform.api_keys (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id   UUID NOT NULL REFERENCES platform.tenants(id),
    user_id     UUID NOT NULL REFERENCES platform.users(id),
    name        VARCHAR(100) NOT NULL,
    key_hash    VARCHAR(64) NOT NULL,
    key_prefix  VARCHAR(8) NOT NULL,
    permissions TEXT[] NOT NULL DEFAULT '{}',
    expires_at  TIMESTAMPTZ,
    last_used_at TIMESTAMPTZ,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    revoked_at  TIMESTAMPTZ
);
```

## Enums

```sql
CREATE TYPE tenant_status AS ENUM ('pending', 'active', 'suspended', 'deleted');
CREATE TYPE subscription_tier AS ENUM ('free', 'starter', 'professional', 'enterprise');
CREATE TYPE user_status AS ENUM ('pending', 'active', 'locked', 'disabled');
CREATE TYPE audit_outcome AS ENUM ('success', 'failure', 'denied');
```
