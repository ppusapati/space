# Platform Module

> Identity, Access Control, Tenant Management & Audit

## Overview

The Platform module provides foundational services for multi-tenant identity management, authentication, authorization, audit logging, and notifications.

## Services

| Service | RPCs | Description |
|---------|------|-------------|
| [IdentityService](./api/identity-service.md) | 12 | Authentication, MFA, sessions |
| [TenantService](./api/tenant-service.md) | 9 | Organization management |
| [UserService](./api/user-service.md) | 11 | User CRUD, roles, API keys |
| [AuditService](./api/audit-service.md) | 5 | Compliance logging |
| [NotificationService](./api/notification-service.md) | 6 | Multi-channel notifications |
| **Total** | **43** | |

## Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         PLATFORM MODULE                                     │
├─────────────────────────────────────────────────────────────────────────────┤
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                        API LAYER (ConnectRPC)                        │   │
│  │  Identity │ Tenant │ User │ Audit │ Notification                    │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                    APPLICATION LAYER (Use Cases)                     │   │
│  │  IdentityService │ TenantService │ UserService │ AuditService       │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                    DOMAIN LAYER (Entities)                           │   │
│  │  User │ Tenant │ Role │ Session │ AuditLog │ APIKey                 │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                    INFRASTRUCTURE LAYER                              │   │
│  │  PostgreSQL │ Redis │ NATS │ Vault │ External IdP │ Email/SMS       │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Data Model

See [Data Model](./data-model.md) for complete schema.

| Table | Description |
|-------|-------------|
| `tenants` | Organizations/accounts |
| `users` | User accounts |
| `roles` | Permission groups |
| `user_roles` | User-role assignments |
| `sessions` | Active sessions |
| `audit_logs` | Compliance audit trail |
| `api_keys` | API key management |

## Components

| Component | Description |
|-----------|-------------|
| [Identity Component](./components/identity-component.md) | Authentication, sessions, tokens |
| [Tenant Component](./components/tenant-component.md) | Multi-tenancy, quotas |
| [Audit Component](./components/audit-component.md) | Hash-chain audit logs |

## Integrations

| Integration | Purpose |
|-------------|---------|
| [External IdP](./integrations/external-idp.md) | OIDC/SAML federation |
| [SIEM](./integrations/siem.md) | Security event logging |
| [Email/SMS](./integrations/email-sms.md) | Notification delivery |

## Key Flows

### Authentication Flow
1. User submits credentials → IdentityService.Login
2. Verify password hash (Argon2id)
3. Check MFA requirement → return MFA challenge
4. Verify MFA code → IdentityService.VerifyMFA
5. Create session in Redis
6. Generate JWT access token + opaque refresh token
7. Log audit event

### Authorization Flow
1. Request arrives with JWT
2. Validate JWT signature and expiry
3. Extract tenant_id, user_id, roles
4. Set RLS context: `SET app.tenant_id = ?`
5. Check RBAC permissions
6. Evaluate policy engine rules (if needed)
7. Allow or deny request

## Configuration

```yaml
platform:
  jwt:
    access_token_ttl: 15m
    refresh_token_ttl: 168h
  session:
    idle_timeout: 15m
    max_lifetime: 8h
  password:
    min_length: 12
  mfa:
    required_for_roles: [admin, operator]
  audit:
    retention_days: 2555
    hash_chain: true
```
