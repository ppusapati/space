# External Identity Provider Integration

## Overview

OIDC/SAML federation for enterprise SSO.

## Supported Providers

| Provider | Protocol | Features |
|----------|----------|----------|
| Okta | OIDC, SAML | Full support |
| Azure AD | OIDC, SAML | Full support |
| Auth0 | OIDC | Full support |
| Google Workspace | OIDC | Full support |
| Keycloak | OIDC, SAML | Self-hosted |

## OIDC Flow

```
User → P9E App → Redirect to IdP → Auth → Redirect with code → Exchange → ID Token → Create Session
```

## Configuration

```yaml
tenant_id: "abc123"
idp_config:
  type: "oidc"
  issuer: "https://okta.example.com"
  client_id: "p9e-space-client"
  client_secret: "${VAULT:okta_secret}"
  scopes: ["openid", "profile", "email", "groups"]
  claims_mapping:
    email: "email"
    name: "name"
    groups: "groups"
```

## Implementation

```go
type OIDCClient struct {
    issuer       string
    clientID     string
    clientSecret string
    redirectURI  string
    provider     *oidc.Provider
}

func (c *OIDCClient) AuthCodeURL(state, nonce string) string {
    verifier := oauth2.GenerateVerifier()
    return c.oauth2Config.AuthCodeURL(state,
        oauth2.SetAuthURLParam("nonce", nonce),
        oauth2.S256ChallengeOption(verifier),
    )
}

func (c *OIDCClient) Exchange(ctx context.Context, code, verifier, nonce string) (*Claims, error) {
    token, _ := c.oauth2Config.Exchange(ctx, code, oauth2.VerifierOption(verifier))
    idToken, _ := c.verifier.Verify(ctx, token.Extra("id_token").(string))
    
    var claims Claims
    idToken.Claims(&claims)
    
    if claims.Nonce != nonce {
        return nil, ErrInvalidNonce
    }
    return &claims, nil
}
```

## Group Mapping

```go
var groupRoleMapping = map[string]string{
    "p9e-admins":    "tenant_admin",
    "p9e-operators": "operator",
    "p9e-analysts":  "analyst",
    "p9e-viewers":   "viewer",
}
```
