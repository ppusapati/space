# Email & SMS Integration

## Overview
Multi-channel notification delivery via AWS SES and SNS.

## Email (AWS SES)
| Template | Purpose |
|----------|---------|
| welcome | New user onboarding |
| password-reset | Password reset link |
| pass-scheduled | Pass notification |
| anomaly-alert | Anomaly detection |
| command-pending | Command awaiting approval |

## SMS (AWS SNS)
| Template | Purpose |
|----------|---------|
| mfa_code | MFA verification code |
| pass_aos | Pass AOS notification |
| alert | Critical alert |

## Implementation
```go
type EmailService struct {
    sesClient *ses.Client
    fromAddr  string
}

func (s *EmailService) SendTemplated(to, template string, data map[string]any) error {
    _, err := s.sesClient.SendTemplatedEmail(ctx, &ses.SendTemplatedEmailInput{
        Source: &s.fromAddr,
        Destination: &types.Destination{ToAddresses: []string{to}},
        Template: &template,
        TemplateData: aws.String(jsonEncode(data)),
    })
    return err
}
```
