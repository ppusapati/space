# SIEM Integration

## Overview
Security event logging to enterprise SIEM platforms.

## Supported Platforms
| Platform | Protocol | Format |
|----------|----------|--------|
| Splunk | Syslog/HEC | CEF |
| Elastic SIEM | Syslog | CEF |
| Azure Sentinel | HTTPS | CEF |

## CEF Format
```
CEF:0|P9E|SpacePlatform|1.0|AUTH-001|User Login Failed|3|src=203.0.113.45 suser=user@example.com
```

## Event Categories
| Category | Events |
|----------|--------|
| AUTH | login, logout, mfa_challenge |
| AUTHZ | access_granted, access_denied |
| DATA | data_read, data_export |
| ADMIN | user_created, role_changed |
| OPS | command_sent, anomaly_detected |
