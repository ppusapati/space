# Identity Component

## Overview

Handles authentication, session management, and token generation.

## Class Diagram

```
┌──────────────────────────┐
│   IdentityService        │
├──────────────────────────┤
│ - userRepo: UserRepo     │
│ - sessionStore: SessionStore
│ - tokenGen: TokenGenerator
│ - passwordHasher: Hasher │
│ - mfaProvider: MFAProvider
├──────────────────────────┤
│ + Login()                │
│ + Logout()               │
│ + RefreshToken()         │
│ + EnrollMFA()            │
│ + VerifyMFA()            │
└──────────────────────────┘
         │
         │ uses
         ▼
┌──────────────────────────┐
│   «interface»            │
│   SessionStore           │
├──────────────────────────┤
│ + Create(session)        │
│ + Get(id) Session        │
│ + Delete(id)             │
│ + Extend(id, duration)   │
└──────────────────────────┘
         ▲
         │ implements
┌──────────────────────────┐
│   RedisSessionStore      │
├──────────────────────────┤
│ - client: RedisClient    │
│ - prefix: string         │
└──────────────────────────┘
```

## Sequence: Login Flow

```
Client → IdentityService: Login(email, password)
IdentityService → UserRepo: FindByEmail(email)
UserRepo → IdentityService: User
IdentityService → Hasher: Verify(password, hash)
alt MFA Required
    IdentityService → Client: MFAChallenge
    Client → IdentityService: VerifyMFA(code)
end
IdentityService → SessionStore: Create(session)
IdentityService → TokenGenerator: Generate(claims)
IdentityService → AuditService: Log(user.login)
IdentityService → Client: TokenPair
```

## Token Generation

```go
type TokenGenerator struct {
    privateKey *rsa.PrivateKey
    issuer     string
    audience   []string
}

func (g *TokenGenerator) Generate(user User, session Session) (TokenPair, error) {
    claims := jwt.MapClaims{
        "iss": g.issuer,
        "sub": user.ID,
        "aud": g.audience,
        "tenant_id": user.TenantID,
        "roles": user.Roles,
        "session_id": session.ID,
        "exp": time.Now().Add(15 * time.Minute).Unix(),
    }
    
    accessToken := jwt.NewWithClaims(jwt.SigningMethodRS256, claims)
    // ... sign and return
}
```

## Password Hashing

```go
// Argon2id configuration
type Argon2Config struct {
    Memory      uint32 // 64 MB
    Iterations  uint32 // 3
    Parallelism uint8  // 4
    SaltLength  uint32 // 16
    KeyLength   uint32 // 32
}
```
