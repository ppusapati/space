# Audit Component

## Overview

Provides tamper-evident audit logging with hash chain integrity.

## Class Diagram

```
┌──────────────────────────┐
│   AuditService           │
├──────────────────────────┤
│ - auditRepo: AuditRepo   │
│ - eventPublisher         │
├──────────────────────────┤
│ + Log(entry)             │
│ + Search(criteria)       │
│ + VerifyIntegrity()      │
│ + Export(timeRange)      │
└──────────────────────────┘

┌──────────────────────────┐
│   AuditLog (Entity)      │
├──────────────────────────┤
│ - ID: UUID               │
│ - TenantID: UUID         │
│ - UserID: UUID           │
│ - Action: string         │
│ - ResourceType: string   │
│ - ResourceID: UUID       │
│ - Outcome: AuditOutcome  │
│ - Details: map           │
│ - Timestamp: time.Time   │
│ - Signature: string      │
└──────────────────────────┘
```

## Hash Chain Implementation

```go
func (s *AuditService) Log(ctx context.Context, entry AuditEntry) error {
    // Get previous signature for hash chain
    prevSig, err := s.auditRepo.GetLastSignature(ctx, entry.TenantID)
    if err != nil && !errors.Is(err, ErrNotFound) {
        return err
    }
    
    log := &entity.AuditLog{
        ID:           uuid.New(),
        TenantID:     entry.TenantID,
        UserID:       entry.UserID,
        Action:       entry.Action,
        ResourceType: entry.ResourceType,
        ResourceID:   entry.ResourceID,
        Outcome:      entry.Outcome,
        Details:      entry.Details,
        IPAddress:    entry.IPAddress,
        Timestamp:    time.Now(),
    }
    
    // Create hash chain signature
    data := fmt.Sprintf("%s|%s|%s|%s|%v",
        prevSig, log.ID, log.Action, log.Timestamp, log.Details)
    hash := sha256.Sum256([]byte(data))
    log.Signature = hex.EncodeToString(hash[:])
    
    return s.auditRepo.Append(ctx, log)
}
```

## Integrity Verification

```go
func (s *AuditService) VerifyIntegrity(ctx context.Context, tenantID uuid.UUID) (*IntegrityReport, error) {
    logs, _ := s.auditRepo.GetAll(ctx, tenantID)
    
    report := &IntegrityReport{
        TotalRecords: len(logs),
    }
    
    var prevSig string
    for _, log := range logs {
        expectedSig := computeSignature(prevSig, log)
        if log.Signature != expectedSig {
            report.Violations = append(report.Violations, Violation{
                LogID:    log.ID,
                Expected: expectedSig,
                Actual:   log.Signature,
            })
        }
        prevSig = log.Signature
        report.VerifiedRecords++
    }
    
    report.Valid = len(report.Violations) == 0
    return report, nil
}
```
