# Tenant Component

## Overview

Manages multi-tenancy, organization settings, and resource quotas.

## Class Diagram

```
┌──────────────────────────┐
│   Tenant (Entity)        │
├──────────────────────────┤
│ - ID: UUID               │
│ - Name: string           │
│ - Slug: TenantSlug       │
│ - Status: TenantStatus   │
│ - Tier: SubscriptionTier │
│ - Settings: Settings     │
│ - Quotas: Quotas         │
├──────────────────────────┤
│ + Activate()             │
│ + Suspend()              │
│ + UpdateTier(tier)       │
│ + CheckQuota(resource)   │
└──────────────────────────┘

┌──────────────────────────┐
│   TenantService          │
├──────────────────────────┤
│ - tenantRepo             │
│ - quotaService           │
│ - eventPublisher         │
├──────────────────────────┤
│ + CreateTenant()         │
│ + GetTenant()            │
│ + UpdateSettings()       │
│ + CheckQuota()           │
└──────────────────────────┘
```

## Quota Management

```go
type Quotas struct {
    MaxUsers       int   `json:"max_users"`
    MaxSatellites  int   `json:"max_satellites"`
    MaxStorageGB   int64 `json:"max_storage_gb"`
    MaxAPIKeys     int   `json:"max_api_keys"`
    MaxPassesPerDay int  `json:"max_passes_per_day"`
}

type QuotaUsage struct {
    Users       int   `json:"users"`
    Satellites  int   `json:"satellites"`
    StorageGB   int64 `json:"storage_gb"`
    APIKeys     int   `json:"api_keys"`
}

func (s *TenantService) CheckQuota(tenantID, resource string) error {
    usage, _ := s.quotaService.GetUsage(tenantID)
    quotas, _ := s.tenantRepo.GetQuotas(tenantID)
    
    switch resource {
    case "users":
        if usage.Users >= quotas.MaxUsers {
            return ErrQuotaExceeded
        }
    // ... other resources
    }
    return nil
}
```

## Subscription Tiers

| Tier | Users | Satellites | Storage | API Keys |
|------|-------|------------|---------|----------|
| Free | 3 | 1 | 1 GB | 2 |
| Starter | 10 | 5 | 50 GB | 10 |
| Professional | 50 | 25 | 500 GB | 50 |
| Enterprise | Unlimited | Unlimited | Unlimited | Unlimited |
