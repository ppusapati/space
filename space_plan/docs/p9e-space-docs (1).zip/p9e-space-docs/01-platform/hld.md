# Platform Module - High-Level Design

## 1. Design Goals

| Goal | Description |
|------|-------------|
| **Multi-Tenancy** | Complete data isolation between organizations |
| **Security** | Defense-in-depth authentication and authorization |
| **Compliance** | SOC 2, ISO 27001 audit requirements |
| **Scalability** | Support 1000+ tenants, 100K+ users |

## 2. Component Design

### Identity Component

```
IdentityService
├── Login(email, password) → TokenPair | MFAChallenge
├── VerifyMFA(sessionId, code) → TokenPair
├── RefreshToken(refreshToken) → TokenPair
├── Logout(allSessions)
├── EnrollMFA(method) → secret, qrCode, backupCodes
├── ResetPassword(token, newPassword)
└── ChangePassword(current, new)
```

**Dependencies:**
- UserRepository (PostgreSQL)
- SessionStore (Redis)
- TokenGenerator (JWT)
- PasswordHasher (Argon2id)
- MFAProvider (TOTP)

### Tenant Component

```
TenantService
├── CreateTenant(name, tier) → Tenant
├── GetTenant(id) → Tenant
├── UpdateTenant(id, settings)
├── SuspendTenant(id)
├── ActivateTenant(id)
├── GetQuotaUsage(id) → QuotaUsage
└── UpdateQuotas(id, quotas)
```

## 3. Security Design

### Authentication
- Password: Argon2id (memory=64MB, iterations=3)
- MFA: TOTP (RFC 6238, 30-second window)
- Session: Redis, 15-min idle, 8-hour max
- JWT: RS256, 15-minute expiry
- Refresh: Opaque, 7-day, single-use rotation

### Authorization Layers

```
Layer 1: IAM
├── User exists and active
├── Session valid
├── Tenant membership
└── MFA completed

Layer 2: RBAC
├── User has role
├── Role grants permission
└── Module access

Layer 3: Policy Engine
├── Resource ownership
├── Time restrictions
├── Classification levels
└── Two-person auth
```

## 4. Multi-Tenancy Design

### Row-Level Security

```sql
-- Enable RLS
ALTER TABLE platform.users ENABLE ROW LEVEL SECURITY;

-- Policy
CREATE POLICY tenant_isolation ON platform.users
    USING (tenant_id = current_setting('app.tenant_id')::uuid);

-- Application sets context
SET app.tenant_id = 'tenant-uuid';
```

## 5. Audit Design

### Hash Chain Integrity

```go
func (s *AuditService) Log(entry AuditEntry) error {
    prevSig, _ := s.repo.GetLastSignature(entry.TenantID)
    data := prevSig + entry.String()
    entry.Signature = sha256.Sum256([]byte(data))
    return s.repo.Append(entry)
}
```
