# Workspace Aggregate

## Structure
```
WorkspaceAggregate
├── Workspace (root)
│   ├── ID, Name, Description
│   ├── Status, Layers
│   └── CreatedBy, CreatedAt
├── Members[]
│   ├── UserID, Role
│   └── AddedAt
├── AOIs[]
│   ├── Geometry, Priority
│   └── MonitoringConfig
└── Reports[]
    ├── Type, Title, Body
    └── Classification, Status
```

## Member Roles
| Role | Permissions |
|------|-------------|
| VIEWER | Read workspace, AOIs, reports |
| EDITOR | Create/edit AOIs, observations |
| ADMIN | Manage members, publish reports |
