# GEOINT Module - Data Model

## Tables

### workspaces
```sql
CREATE TABLE geoint.workspaces (
    id UUID PRIMARY KEY,
    tenant_id UUID NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    status workspace_status NOT NULL DEFAULT 'active',
    layers JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by UUID NOT NULL
);
```

### workspace_members
```sql
CREATE TABLE geoint.workspace_members (
    workspace_id UUID NOT NULL REFERENCES geoint.workspaces(id),
    user_id UUID NOT NULL,
    role workspace_role NOT NULL DEFAULT 'viewer',
    added_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (workspace_id, user_id)
);
```

### aois
```sql
CREATE TABLE geoint.aois (
    id UUID PRIMARY KEY,
    workspace_id UUID NOT NULL REFERENCES geoint.workspaces(id),
    tenant_id UUID NOT NULL,
    name VARCHAR(255) NOT NULL,
    geometry GEOMETRY(GEOMETRY, 4326) NOT NULL,
    status aoi_status NOT NULL DEFAULT 'active',
    priority priority_level NOT NULL DEFAULT 'medium',
    classification classification_level NOT NULL DEFAULT 'unclassified',
    monitoring_enabled BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE INDEX idx_aois_geometry ON geoint.aois USING GIST (geometry);
```

### observations
```sql
CREATE TABLE geoint.observations (
    id UUID PRIMARY KEY,
    aoi_id UUID NOT NULL REFERENCES geoint.aois(id),
    tenant_id UUID NOT NULL,
    type observation_type NOT NULL,
    title VARCHAR(255) NOT NULL,
    location GEOMETRY(POINT, 4326) NOT NULL,
    observed_at TIMESTAMPTZ NOT NULL,
    confidence DECIMAL(5,4),
    source observation_source NOT NULL
);

CREATE INDEX idx_observations_location ON geoint.observations USING GIST (location);
```

### reports
```sql
CREATE TABLE geoint.reports (
    id UUID PRIMARY KEY,
    workspace_id UUID NOT NULL,
    tenant_id UUID NOT NULL,
    type report_type NOT NULL,
    title VARCHAR(255) NOT NULL,
    summary TEXT,
    body TEXT,
    classification classification_level NOT NULL DEFAULT 'unclassified',
    status report_status NOT NULL DEFAULT 'draft',
    pdf_url TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    published_at TIMESTAMPTZ
);
```
