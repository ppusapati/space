# Report Service API
> Package: `geoint.v1`

```protobuf
service ReportService {
  rpc CreateReport(CreateReportRequest) returns (Report);
  rpc GetReport(GetReportRequest) returns (Report);
  rpc UpdateReport(UpdateReportRequest) returns (Report);
  rpc DeleteReport(DeleteReportRequest) returns (google.protobuf.Empty);
  rpc ListReports(ListReportsRequest) returns (ListReportsResponse);
  rpc PublishReport(PublishReportRequest) returns (Report);
  rpc GeneratePDF(GeneratePDFRequest) returns (PDFResponse);
  rpc ListTemplates(ListTemplatesRequest) returns (ListTemplatesResponse);
}
```

## Report Types
- SPOT: Quick tactical report
- SITREP: Situation report
- CHANGE: Change detection report
- ASSESSMENT: Comprehensive assessment
