# Analysis Service API
> Package: `geoint.v1`

```protobuf
service AnalysisService {
  rpc DetectChanges(DetectChangesRequest) returns (DetectChangesResponse);
  rpc DetectObjects(DetectObjectsRequest) returns (DetectObjectsResponse);
  rpc AnalyzePatterns(AnalyzePatternsRequest) returns (PatternAnalysis);
  rpc CreateObservation(CreateObservationRequest) returns (Observation);
  rpc ListObservations(ListObservationsRequest) returns (ListObservationsResponse);
  rpc ValidateObservation(ValidateObservationRequest) returns (Observation);
  rpc GetTimeline(GetTimelineRequest) returns (Timeline);
}
```
