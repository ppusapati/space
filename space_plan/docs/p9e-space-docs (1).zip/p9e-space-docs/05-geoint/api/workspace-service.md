# WorkspaceService API

> Collaborative GEOINT workspaces and projects

## Service Definition

```protobuf
service WorkspaceService {
  // Workspace CRUD
  rpc CreateWorkspace(CreateWorkspaceRequest) returns (Workspace);
  rpc GetWorkspace(GetWorkspaceRequest) returns (Workspace);
  rpc UpdateWorkspace(UpdateWorkspaceRequest) returns (Workspace);
  rpc DeleteWorkspace(DeleteWorkspaceRequest) returns (google.protobuf.Empty);
  rpc ListWorkspaces(ListWorkspacesRequest) returns (ListWorkspacesResponse);
  
  // Members
  rpc AddMember(AddMemberRequest) returns (WorkspaceMember);
  rpc UpdateMember(UpdateMemberRequest) returns (WorkspaceMember);
  rpc RemoveMember(RemoveMemberRequest) returns (google.protobuf.Empty);
  rpc ListMembers(ListMembersRequest) returns (ListMembersResponse);
  
  // Layers
  rpc AddLayer(AddLayerRequest) returns (WorkspaceLayer);
  rpc UpdateLayer(UpdateLayerRequest) returns (WorkspaceLayer);
  rpc RemoveLayer(RemoveLayerRequest) returns (google.protobuf.Empty);
  rpc ListLayers(ListLayersRequest) returns (ListLayersResponse);
  rpc ReorderLayers(ReorderLayersRequest) returns (ListLayersResponse);
}
```

## Messages

### Workspace

```protobuf
message Workspace {
  string id = 1;
  string tenant_id = 2;
  string name = 3;
  string description = 4;
  ClassificationLevel classification = 5;
  WorkspaceStatus status = 6;
  
  // Default view
  BoundingBox default_bbox = 7;
  int32 default_zoom = 8;
  
  // Settings
  WorkspaceSettings settings = 9;
  
  // Counts
  int32 member_count = 10;
  int32 aoi_count = 11;
  int32 report_count = 12;
  
  // Metadata
  string created_by = 13;
  google.protobuf.Timestamp created_at = 14;
  google.protobuf.Timestamp updated_at = 15;
}

enum ClassificationLevel {
  CLASSIFICATION_LEVEL_UNSPECIFIED = 0;
  CLASSIFICATION_LEVEL_UNCLASSIFIED = 1;
  CLASSIFICATION_LEVEL_RESTRICTED = 2;
  CLASSIFICATION_LEVEL_CONFIDENTIAL = 3;
  CLASSIFICATION_LEVEL_SECRET = 4;
}

enum WorkspaceStatus {
  WORKSPACE_STATUS_UNSPECIFIED = 0;
  WORKSPACE_STATUS_ACTIVE = 1;
  WORKSPACE_STATUS_ARCHIVED = 2;
}

message WorkspaceSettings {
  // Basemap
  string default_basemap = 1;  // "satellite", "street", "terrain"
  
  // Notifications
  bool notify_on_new_imagery = 2;
  bool notify_on_aoi_activity = 3;
  bool notify_on_report_ready = 4;
  
  // Auto-processing
  bool auto_detect_changes = 5;
  bool auto_detect_objects = 6;
  repeated string auto_detect_classes = 7;
}
```

### WorkspaceMember

```protobuf
message WorkspaceMember {
  string workspace_id = 1;
  string user_id = 2;
  string email = 3;
  string name = 4;
  MemberRole role = 5;
  google.protobuf.Timestamp joined_at = 6;
  google.protobuf.Timestamp last_active_at = 7;
}

enum MemberRole {
  MEMBER_ROLE_UNSPECIFIED = 0;
  MEMBER_ROLE_VIEWER = 1;   // Read-only access
  MEMBER_ROLE_EDITOR = 2;   // Can create/edit AOIs, observations
  MEMBER_ROLE_ADMIN = 3;    // Can manage members, settings
}
```

### WorkspaceLayer

```protobuf
message WorkspaceLayer {
  string id = 1;
  string workspace_id = 2;
  string name = 3;
  LayerType type = 4;
  int32 order = 5;
  bool visible = 6;
  double opacity = 7;  // 0.0 - 1.0
  
  // Source configuration
  LayerSource source = 8;
  
  // Style
  LayerStyle style = 9;
}

enum LayerType {
  LAYER_TYPE_UNSPECIFIED = 0;
  LAYER_TYPE_BASEMAP = 1;
  LAYER_TYPE_IMAGERY = 2;
  LAYER_TYPE_VECTOR = 3;
  LAYER_TYPE_AOI = 4;
  LAYER_TYPE_OBSERVATIONS = 5;
  LAYER_TYPE_HEATMAP = 6;
  LAYER_TYPE_WMS = 7;
  LAYER_TYPE_WMTS = 8;
}

message LayerSource {
  oneof source {
    string collection_id = 1;      // EO catalog collection
    string item_id = 2;            // Specific item
    string aoi_id = 3;             // AOI layer
    string wms_url = 4;            // WMS endpoint
    string wmts_url = 5;           // WMTS endpoint
  }
  
  // For imagery layers
  repeated string bands = 6;       // RGB band combination
  string color_map = 7;            // For single-band
  double min_value = 8;
  double max_value = 9;
}

message LayerStyle {
  // Vector styles
  string fill_color = 1;
  string stroke_color = 2;
  double stroke_width = 3;
  double fill_opacity = 4;
  
  // Label
  string label_field = 5;
  string label_font = 6;
  int32 label_size = 7;
}
```

## RPCs

### CreateWorkspace

Creates a new collaborative workspace.

```protobuf
message CreateWorkspaceRequest {
  string name = 1 [(validate.rules).string = {min_len: 1, max_len: 255}];
  string description = 2;
  ClassificationLevel classification = 3;
  BoundingBox default_bbox = 4;
  WorkspaceSettings settings = 5;
}
```

**Response:** `Workspace` with creator as admin member

**Authorization:** `geoint.workspaces.create`

### AddMember

Adds a user to the workspace.

```protobuf
message AddMemberRequest {
  string workspace_id = 1;
  string user_email = 2;
  MemberRole role = 3;
}
```

**Authorization:** `workspace.admin` role in workspace

### ListWorkspaces

Lists workspaces the user has access to.

```protobuf
message ListWorkspacesRequest {
  common.v1.PageRequest page = 1;
  WorkspaceStatus status_filter = 2;
  string search = 3;
}

message ListWorkspacesResponse {
  repeated WorkspaceSummary workspaces = 1;
  common.v1.PageInfo page_info = 2;
}

message WorkspaceSummary {
  string id = 1;
  string name = 2;
  ClassificationLevel classification = 3;
  MemberRole my_role = 4;
  int32 member_count = 5;
  google.protobuf.Timestamp last_activity = 6;
}
```

### ReorderLayers

Reorders layers in the workspace.

```protobuf
message ReorderLayersRequest {
  string workspace_id = 1;
  repeated string layer_ids = 2;  // In desired order
}
```

## Workspace Aggregate

```
WorkspaceAggregate
├── Workspace (root)
│   ├── ID, Name, Description
│   ├── Classification
│   └── Settings
│
├── Members[]
│   ├── UserID, Email, Name
│   ├── Role (Viewer/Editor/Admin)
│   └── JoinedAt
│
├── Layers[]
│   ├── ID, Name, Type
│   ├── Source, Style
│   └── Order, Visibility
│
├── AOIs[] (references)
│
└── Reports[] (references)
```

## Access Control

| Role | Permissions |
|------|-------------|
| **Viewer** | View workspace, AOIs, observations, reports |
| **Editor** | + Create/edit AOIs, observations, annotations |
| **Admin** | + Manage members, settings, delete workspace |

## Events

| Event | Trigger | Payload |
|-------|---------|---------|
| `workspace.created` | CreateWorkspace | Workspace |
| `workspace.member.added` | AddMember | workspace_id, member |
| `workspace.member.removed` | RemoveMember | workspace_id, user_id |
| `workspace.layer.added` | AddLayer | workspace_id, layer |
| `workspace.archived` | Archive | workspace_id |

## Metrics

| Metric | Type | Labels | Description |
|--------|------|--------|-------------|
| `workspaces_total` | Gauge | status | Workspace count |
| `workspace_members` | Gauge | workspace_id | Members per workspace |
| `workspace_activity` | Counter | workspace_id, action | Activity events |
