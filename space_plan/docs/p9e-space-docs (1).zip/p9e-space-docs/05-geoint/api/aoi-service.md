# AOI Service API
> Package: `geoint.v1`

```protobuf
service AOIService {
  rpc CreateAOI(CreateAOIRequest) returns (AOI);
  rpc GetAOI(GetAOIRequest) returns (AOI);
  rpc UpdateAOI(UpdateAOIRequest) returns (AOI);
  rpc DeleteAOI(DeleteAOIRequest) returns (google.protobuf.Empty);
  rpc ListAOIs(ListAOIsRequest) returns (ListAOIsResponse);
  rpc EnableMonitoring(EnableMonitoringRequest) returns (AOI);
  rpc DisableMonitoring(DisableMonitoringRequest) returns (AOI);
  rpc GetMonitoringStatus(GetMonitoringStatusRequest) returns (MonitoringStatus);
}
```
