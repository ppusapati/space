# GEOINT Module

> Geospatial Intelligence - AOI Monitoring, Analysis & Reporting

## Services

| Service | RPCs | Description |
|---------|------|-------------|
| [AOIService](./api/aoi-service.md) | 8 | Area of Interest management |
| [AnalysisService](./api/analysis-service.md) | 7 | Pattern detection |
| [ReportService](./api/report-service.md) | 8 | Report generation |
| [WorkspaceService](./api/workspace-service.md) | 9 | Collaboration |
| **Total** | **32** | |

## Key Concepts

### Workspaces
- Collaborative project spaces
- Member management (Viewer, Editor, Admin)
- Shared AOIs and reports

### Areas of Interest (AOIs)
- Geographic regions for monitoring
- Priority levels (LOW, MEDIUM, HIGH, CRITICAL)
- Classification levels
- Automated monitoring

### Observations
- Point/polygon annotations
- Types: Vehicle, Vessel, Aircraft, Structure, Activity
- Sources: ML_AUTO, HUMAN, VALIDATED

### Reports
- Types: SPOT, SITREP, CHANGE, ASSESSMENT
- PDF generation
- Classification handling

## Workspace Aggregate
```
WorkspaceAggregate
├── Workspace (root)
├── Members[]
├── AOIs[]
└── Reports[]
```
