# Integration Patterns

> P9E Space Platform - External System Integration Architecture

## 1. Integration Catalog

| # | System | Category | Protocol | Auth | Purpose |
|---|--------|----------|----------|------|---------|
| 1 | Space-Track.org | Space Data | REST | Session Cookie | TLE, CDM data |
| 2 | Sentinel Hub | EO Imagery | REST | OAuth 2.0 | Satellite imagery |
| 3 | AWS Ground Station | Hardware | AWS SDK | IAM SigV4 | Contact scheduling |
| 4 | NOAA Weather | Data | REST | User-Agent | Weather forecasts |
| 5 | USGS Elevation | Data | REST | None | DEM data |
| 6 | SDR Hardware | Hardware | ZMQ/TCP | Local | RF reception |
| 7 | Antenna Rotator | Hardware | Serial/Hamlib | Local | Antenna pointing |
| 8 | External IdP | Identity | OIDC | PKCE | SSO federation |
| 9 | SIEM | Security | Syslog/CEF | mTLS | Security logging |
| 10 | Stripe | Billing | REST | API Key | Subscriptions |
| 11 | AWS SES | Notification | AWS SDK | IAM | Email delivery |
| 12 | AWS SNS | Notification | AWS SDK | IAM | SMS delivery |
| 13 | S3/MinIO | Storage | S3 API | IAM/Keys | Object storage |

## 2. Integration Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        P9E PLATFORM CORE                                    │
├─────────────────────────────────────────────────────────────────────────────┤
│  ┌───────────────────┐ ┌───────────────────┐ ┌───────────────────┐         │
│  │   ADAPTER LAYER   │ │   GATEWAY LAYER   │ │    ACL LAYER      │         │
│  │ • Protocol Conv   │ │ • Rate Limiting   │ │ • Data Transform  │         │
│  │ • Hardware I/O    │ │ • Caching         │ │ • Model Mapping   │         │
│  │ • Stream Handling │ │ • Auth Handling   │ │ • Validation      │         │
│  └─────────┬─────────┘ └─────────┬─────────┘ └─────────┬─────────┘         │
│  ┌─────────┴─────────────────────┴─────────────────────┴─────────┐         │
│  │                    RESILIENCE LAYER                           │         │
│  │   Circuit Breaker │ Retry + Backoff │ Timeout │ Bulkhead      │         │
│  └───────────────────────────────────────────────────────────────┘         │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 3. Resilience Patterns

### Circuit Breaker
```go
type CircuitBreaker struct {
    maxFailures int           // 5
    timeout     time.Duration // 30s
    state       State         // Closed, Open, HalfOpen
}
```

### Retry with Exponential Backoff
```go
type RetryConfig struct {
    MaxAttempts    int           // 3
    InitialBackoff time.Duration // 100ms
    MaxBackoff     time.Duration // 10s
    BackoffFactor  float64       // 2.0
}
```

## 4. Space-Track Integration

```go
type SpaceTrackClient struct {
    baseURL  string // https://www.space-track.org
    username string
    password string
    session  *http.Cookie // 2-hour expiry
}

// Rate limit: 200 requests/hour
func (c *SpaceTrackClient) FetchTLE(ctx context.Context, noradID int) (*TLE, error)
func (c *SpaceTrackClient) FetchCDM(ctx context.Context, noradID int, since time.Time) ([]CDM, error)
```

## 5. Sentinel Hub Integration

```go
type SentinelHubClient struct {
    baseURL      string // https://services.sentinel-hub.com
    clientID     string
    clientSecret string
    token        *oauth2.Token // 1-hour expiry
}

// Rate limit: 300 requests/minute, 50,000 PU/month
func (c *SentinelHubClient) SearchCatalog(ctx context.Context, bbox BBox, collections []string) ([]Item, error)
func (c *SentinelHubClient) Process(ctx context.Context, bbox BBox, evalscript string) ([]byte, error)
```

## 6. SDR Hardware Integration

```go
type SDRController interface {
    SetFrequency(freq float64) error
    SetSampleRate(rate float64) error
    SetGain(gain float64) error
    StartStream(ctx context.Context) (<-chan []complex64, error)
    StopStream() error
    GetStatus() SDRStatus
}

// Implementations: USRPAdapter, RTLSDRAdapter, HackRFAdapter
```

## 7. Health Checks

| Integration | Check Method | Interval |
|-------------|--------------|----------|
| Space-Track | Login + query | 5 min |
| Sentinel Hub | Token refresh | 5 min |
| AWS GS | ListGroundStations | 5 min |
| SDR Hardware | Device ping | 30 sec |
| Antenna | Position query | 10 sec |
| External IdP | OIDC discovery | 5 min |

## 8. Monitoring Metrics

```prometheus
integration_requests_total{integration, method, status}
integration_latency_seconds{integration, method}
integration_circuit_state{integration}  # 0=closed, 1=open, 2=half-open
```
