# System Overview

> P9E Space Technology Platform - Enterprise Architecture

## 1. Introduction

The P9E Space Platform is a cloud-native, multi-tenant satellite operations platform designed for commercial and government space operators.

## 2. Business Context

### 2.1 Target Users

| Actor | Description | Primary Modules |
|-------|-------------|-----------------|
| **System Administrator** | Platform configuration, tenant management | Platform |
| **Tenant Administrator** | Organization settings, user management | Platform |
| **Ground Station Operator** | Pass scheduling, TM/TC operations | Ground Station |
| **Flight Dynamics Engineer** | Orbit determination, maneuver planning | Satellite |
| **EO Analyst** | Imagery search, processing, ML inference | EO |
| **Intelligence Analyst** | AOI monitoring, pattern analysis, reporting | GEOINT |

### 2.2 Key Capabilities

1. **Multi-Tenant Operations**: Complete tenant isolation with configurable quotas
2. **Ground Station Network**: Support for owned and partner ground stations
3. **Real-Time Telemetry**: Sub-second latency from antenna to dashboard
4. **Command & Control**: Two-person authorization for critical operations
5. **Earth Observation**: STAC-compliant catalog with processing pipelines
6. **Geospatial Intelligence**: Automated monitoring and change detection

## 3. System Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           PRESENTATION LAYER                                │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐        │
│  │  Web App    │  │ Desktop App │  │ Mobile App  │  │  CLI Tool   │        │
│  │ (SvelteKit) │  │  (Tauri)    │  │  (Tauri)    │  │    (Go)     │        │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘        │
│         └────────────────┴────────────────┴────────────────┘               │
│                          ┌────────┴────────┐                               │
│                          │   API Gateway   │                               │
│                          │  (ConnectRPC)   │                               │
│                          └────────┬────────┘                               │
└──────────────────────────────────┼─────────────────────────────────────────┘
                                   │
┌──────────────────────────────────┼─────────────────────────────────────────┐
│                           SERVICE LAYER                                    │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐       │
│  │  Platform   │  │Ground Station│  │  Satellite  │  │     EO      │       │
│  │  Module     │  │   Module    │  │   Module    │  │   Module    │       │
│  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘       │
│  ┌─────────────┐  ┌─────────────┐                                         │
│  │   GEOINT    │  │   Common    │                                         │
│  │   Module    │  │  Services   │                                         │
│  └─────────────┘  └─────────────┘                                         │
└───────────────────────────────────────────────────────────────────────────┘
                                   │
┌──────────────────────────────────┼─────────────────────────────────────────┐
│                           DATA LAYER                                       │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐       │
│  │ PostgreSQL  │  │ TimescaleDB │  │   Redis     │  │    NATS     │       │
│  │  + PostGIS  │  │ (Telemetry) │  │   Cache     │  │  JetStream  │       │
│  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘       │
│  ┌─────────────┐  ┌─────────────┐                                         │
│  │  S3/MinIO   │  │    Vault    │                                         │
│  │  (Objects)  │  │  (Secrets)  │                                         │
│  └─────────────┘  └─────────────┘                                         │
└───────────────────────────────────────────────────────────────────────────┘
```

## 4. Module Responsibilities

| Module | Bounded Context | Key Aggregates |
|--------|-----------------|----------------|
| **Platform** | Identity & Access | User, Tenant, Session, AuditLog |
| **Ground Station** | Satellite Operations | Pass, Command, TelemetryStream |
| **Satellite** | Spacecraft Management | Spacecraft, OrbitState, Conjunction |
| **EO** | Earth Observation | Collection, Item, ProcessingJob, Model |
| **GEOINT** | Intelligence Analysis | Workspace, AOI, Observation, Report |
| **Common** | Shared Utilities | Export, Dashboard, Schedule |

## 5. Communication Patterns

| Pattern | Usage | Technology |
|---------|-------|------------|
| **Synchronous** | API requests, queries | ConnectRPC (gRPC/HTTP) |
| **Async Events** | Domain events, notifications | NATS JetStream |
| **Streaming** | Telemetry, alerts | gRPC streams, WebSocket, SSE |
| **Batch** | Data export, bulk operations | Background jobs + S3 |

## 6. Non-Functional Requirements

| Requirement | Target | Approach |
|-------------|--------|----------|
| **Availability** | 99.9% | HA deployment, health checks |
| **Latency (API)** | p95 < 200ms | Caching, connection pooling |
| **Latency (Telemetry)** | < 1 second | NATS streaming |
| **Throughput** | 10,000 TM frames/second | Horizontal scaling |
| **Storage** | 10+ PB imagery | S3 tiering |
| **Recovery (RPO)** | 1 hour | Streaming replication |
| **Recovery (RTO)** | 4 hours | Automated failover |

## 7. External Integrations

| System | Purpose | Protocol |
|--------|---------|----------|
| Space-Track.org | TLE, CDM data | REST API |
| Sentinel Hub | Satellite imagery | REST API (OAuth) |
| AWS Ground Station | Antenna access | AWS SDK |
| External IdP | SSO federation | OIDC/SAML |
| Stripe | Billing | REST API + Webhooks |
| AWS SES/SNS | Notifications | AWS SDK |

## 8. Related Documents

- [Security Architecture](./security-architecture.md)
- [Data Architecture](./data-architecture.md)
- [Integration Patterns](./integration-patterns.md)
- [Observability](./observability.md)
