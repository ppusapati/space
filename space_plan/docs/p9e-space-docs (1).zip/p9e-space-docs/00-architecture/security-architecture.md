# Security Architecture

> P9E Space Platform - Security Design & Controls

## 1. Overview

Defense-in-depth security with multiple layers protecting multi-tenant satellite operations data.

## 2. Security Principles

| Principle | Implementation |
|-----------|----------------|
| **Zero Trust** | Verify every request, assume breach |
| **Least Privilege** | Minimal permissions by default |
| **Defense in Depth** | Multiple security layers |
| **Secure by Default** | Security enabled out of box |
| **Audit Everything** | Complete audit trail |

## 3. Authentication

### 3.1 Authentication Methods

| Method | Implementation | Use Case |
|--------|----------------|----------|
| Password | Argon2id (memory=64MB, iterations=3) | Primary login |
| MFA - TOTP | RFC 6238, 30-second window | Required for admins |
| MFA - WebAuthn | FIDO2 hardware keys | High security |
| OIDC | External IdP federation | Enterprise SSO |
| API Key | SHA-256 hashed | Programmatic access |

### 3.2 Token Structure

```
Access Token (JWT, 15 min):
{
  "iss": "https://auth.p9e.space",
  "sub": "user_uuid",
  "tenant_id": "tenant_uuid",
  "roles": ["operator", "analyst"],
  "permissions": ["pass.schedule", "telemetry.read"],
  "session_id": "session_uuid",
  "exp": 1735300800
}

Refresh Token: Opaque, 7 days, single-use with rotation
```

## 4. Authorization

### 4.1 Three-Layer Model

```
┌─────────────────────────────────────────────────────────────────┐
│ LAYER 1: IAM (Identity & Access Management)                     │
│ • User exists and is active                                     │
│ • Session is valid                                              │
│ • Tenant membership verified                                    │
│ • MFA completed (if required)                                   │
├─────────────────────────────────────────────────────────────────┤
│ LAYER 2: RBAC (Role-Based Access Control)                       │
│ • User has required role                                        │
│ • Role grants permission for action                             │
│ • Module-level access control                                   │
├─────────────────────────────────────────────────────────────────┤
│ LAYER 3: Policy Engine (Fine-Grained)                           │
│ • Resource ownership                                            │
│ • Time-based restrictions                                       │
│ • Classification levels                                         │
│ • Custom business rules (e.g., two-person auth)                 │
└─────────────────────────────────────────────────────────────────┘
```

### 4.2 Permission Model

```
Permission Format: {module}.{resource}.{action}

Examples:
- platform.users.create
- groundstation.passes.schedule
- groundstation.commands.approve
- eo.items.read
- geoint.reports.publish
```

### 4.3 Role Hierarchy

| Role | Permissions |
|------|-------------|
| System Admin | `*` (all) |
| Tenant Admin | `tenant.*`, `users.*` |
| Mission Manager | `passes.*`, `commands.*`, `spacecraft.read` |
| Operator | `passes.*`, `telemetry.*`, `commands.submit` |
| Analyst | `catalog.read`, `processing.*`, `geoint.*` |
| Viewer | `*.read` |

## 5. Data Protection

### 5.1 Encryption

| Scope | Algorithm | Key Management |
|-------|-----------|----------------|
| In Transit | TLS 1.3 | Auto-rotated certificates |
| At Rest (DB) | AES-256-GCM | Vault-managed DEK |
| At Rest (S3) | SSE-KMS | AWS KMS / Vault Transit |
| Secrets | AES-256-GCM | HashiCorp Vault |

### 5.2 Tenant Isolation (Row-Level Security)

```sql
-- RLS Policy
CREATE POLICY tenant_isolation ON satellites
    USING (tenant_id = current_setting('app.tenant_id')::uuid);

-- Application sets context
SET app.tenant_id = 'tenant-uuid';
SELECT * FROM satellites; -- Only returns tenant's satellites
```

## 6. Network Security

```
┌─────────────────────────────────────────────────────────────────┐
│ PUBLIC ZONE (DMZ)                                               │
│   Ingress Controller │ WAF │ DDoS Protection                   │
├─────────────────────────────────────────────────────────────────┤
│ APPLICATION ZONE                                                │
│   API Gateway │ Services │ Workers                             │
├─────────────────────────────────────────────────────────────────┤
│ DATA ZONE (Restricted)                                          │
│   PostgreSQL │ Redis │ Vault                                   │
└─────────────────────────────────────────────────────────────────┘
```

## 7. Audit & Compliance

### 7.1 Audit Log Structure

```json
{
  "id": "uuid",
  "tenant_id": "uuid",
  "user_id": "uuid",
  "action": "command.approve",
  "resource_type": "Command",
  "resource_id": "uuid",
  "outcome": "success",
  "details": {"command_mnemonic": "SAFE_MODE", "hazard_level": "CRITICAL"},
  "timestamp": "2025-12-27T10:30:00Z",
  "signature": "sha256:abc123..."
}
```

### 7.2 Compliance Controls

| Framework | Status |
|-----------|--------|
| SOC 2 Type II | Ready |
| ISO 27001 | Aligned |
| ITAR | Aware |
| GDPR | Compliant |

## 8. Secrets Management (Vault)

| Type | Path | Rotation |
|------|------|----------|
| API Keys | `secret/data/{env}/api-keys/*` | 90 days |
| DB Credentials | `database/creds/*` | Dynamic (1 hour) |
| JWT Signing Key | `transit/keys/jwt-signing` | 30 days |
| TLS Certificates | `pki/issue/*` | 30 days |
