# ADR-002: ConnectRPC for API Communication

## Status
**Accepted** - December 2025

## Context
Need API protocol with strong typing, browser support, and streaming.

## Decision
Use **ConnectRPC** (from Buf) as primary API protocol.

## Rationale

| Feature | ConnectRPC | Pure gRPC | REST |
|---------|------------|-----------|------|
| Browser support | Native | Requires proxy | Native |
| Type safety | Protobuf | Protobuf | OpenAPI |
| Streaming | Bidirectional | Bidirectional | Limited |
| Protocol options | gRPC, gRPC-Web, HTTP/JSON | gRPC only | HTTP only |

## Consequences
- Strong type safety across frontend and backend
- Flexible protocol selection per client
- Generated clients for TypeScript, Go
- Learning curve for Protobuf
