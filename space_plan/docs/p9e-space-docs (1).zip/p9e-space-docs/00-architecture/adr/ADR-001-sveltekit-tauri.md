# ADR-001: SvelteKit + Tauri for Frontend

## Status
**Accepted** - December 2025

## Context
The platform requires both web and desktop applications.

## Decision
Use **SvelteKit 2.x** for web and **Tauri 2.x** for desktop.

## Rationale

| Factor | SvelteKit | React/Next.js |
|--------|-----------|---------------|
| Bundle size | Smallest | Larger |
| Runtime | No VDOM | VDOM |
| Performance | Excellent | Good |

| Factor | Tauri | Electron |
|--------|-------|----------|
| Bundle size | ~3-10 MB | ~150+ MB |
| Memory | Lower | Higher |
| Security | Rust backend | Node.js |

## Consequences
- Smaller application bundles
- Better performance
- Single codebase for web + desktop
- Rust knowledge required for native plugins
