# Observability

> P9E Space Platform - Logging, Metrics, Tracing & Alerting

## 1. Observability Stack

| Component | Tool | Purpose |
|-----------|------|---------|
| **Metrics** | Prometheus + Grafana | Time-series metrics, dashboards |
| **Logging** | Loki + Grafana | Log aggregation, search |
| **Tracing** | Tempo + Grafana | Distributed tracing |
| **Alerting** | Alertmanager | Alert routing, notification |

## 2. Metrics (RED Method)

```prometheus
# Rate - Requests per second
http_requests_total{service, method, path, status}

# Errors - Error rate
http_requests_total{status=~"5.."}

# Duration - Latency
http_request_duration_seconds{service, method, path}
```

### Service-Specific Metrics

```prometheus
# Platform
p9e_active_sessions{tenant_id}
p9e_auth_attempts_total{outcome, method}

# Ground Station
p9e_passes_scheduled_total{satellite_id, ground_station_id}
p9e_telemetry_frames_total{satellite_id}
p9e_commands_total{satellite_id, status}

# EO
p9e_catalog_items_total{collection_id}
p9e_processing_jobs_total{workflow_id, status}

# GEOINT
p9e_aois_total{workspace_id}
p9e_observations_total{type}
```

## 3. Logging

### Log Format (Structured JSON)

```json
{
  "timestamp": "2025-12-27T10:30:00.123Z",
  "level": "info",
  "service": "platform",
  "trace_id": "abc123def456",
  "tenant_id": "uuid",
  "user_id": "uuid",
  "message": "User logged in successfully",
  "attributes": {"email": "user@example.com", "mfa_used": true}
}
```

### Log Levels

| Level | Usage |
|-------|-------|
| DEBUG | Development only |
| INFO | Normal operations |
| WARN | Recoverable issues |
| ERROR | Failures |
| FATAL | Service termination |

## 4. Distributed Tracing

### Span Naming Convention
```
{service}.{component}.{operation}

Examples:
- platform.identity.login
- groundstation.pass.schedule
- groundstation.telemetry.stream
- eo.catalog.search
```

## 5. Alerting

### Severity Levels

| Severity | Response | Channels |
|----------|----------|----------|
| Critical | Page immediately | PagerDuty, Slack #critical |
| Warning | Review within 1h | Slack #alerts |
| Info | Daily review | Email digest |

### Critical Alerts

```yaml
- alert: ServiceDown
  expr: up == 0
  for: 1m
  labels:
    severity: critical

- alert: HighErrorRate
  expr: rate(http_requests_total{status=~"5.."}[5m]) / rate(http_requests_total[5m]) > 0.05
  for: 5m
  labels:
    severity: critical

- alert: TelemetryLag
  expr: p9e_telemetry_latency_seconds > 5
  for: 5m
  labels:
    severity: warning
```

## 6. SLIs/SLOs

| Service | Availability | Latency (p95) | Error Rate |
|---------|--------------|---------------|------------|
| API Gateway | 99.9% | < 100ms | < 0.1% |
| Platform | 99.9% | < 200ms | < 0.1% |
| Ground Station | 99.5% | < 500ms | < 0.5% |
| EO Processing | 99.0% | < 30s | < 1.0% |
| Telemetry | 99.9% | < 1s | < 0.1% |
