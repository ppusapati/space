# Data Architecture

> P9E Space Platform - Database Design & Data Management

## 1. Overview

Polyglot persistence strategy optimized for different data access patterns.

## 2. Database Technologies

| Database | Purpose | Data Types |
|----------|---------|------------|
| **PostgreSQL 16** | Primary transactional | Users, tenants, satellites, passes |
| **TimescaleDB** | Time-series telemetry | Telemetry frames, metrics |
| **PostGIS** | Geospatial data | AOIs, imagery footprints |
| **Redis 7** | Caching & sessions | Sessions, rate limits |
| **NATS JetStream** | Event streaming | Domain events |
| **S3/MinIO** | Object storage | Imagery, exports |

## 3. Schema Distribution

| Schema | Tables | Key Entities |
|--------|--------|--------------|
| `platform` | 12 | tenants, users, roles, sessions, audit_logs, api_keys |
| `groundstation` | 15 | satellites, ground_stations, passes, telemetry, commands |
| `satellite` | 8 | spacecraft, subsystems, orbit_states, maneuvers, conjunctions |
| `eo` | 10 | collections, items, assets, processing_jobs, models |
| `geoint` | 10 | workspaces, aois, observations, reports |
| `common` | 7 | exports, dashboards, schedules, webhooks |

## 4. Platform Schema

```sql
-- Tenants
CREATE TABLE platform.tenants (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(100) NOT NULL UNIQUE,
    status tenant_status NOT NULL DEFAULT 'pending',
    tier subscription_tier NOT NULL DEFAULT 'free',
    settings JSONB NOT NULL DEFAULT '{}',
    quotas JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Users
CREATE TABLE platform.users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES platform.tenants(id),
    email VARCHAR(255) NOT NULL,
    password_hash VARCHAR(255),
    status user_status NOT NULL DEFAULT 'active',
    mfa_enabled BOOLEAN NOT NULL DEFAULT FALSE,
    CONSTRAINT unique_email_per_tenant UNIQUE (tenant_id, email)
);

-- Row-Level Security
ALTER TABLE platform.users ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON platform.users
    USING (tenant_id = current_setting('app.tenant_id')::uuid);
```

## 5. Ground Station Schema

```sql
-- Satellites
CREATE TABLE groundstation.satellites (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES platform.tenants(id),
    norad_id INTEGER NOT NULL,
    name VARCHAR(255) NOT NULL,
    status satellite_status NOT NULL DEFAULT 'operational',
    downlink_freq_mhz DECIMAL(10,4),
    CONSTRAINT unique_norad_per_tenant UNIQUE (tenant_id, norad_id)
);

-- Pass Schedules
CREATE TABLE groundstation.pass_schedules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    satellite_id UUID NOT NULL REFERENCES groundstation.satellites(id),
    ground_station_id UUID NOT NULL,
    predicted_aos TIMESTAMPTZ NOT NULL,
    predicted_los TIMESTAMPTZ NOT NULL,
    max_elevation DECIMAL(5,2) NOT NULL,
    status pass_status NOT NULL DEFAULT 'scheduled'
);
```

## 6. Telemetry (TimescaleDB)

```sql
-- Raw telemetry hypertable
CREATE TABLE groundstation.telemetry_raw (
    time TIMESTAMPTZ NOT NULL,
    satellite_id UUID NOT NULL,
    parameter_id VARCHAR(50) NOT NULL,
    value DOUBLE PRECISION NOT NULL,
    quality telemetry_quality NOT NULL DEFAULT 'good',
    PRIMARY KEY (satellite_id, parameter_id, time)
);

SELECT create_hypertable('groundstation.telemetry_raw', 'time',
    chunk_time_interval => INTERVAL '1 minute');

-- Continuous aggregates
CREATE MATERIALIZED VIEW groundstation.telemetry_1min
WITH (timescaledb.continuous) AS
SELECT time_bucket('1 minute', time) AS bucket,
       satellite_id, parameter_id,
       AVG(value), MIN(value), MAX(value), COUNT(*)
FROM groundstation.telemetry_raw
GROUP BY bucket, satellite_id, parameter_id;

-- Retention policies
SELECT add_retention_policy('groundstation.telemetry_raw', INTERVAL '7 days');
SELECT add_retention_policy('groundstation.telemetry_1min', INTERVAL '90 days');
```

## 7. EO Schema (PostGIS)

```sql
-- STAC Collections
CREATE TABLE eo.collections (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL,
    stac_id VARCHAR(255) NOT NULL,
    title VARCHAR(255) NOT NULL,
    extent_spatial GEOMETRY(POLYGON, 4326),
    extent_temporal TSTZRANGE
);

-- STAC Items
CREATE TABLE eo.items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    collection_id UUID NOT NULL REFERENCES eo.collections(id),
    stac_id VARCHAR(255) NOT NULL,
    geometry GEOMETRY(GEOMETRY, 4326) NOT NULL,
    datetime TIMESTAMPTZ NOT NULL,
    cloud_cover DECIMAL(5,2)
);

CREATE INDEX idx_items_geometry ON eo.items USING GIST (geometry);
```

## 8. Data Retention

| Data Type | Hot | Warm | Cold | Archive |
|-----------|-----|------|------|---------|
| Telemetry Raw | 7 days | - | - | Deleted |
| Telemetry 1min | 90 days | - | - | Deleted |
| Telemetry 1hour | 5 years | - | - | S3 Glacier |
| Audit Logs | 90 days | 1 year | 7 years | S3 Glacier |
| Imagery | 90 days | 1 year | - | S3 Glacier |

## 9. Backup & Recovery

| Component | Method | Frequency | Retention |
|-----------|--------|-----------|-----------|
| PostgreSQL | pg_dump + WAL | Continuous | 30 days |
| TimescaleDB | Native backup | Daily | 30 days |
| Redis | RDB + AOF | Hourly | 7 days |
| S3 | Cross-region replication | Continuous | Indefinite |

**RPO**: 1 hour | **RTO**: 4 hours
