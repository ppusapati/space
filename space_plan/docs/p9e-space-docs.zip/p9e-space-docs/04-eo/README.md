# Earth Observation Module

> Imagery Catalog, Processing Pipelines & ML Inference

## Overview

The Earth Observation (EO) module provides STAC-compliant imagery cataloging, processing workflow management, and machine learning model deployment and inference.

## Services

| Service | RPCs | Description |
|---------|------|-------------|
| [CatalogService](./api/catalog-service.md) | 7 | STAC catalog search and management |
| [ProcessingService](./api/processing-service.md) | 8 | Image processing pipelines |
| [MLService](./api/ml-service.md) | 10 | Model management and inference |
| **Total** | **25** | |

## Key Concepts

### STAC Compliance
- **Collections**: Groups of related items (e.g., Sentinel-2 L2A)
- **Items**: Individual scenes with metadata
- **Assets**: Actual data files (COG, GeoTIFF)

### Processing Pipelines
- Orthorectification
- Pansharpening
- Atmospheric correction
- Index calculation (NDVI, NDWI)
- Mosaicking

### ML Workflows
- Model training (external)
- Model registration and versioning
- Deployment to inference endpoints
- Batch and streaming inference
- Object detection, classification, segmentation, change detection

## Processing Job States
```
PENDING → RUNNING → COMPLETED
                  → FAILED → RETRYING → RUNNING
       → CANCELLED
```

## Integrations
- [Sentinel Hub](./integrations/sentinel-hub.md) - ESA imagery
- [NOAA/USGS](./integrations/noaa-usgs.md) - Weather, elevation
- [Object Storage](./integrations/object-storage.md) - S3/MinIO

## Related Documents
- [GEOINT Module](../05-geoint/README.md)
- [Data Architecture](../00-architecture/data-architecture.md)
