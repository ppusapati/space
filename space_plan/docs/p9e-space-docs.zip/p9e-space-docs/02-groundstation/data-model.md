# Ground Station Module - Data Model

## Overview

The Ground Station module uses PostgreSQL for relational data and TimescaleDB for time-series telemetry.

## Schema: `groundstation`

### Entity Relationship Diagram

```
┌───────────────┐       ┌───────────────┐       ┌───────────────┐
│  satellites   │       │ ground_stations│      │ pass_schedules│
├───────────────┤       ├───────────────┤       ├───────────────┤
│ id (PK)       │       │ id (PK)       │       │ id (PK)       │
│ tenant_id     │       │ tenant_id     │       │ tenant_id     │
│ norad_id      │◄──────│ name          │◄──────│ satellite_id  │
│ name          │       │ latitude      │       │ ground_stn_id │
│ status        │       │ longitude     │       │ predicted_aos │
└───────┬───────┘       │ min_elevation │       │ predicted_los │
        │               └───────────────┘       │ max_elevation │
        │                                       │ status        │
        ▼                                       └───────┬───────┘
┌───────────────┐                                       │
│  tle_history  │                                       ▼
├───────────────┤                               ┌───────────────┐
│ id (PK)       │                               │pass_executions│
│ satellite_id  │                               ├───────────────┤
│ line1         │                               │ id (PK)       │
│ line2         │                               │ schedule_id   │
│ epoch         │                               │ actual_aos    │
└───────────────┘                               │ actual_los    │
                                                │ status        │
        ┌───────────────────────────────────────┴───────────────┐
        │                                                       │
        ▼                                                       ▼
┌───────────────┐       ┌───────────────┐       ┌───────────────┐
│   commands    │       │telemetry_raw  │       │   anomalies   │
├───────────────┤       ├───────────────┤       ├───────────────┤
│ id (PK)       │       │ time          │       │ id (PK)       │
│ satellite_id  │       │ satellite_id  │       │ satellite_id  │
│ mnemonic      │       │ parameter_id  │       │ type          │
│ hazard_level  │       │ value         │       │ severity      │
│ status        │       │ quality       │       │ status        │
│ submitted_by  │       └───────────────┘       │ detected_at   │
│ approved_by   │             ▲                 └───────────────┘
└───────────────┘             │
                              │ (TimescaleDB Hypertable)
                    ┌─────────┴─────────┐
                    │                   │
            ┌───────────────┐   ┌───────────────┐
            │telemetry_1min │   │telemetry_1hour│
            └───────────────┘   └───────────────┘
```

## Tables

### satellites

Satellite catalog with frequencies and configuration.

```sql
CREATE TABLE groundstation.satellites (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES platform.tenants(id),
    norad_id        INTEGER NOT NULL,
    cospar_id       VARCHAR(20),
    name            VARCHAR(255) NOT NULL,
    mission_type    mission_type NOT NULL,
    status          satellite_status NOT NULL DEFAULT 'operational',
    spacecraft_id   UUID REFERENCES satellite.spacecraft(id),
    uplink_freq_mhz DECIMAL(10,4),
    downlink_freq_mhz DECIMAL(10,4),
    modulation      VARCHAR(50),
    data_rate_bps   INTEGER,
    config          JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    CONSTRAINT unique_norad_per_tenant UNIQUE (tenant_id, norad_id)
);

CREATE INDEX idx_satellites_tenant ON groundstation.satellites(tenant_id);
CREATE INDEX idx_satellites_norad ON groundstation.satellites(norad_id);
CREATE INDEX idx_satellites_status ON groundstation.satellites(status);
```

### tle_history

Two-Line Element set history for orbit prediction.

```sql
CREATE TABLE groundstation.tle_history (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    satellite_id    UUID NOT NULL REFERENCES groundstation.satellites(id),
    line1           VARCHAR(69) NOT NULL,
    line2           VARCHAR(69) NOT NULL,
    epoch           TIMESTAMPTZ NOT NULL,
    source          VARCHAR(50) NOT NULL DEFAULT 'space-track',
    fetched_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    CONSTRAINT unique_tle_epoch UNIQUE (satellite_id, epoch)
);

CREATE INDEX idx_tle_satellite_epoch ON groundstation.tle_history(satellite_id, epoch DESC);
```

### ground_stations

Ground station locations and capabilities.

```sql
CREATE TABLE groundstation.ground_stations (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES platform.tenants(id),
    name            VARCHAR(255) NOT NULL,
    code            VARCHAR(10) NOT NULL,
    latitude        DECIMAL(9,6) NOT NULL,
    longitude       DECIMAL(9,6) NOT NULL,
    altitude_m      DECIMAL(10,2) NOT NULL DEFAULT 0,
    min_elevation   DECIMAL(5,2) NOT NULL DEFAULT 5.0,
    max_elevation   DECIMAL(5,2) NOT NULL DEFAULT 90.0,
    capabilities    TEXT[] NOT NULL DEFAULT '{}',
    antennas        JSONB NOT NULL DEFAULT '[]',
    status          gs_status NOT NULL DEFAULT 'operational',
    timezone        VARCHAR(50) NOT NULL DEFAULT 'UTC',
    config          JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    CONSTRAINT valid_lat CHECK (latitude BETWEEN -90 AND 90),
    CONSTRAINT valid_lon CHECK (longitude BETWEEN -180 AND 180),
    CONSTRAINT unique_code_per_tenant UNIQUE (tenant_id, code)
);
```

### pass_schedules

Scheduled satellite passes.

```sql
CREATE TABLE groundstation.pass_schedules (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES platform.tenants(id),
    satellite_id    UUID NOT NULL REFERENCES groundstation.satellites(id),
    ground_station_id UUID NOT NULL REFERENCES groundstation.ground_stations(id),
    predicted_aos   TIMESTAMPTZ NOT NULL,
    predicted_los   TIMESTAMPTZ NOT NULL,
    predicted_tca   TIMESTAMPTZ NOT NULL,
    max_elevation   DECIMAL(5,2) NOT NULL,
    aos_azimuth     DECIMAL(5,2),
    los_azimuth     DECIMAL(5,2),
    duration_seconds INTEGER GENERATED ALWAYS AS (EXTRACT(EPOCH FROM predicted_los - predicted_aos)) STORED,
    status          pass_status NOT NULL DEFAULT 'scheduled',
    priority        INTEGER NOT NULL DEFAULT 5,
    mission_type    VARCHAR(50),
    notes           TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by      UUID REFERENCES platform.users(id),
    
    CONSTRAINT valid_time_range CHECK (predicted_los > predicted_aos),
    CONSTRAINT valid_elevation CHECK (max_elevation BETWEEN 0 AND 90)
);

CREATE INDEX idx_passes_time ON groundstation.pass_schedules(predicted_aos, predicted_los);
CREATE INDEX idx_passes_satellite ON groundstation.pass_schedules(satellite_id, predicted_aos);
CREATE INDEX idx_passes_gs ON groundstation.pass_schedules(ground_station_id, predicted_aos);
CREATE INDEX idx_passes_status ON groundstation.pass_schedules(status) WHERE status IN ('scheduled', 'in_progress');
```

### pass_executions

Pass execution records.

```sql
CREATE TABLE groundstation.pass_executions (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    schedule_id     UUID NOT NULL REFERENCES groundstation.pass_schedules(id),
    actual_aos      TIMESTAMPTZ,
    actual_los      TIMESTAMPTZ,
    status          execution_status NOT NULL DEFAULT 'pending',
    telemetry_frames INTEGER NOT NULL DEFAULT 0,
    telemetry_bytes BIGINT NOT NULL DEFAULT 0,
    commands_sent   INTEGER NOT NULL DEFAULT 0,
    commands_acked  INTEGER NOT NULL DEFAULT 0,
    max_signal_dbm  DECIMAL(6,2),
    avg_signal_dbm  DECIMAL(6,2),
    doppler_hz      INTEGER,
    errors          JSONB,
    notes           TEXT,
    completed_at    TIMESTAMPTZ
);

CREATE INDEX idx_executions_schedule ON groundstation.pass_executions(schedule_id);
```

### commands

Command submissions and approvals.

```sql
CREATE TABLE groundstation.commands (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES platform.tenants(id),
    satellite_id    UUID NOT NULL REFERENCES groundstation.satellites(id),
    command_def_id  UUID NOT NULL REFERENCES groundstation.command_definitions(id),
    mnemonic        VARCHAR(50) NOT NULL,
    parameters      JSONB NOT NULL DEFAULT '{}',
    hazard_level    hazard_level NOT NULL,
    status          command_status NOT NULL DEFAULT 'pending',
    justification   TEXT,
    scheduled_for   TIMESTAMPTZ,
    submitted_by    UUID NOT NULL REFERENCES platform.users(id),
    submitted_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    approved_by     UUID REFERENCES platform.users(id),
    approved_at     TIMESTAMPTZ,
    rejected_by     UUID REFERENCES platform.users(id),
    rejected_at     TIMESTAMPTZ,
    rejection_reason TEXT,
    sent_at         TIMESTAMPTZ,
    acked_at        TIMESTAMPTZ,
    pass_id         UUID REFERENCES groundstation.pass_schedules(id),
    response        JSONB,
    expires_at      TIMESTAMPTZ,
    
    CONSTRAINT two_person_auth CHECK (
        (hazard_level IN ('safe', 'caution') OR approved_by IS NULL OR approved_by != submitted_by)
    )
);

CREATE INDEX idx_commands_satellite ON groundstation.commands(satellite_id, submitted_at DESC);
CREATE INDEX idx_commands_status ON groundstation.commands(status) 
    WHERE status IN ('pending', 'awaiting_approval', 'approved', 'queued');
CREATE INDEX idx_commands_pass ON groundstation.commands(pass_id) WHERE pass_id IS NOT NULL;
```

### command_definitions

Command catalog with parameter schemas.

```sql
CREATE TABLE groundstation.command_definitions (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    satellite_id    UUID NOT NULL REFERENCES groundstation.satellites(id),
    mnemonic        VARCHAR(50) NOT NULL,
    name            VARCHAR(255) NOT NULL,
    description     TEXT,
    hazard_level    hazard_level NOT NULL DEFAULT 'safe',
    parameters      JSONB NOT NULL DEFAULT '[]',  -- JSON Schema
    validation_rules JSONB,
    requires_approval BOOLEAN NOT NULL DEFAULT FALSE,
    enabled         BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    CONSTRAINT unique_mnemonic UNIQUE (satellite_id, mnemonic)
);
```

## Telemetry Tables (TimescaleDB)

### telemetry_raw

Raw telemetry hypertable.

```sql
CREATE TABLE groundstation.telemetry_raw (
    time            TIMESTAMPTZ NOT NULL,
    satellite_id    UUID NOT NULL,
    parameter_id    VARCHAR(50) NOT NULL,
    value           DOUBLE PRECISION NOT NULL,
    raw_value       BIGINT,
    quality         telemetry_quality NOT NULL DEFAULT 'good',
    
    PRIMARY KEY (satellite_id, parameter_id, time)
);

-- Convert to hypertable
SELECT create_hypertable('groundstation.telemetry_raw', 'time',
    chunk_time_interval => INTERVAL '1 minute',
    partitioning_column => 'satellite_id',
    number_partitions => 4
);

-- Compression policy
ALTER TABLE groundstation.telemetry_raw SET (
    timescaledb.compress,
    timescaledb.compress_segmentby = 'satellite_id,parameter_id',
    timescaledb.compress_orderby = 'time DESC'
);
SELECT add_compression_policy('groundstation.telemetry_raw', INTERVAL '1 hour');

-- Retention policy
SELECT add_retention_policy('groundstation.telemetry_raw', INTERVAL '7 days');
```

### Continuous Aggregates

```sql
-- 1-minute rollup
CREATE MATERIALIZED VIEW groundstation.telemetry_1min
WITH (timescaledb.continuous) AS
SELECT
    time_bucket('1 minute', time) AS bucket,
    satellite_id,
    parameter_id,
    AVG(value) AS avg_value,
    MIN(value) AS min_value,
    MAX(value) AS max_value,
    COUNT(*) AS sample_count,
    STDDEV(value) AS stddev_value
FROM groundstation.telemetry_raw
GROUP BY bucket, satellite_id, parameter_id
WITH NO DATA;

-- 1-hour rollup
CREATE MATERIALIZED VIEW groundstation.telemetry_1hour
WITH (timescaledb.continuous) AS
SELECT
    time_bucket('1 hour', bucket) AS bucket,
    satellite_id,
    parameter_id,
    AVG(avg_value) AS avg_value,
    MIN(min_value) AS min_value,
    MAX(max_value) AS max_value,
    SUM(sample_count) AS sample_count
FROM groundstation.telemetry_1min
GROUP BY time_bucket('1 hour', bucket), satellite_id, parameter_id
WITH NO DATA;

-- Retention policies
SELECT add_retention_policy('groundstation.telemetry_1min', INTERVAL '90 days');
SELECT add_retention_policy('groundstation.telemetry_1hour', INTERVAL '5 years');
```

### anomalies

Detected anomalies.

```sql
CREATE TABLE groundstation.anomalies (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES platform.tenants(id),
    satellite_id    UUID NOT NULL REFERENCES groundstation.satellites(id),
    type            anomaly_type NOT NULL,
    severity        severity_level NOT NULL,
    status          anomaly_status NOT NULL DEFAULT 'open',
    title           VARCHAR(255) NOT NULL,
    description     TEXT,
    parameter_id    VARCHAR(50),
    expected_value  DOUBLE PRECISION,
    actual_value    DOUBLE PRECISION,
    threshold       DOUBLE PRECISION,
    detected_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    acknowledged_at TIMESTAMPTZ,
    acknowledged_by UUID REFERENCES platform.users(id),
    resolved_at     TIMESTAMPTZ,
    resolved_by     UUID REFERENCES platform.users(id),
    resolution_notes TEXT
);

CREATE INDEX idx_anomalies_satellite ON groundstation.anomalies(satellite_id, detected_at DESC);
CREATE INDEX idx_anomalies_status ON groundstation.anomalies(status) WHERE status = 'open';
```

## Enums

```sql
CREATE TYPE mission_type AS ENUM ('eo', 'comms', 'science', 'tech_demo', 'navigation');
CREATE TYPE satellite_status AS ENUM ('commissioning', 'operational', 'degraded', 'safe_mode', 'decommissioned');
CREATE TYPE gs_status AS ENUM ('operational', 'maintenance', 'offline');
CREATE TYPE pass_status AS ENUM ('predicted', 'scheduled', 'confirmed', 'in_progress', 'completed', 'cancelled', 'failed');
CREATE TYPE execution_status AS ENUM ('pending', 'preparing', 'tracking', 'aos', 'los', 'completed', 'failed', 'aborted');
CREATE TYPE hazard_level AS ENUM ('safe', 'caution', 'critical');
CREATE TYPE command_status AS ENUM ('draft', 'pending', 'awaiting_approval', 'approved', 'rejected', 'queued', 'sent', 'acked', 'failed', 'expired');
CREATE TYPE telemetry_quality AS ENUM ('good', 'suspect', 'bad', 'missing');
CREATE TYPE anomaly_type AS ENUM ('limit_violation', 'trend', 'missing_data', 'correlation', 'prediction');
CREATE TYPE severity_level AS ENUM ('info', 'warning', 'critical');
CREATE TYPE anomaly_status AS ENUM ('open', 'acknowledged', 'resolved', 'false_positive');
```

## Indexes Summary

| Table | Index | Purpose |
|-------|-------|---------|
| satellites | idx_satellites_norad | NORAD ID lookup |
| tle_history | idx_tle_satellite_epoch | Latest TLE query |
| pass_schedules | idx_passes_time | Time-based queries |
| pass_schedules | idx_passes_satellite | Satellite passes |
| commands | idx_commands_status | Pending commands |
| telemetry_raw | TimescaleDB chunks | Time-series queries |
| anomalies | idx_anomalies_status | Open anomalies |
