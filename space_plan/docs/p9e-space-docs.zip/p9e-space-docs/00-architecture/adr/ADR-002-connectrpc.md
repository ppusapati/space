# ADR-002: ConnectRPC for API Communication

## Status
**Accepted** - December 2025

## Context
The platform requires an API protocol that supports:
- Strong typing with code generation
- Browser compatibility (SvelteKit web app)
- High-performance binary protocol (desktop, server-to-server)
- Streaming for real-time telemetry
- Good developer experience

Options evaluated:
1. REST with OpenAPI
2. Pure gRPC with grpc-web
3. ConnectRPC (Buf)
4. GraphQL

## Decision
We will use **ConnectRPC** (from Buf) as our primary API protocol.

## Rationale

### ConnectRPC Advantages
| Feature | ConnectRPC | Pure gRPC | REST |
|---------|------------|-----------|------|
| Browser support | Native | Requires proxy | Native |
| Type safety | Protobuf | Protobuf | OpenAPI (weaker) |
| Streaming | Bidirectional | Bidirectional | Limited (SSE) |
| Protocol options | gRPC, gRPC-Web, HTTP/JSON | gRPC only | HTTP only |
| Code generation | Full-stack | Full-stack | Partial |
| Debugging | cURL-friendly JSON | Binary | cURL-friendly |

### Protocol Flexibility
ConnectRPC supports three wire protocols with the same service definition:
1. **gRPC** - Binary, efficient (server-to-server)
2. **gRPC-Web** - Browser-compatible gRPC
3. **Connect Protocol** - HTTP/JSON, cURL-friendly

```protobuf
// Single definition serves all protocols
service IdentityService {
  rpc Login(LoginRequest) returns (LoginResponse);
}
```

### Buf Ecosystem Integration
- `buf` CLI for linting, breaking change detection
- Buf Schema Registry for schema management
- `protoc-gen-validate` for validation
- `grpc-gateway` for OpenAPI generation

## Consequences

### Positive
- Strong type safety across frontend and backend
- Flexible protocol selection per client type
- Excellent streaming support for telemetry
- Generated clients for TypeScript, Go
- Self-documenting via Protobuf

### Negative
- Learning curve for Protobuf
- Build step for code generation
- Smaller ecosystem than REST
- Fewer off-the-shelf tools

### Migration Path
Existing REST clients can use Connect Protocol (HTTP/JSON) which is fully REST-compatible with standard HTTP semantics.

## Implementation

### Service Definition
```protobuf
syntax = "proto3";
package platform.v1;

service IdentityService {
  rpc Login(LoginRequest) returns (LoginResponse) {
    option (google.api.http) = {
      post: "/v1/auth/login"
      body: "*"
    };
  }
}
```

### Go Server
```go
mux := http.NewServeMux()
mux.Handle(identityv1connect.NewIdentityServiceHandler(
    &IdentityServiceServer{},
    connect.WithInterceptors(authInterceptor),
))
```

### TypeScript Client
```typescript
const client = createPromiseClient(
  IdentityService,
  createConnectTransport({ baseUrl: "https://api.p9e.space" })
);
const response = await client.login({ email, password });
```
