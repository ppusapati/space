# ADR-001: SvelteKit + Tauri for Frontend

## Status
**Accepted** - December 2025

## Context
The P9E Space Platform requires both web and desktop applications for different user scenarios:
- Web application for general access
- Desktop application for ground station operations (local hardware access)
- Potential mobile application for monitoring

We evaluated multiple approaches:
1. Separate codebases (React web + Electron desktop)
2. Unified codebase with Electron
3. Unified codebase with SvelteKit + Tauri

## Decision
We will use **SvelteKit 2.x** for the web framework and **Tauri 2.x** for desktop packaging.

## Rationale

### Why SvelteKit?
| Factor | SvelteKit | React/Next.js | Vue/Nuxt |
|--------|-----------|---------------|----------|
| Bundle size | Smallest | Larger | Medium |
| Runtime overhead | Minimal (no VDOM) | VDOM reconciliation | VDOM |
| Learning curve | Simpler | Complex ecosystem | Moderate |
| SSR/SSG | Built-in | Built-in | Built-in |
| Performance | Excellent | Good | Good |

### Why Tauri over Electron?
| Factor | Tauri | Electron |
|--------|-------|----------|
| Bundle size | ~3-10 MB | ~150+ MB |
| Memory usage | Lower (system webview) | Higher (bundled Chromium) |
| Security | Stronger (Rust backend) | Weaker (Node.js) |
| Native access | Rust plugins | Node.js |
| Startup time | Faster | Slower |

### Unified Codebase Benefits
- Single codebase for web + desktop + mobile
- Shared components and state management
- Consistent user experience
- Reduced development effort

## Consequences

### Positive
- Significantly smaller application bundles
- Better performance on resource-constrained systems
- Strong security model via Rust
- Simplified maintenance with single codebase

### Negative
- Tauri ecosystem less mature than Electron
- Rust knowledge required for native plugins
- Platform-specific webview quirks
- Smaller community than React

### Risks & Mitigations
| Risk | Mitigation |
|------|------------|
| Tauri API changes | Pin versions, follow stable releases |
| WebView inconsistencies | Extensive cross-platform testing |
| Limited Tauri plugins | Develop custom Rust plugins as needed |

## Alternatives Considered

### Electron
Rejected due to large bundle size and resource consumption, which is problematic for ground station operations where resources may be limited.

### Flutter
Rejected due to Dart language requirement and less suitable for complex web dashboards.

### Native Applications
Rejected due to triple development effort (web + Windows + Linux/Mac).
