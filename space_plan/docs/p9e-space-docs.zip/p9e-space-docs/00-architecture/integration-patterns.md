# Integration Patterns

> P9E Space Platform - External System Integration Architecture

## 1. Overview

The P9E Space Platform integrates with 12+ external systems for space data, imagery, hardware control, identity, billing, and notifications. This document defines the patterns, protocols, and resilience mechanisms used.

## 2. Integration Catalog

| # | System | Category | Protocol | Purpose |
|---|--------|----------|----------|---------|
| 1 | Space-Track.org | Space Data | REST | TLE, CDM, decay data |
| 2 | Sentinel Hub | EO Imagery | REST/OAuth | Satellite imagery |
| 3 | AWS Ground Station | Hardware | AWS SDK | Contact scheduling |
| 4 | NOAA Weather | Data | REST | Weather forecasts |
| 5 | USGS Elevation | Data | REST | DEM data |
| 6 | SDR Hardware | Hardware | ZMQ/TCP | RF reception |
| 7 | Antenna Rotator | Hardware | Serial/Hamlib | Antenna pointing |
| 8 | External IdP | Identity | OIDC | SSO federation |
| 9 | SIEM | Security | Syslog/CEF | Security logging |
| 10 | Stripe | Billing | REST | Subscriptions |
| 11 | AWS SES | Notification | AWS SDK | Email delivery |
| 12 | AWS SNS | Notification | AWS SDK | SMS delivery |
| 13 | S3/MinIO | Storage | S3 API | Object storage |

## 3. Integration Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        P9E PLATFORM CORE                                    │
├─────────────────────────────────────────────────────────────────────────────┤
│                              │                                              │
│              ┌───────────────┼───────────────┐                              │
│              │               │               │                              │
│              ▼               ▼               ▼                              │
│  ┌───────────────────┐ ┌───────────────────┐ ┌───────────────────┐         │
│  │   ADAPTER LAYER   │ │   GATEWAY LAYER   │ │    ACL LAYER      │         │
│  │                   │ │                   │ │                   │         │
│  │ • Protocol Conv   │ │ • Rate Limiting   │ │ • Data Transform  │         │
│  │ • Hardware I/O    │ │ • Caching         │ │ • Model Mapping   │         │
│  │ • Stream Handling │ │ • Auth Handling   │ │ • Validation      │         │
│  └─────────┬─────────┘ └─────────┬─────────┘ └─────────┬─────────┘         │
│            │                     │                     │                    │
│  ┌─────────┴─────────────────────┴─────────────────────┴─────────┐         │
│  │                    RESILIENCE LAYER                           │         │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐         │         │
│  │  │ Circuit  │ │  Retry   │ │ Timeout  │ │ Bulkhead │         │         │
│  │  │ Breaker  │ │ + Backoff│ │          │ │          │         │         │
│  │  └──────────┘ └──────────┘ └──────────┘ └──────────┘         │         │
│  └───────────────────────────────────────────────────────────────┘         │
│            │                     │                     │                    │
└────────────┼─────────────────────┼─────────────────────┼────────────────────┘
             │                     │                     │
             ▼                     ▼                     ▼
    ┌────────────────┐    ┌────────────────┐    ┌────────────────┐
    │   Hardware     │    │   External     │    │   Cloud        │
    │   Systems      │    │   APIs         │    │   Services     │
    │                │    │                │    │                │
    │ • SDR          │    │ • Space-Track  │    │ • AWS          │
    │ • Antenna      │    │ • Sentinel Hub │    │ • Stripe       │
    │ • TNC          │    │ • NOAA/USGS    │    │ • IdP          │
    └────────────────┘    └────────────────┘    └────────────────┘
```

## 4. Integration Patterns

### 4.1 Adapter Pattern

Used for hardware interfaces and protocol conversion.

```go
// Adapter interface
type SDRController interface {
    SetFrequency(freq float64) error
    SetSampleRate(rate float64) error
    StartStream(ctx context.Context) (<-chan []complex64, error)
    StopStream() error
}

// USRP implementation
type USRPAdapter struct {
    device *uhd.USRP
}

func (a *USRPAdapter) SetFrequency(freq float64) error {
    return a.device.SetRxFreq(freq)
}

// RTL-SDR implementation
type RTLSDRAdapter struct {
    device *rtl.Device
}

func (a *RTLSDRAdapter) SetFrequency(freq float64) error {
    return a.device.SetCenterFreq(uint32(freq))
}
```

### 4.2 Gateway Pattern

Used for external API aggregation with caching and rate limiting.

```go
// Gateway with caching
type SpaceTrackGateway struct {
    client  *SpaceTrackClient
    cache   *redis.Client
    limiter *rate.Limiter
}

func (g *SpaceTrackGateway) GetTLE(ctx context.Context, noradID int) (*TLE, error) {
    // Check cache first
    cacheKey := fmt.Sprintf("tle:%d", noradID)
    if cached, err := g.cache.Get(ctx, cacheKey).Result(); err == nil {
        return parseCachedTLE(cached), nil
    }
    
    // Rate limit
    if err := g.limiter.Wait(ctx); err != nil {
        return nil, err
    }
    
    // Fetch from API
    tle, err := g.client.FetchTLE(ctx, noradID)
    if err != nil {
        return nil, err
    }
    
    // Cache for 1 hour
    g.cache.Set(ctx, cacheKey, tle.Serialize(), time.Hour)
    
    return tle, nil
}
```

### 4.3 Anti-Corruption Layer (ACL)

Used to isolate domain model from external system models.

```go
// External model (Space-Track)
type SpaceTrackTLE struct {
    NoradCatID    string `json:"NORAD_CAT_ID"`
    TLELine1      string `json:"TLE_LINE1"`
    TLELine2      string `json:"TLE_LINE2"`
    Epoch         string `json:"EPOCH"`
    ObjectName    string `json:"OBJECT_NAME"`
}

// Domain model
type TLE struct {
    NoradID int
    Line1   string
    Line2   string
    Epoch   time.Time
}

// ACL translator
type TLETranslator struct{}

func (t *TLETranslator) ToDomain(ext *SpaceTrackTLE) (*TLE, error) {
    noradID, _ := strconv.Atoi(ext.NoradCatID)
    epoch, _ := time.Parse("2006-01-02T15:04:05", ext.Epoch)
    
    return &TLE{
        NoradID: noradID,
        Line1:   ext.TLELine1,
        Line2:   ext.TLELine2,
        Epoch:   epoch,
    }, nil
}
```

## 5. Resilience Patterns

### 5.1 Circuit Breaker

```go
type CircuitBreaker struct {
    name        string
    maxFailures int           // 5
    timeout     time.Duration // 30s
    state       State         // Closed, Open, HalfOpen
    failures    int
    lastFailure time.Time
}

func (cb *CircuitBreaker) Execute(fn func() error) error {
    if cb.state == StateOpen {
        if time.Since(cb.lastFailure) > cb.timeout {
            cb.state = StateHalfOpen
        } else {
            return ErrCircuitOpen
        }
    }
    
    err := fn()
    
    if err != nil {
        cb.failures++
        cb.lastFailure = time.Now()
        if cb.failures >= cb.maxFailures {
            cb.state = StateOpen
        }
        return err
    }
    
    // Success - reset
    cb.state = StateClosed
    cb.failures = 0
    return nil
}
```

### 5.2 Retry with Exponential Backoff

```go
type RetryConfig struct {
    MaxAttempts    int           // 3
    InitialBackoff time.Duration // 100ms
    MaxBackoff     time.Duration // 10s
    BackoffFactor  float64       // 2.0
}

func Retry(ctx context.Context, cfg RetryConfig, fn func() error) error {
    backoff := cfg.InitialBackoff
    
    for attempt := 1; attempt <= cfg.MaxAttempts; attempt++ {
        err := fn()
        if err == nil {
            return nil
        }
        
        if !isRetryable(err) {
            return err
        }
        
        if attempt < cfg.MaxAttempts {
            jitter := time.Duration(rand.Float64() * float64(backoff) * 0.3)
            select {
            case <-time.After(backoff + jitter):
            case <-ctx.Done():
                return ctx.Err()
            }
            
            backoff = time.Duration(float64(backoff) * cfg.BackoffFactor)
            if backoff > cfg.MaxBackoff {
                backoff = cfg.MaxBackoff
            }
        }
    }
    
    return fmt.Errorf("max retries exceeded")
}
```

### 5.3 Bulkhead (Concurrency Limiting)

```go
type Bulkhead struct {
    semaphore chan struct{}
    timeout   time.Duration
}

func NewBulkhead(maxConcurrent int, timeout time.Duration) *Bulkhead {
    return &Bulkhead{
        semaphore: make(chan struct{}, maxConcurrent),
        timeout:   timeout,
    }
}

func (b *Bulkhead) Execute(ctx context.Context, fn func() error) error {
    select {
    case b.semaphore <- struct{}{}:
        defer func() { <-b.semaphore }()
        return fn()
    case <-time.After(b.timeout):
        return ErrBulkheadFull
    case <-ctx.Done():
        return ctx.Err()
    }
}
```

### 5.4 Combined Resilience

```go
func ResilientCall(ctx context.Context, cfg Config, fn func() error) error {
    return cfg.Bulkhead.Execute(ctx, func() error {
        return cfg.CircuitBreaker.Execute(func() error {
            return Retry(ctx, cfg.RetryConfig, func() error {
                return WithTimeout(ctx, cfg.Timeout, fn)
            })
        })
    })
}
```

## 6. Authentication Methods

| System | Method | Token Lifetime |
|--------|--------|----------------|
| Space-Track | Session cookie | 2 hours |
| Sentinel Hub | OAuth 2.0 Client Credentials | 1 hour |
| AWS Services | IAM SigV4 | Request-scoped |
| External IdP | OIDC PKCE | Per session |
| Stripe | API Key | N/A |
| SIEM | mTLS | Certificate-based |

## 7. Error Handling

### 7.1 Error Categories

| Category | Retry | Examples |
|----------|-------|----------|
| **Transient** | Yes | Network timeout, 503, rate limit |
| **Permanent** | No | 400, 401, 404 |
| **Circuit Open** | Wait | Service unavailable |

### 7.2 Error Response Mapping

```go
func mapExternalError(err error) error {
    var httpErr *HTTPError
    if errors.As(err, &httpErr) {
        switch httpErr.StatusCode {
        case 401:
            return ErrAuthExpired
        case 403:
            return ErrPermissionDenied
        case 404:
            return ErrNotFound
        case 429:
            return ErrRateLimited
        case 503:
            return ErrServiceUnavailable
        default:
            return ErrInternal
        }
    }
    return err
}
```

## 8. Health Checks

| Integration | Check Method | Interval |
|-------------|--------------|----------|
| Space-Track | Login + query | 5 min |
| Sentinel Hub | Token refresh | 5 min |
| AWS Ground Station | ListGroundStations | 5 min |
| SDR Hardware | Device ping | 30 sec |
| Antenna Rotator | Position query | 10 sec |
| External IdP | OIDC discovery | 5 min |
| Stripe | Balance check | 5 min |
| S3/MinIO | HeadBucket | 1 min |

## 9. Monitoring

### 9.1 Metrics

```prometheus
# Request metrics
integration_requests_total{integration, method, status}
integration_latency_seconds{integration, method}

# Circuit breaker
integration_circuit_state{integration}  # 0=closed, 1=open, 2=half-open
integration_circuit_failures{integration}

# Rate limiting
integration_rate_limit_hits{integration}
integration_queue_depth{integration}
```

### 9.2 Alerting Rules

```yaml
groups:
  - name: integration-alerts
    rules:
      - alert: IntegrationDown
        expr: integration_up == 0
        for: 5m
        labels:
          severity: critical
          
      - alert: IntegrationHighLatency
        expr: histogram_quantile(0.95, integration_latency_seconds) > 5
        for: 5m
        labels:
          severity: warning
          
      - alert: CircuitBreakerOpen
        expr: integration_circuit_state == 1
        for: 1m
        labels:
          severity: warning
```

## 10. Configuration

### 10.1 Environment Variables

```bash
# Space-Track
SPACETRACK_USERNAME=
SPACETRACK_PASSWORD=
SPACETRACK_BASE_URL=https://www.space-track.org

# Sentinel Hub
SENTINELHUB_CLIENT_ID=
SENTINELHUB_CLIENT_SECRET=
SENTINELHUB_BASE_URL=https://services.sentinel-hub.com

# AWS
AWS_REGION=us-east-2
AWS_GROUND_STATION_SATELLITE_ARN=

# External IdP
OIDC_ISSUER=
OIDC_CLIENT_ID=
OIDC_CLIENT_SECRET=

# Stripe
STRIPE_SECRET_KEY=
STRIPE_WEBHOOK_SECRET=

# Storage
S3_BUCKET_IMAGERY=
S3_BUCKET_EXPORTS=
S3_ENDPOINT=  # For MinIO
```

## 11. Related Documents

- [System Overview](./system-overview.md)
- [Security Architecture](./security-architecture.md)
- Module-specific integrations in each module's `integrations/` folder
