# Security Architecture

> P9E Space Platform - Security Design & Controls

## 1. Overview

The P9E Space Platform implements defense-in-depth security with multiple layers of controls protecting multi-tenant satellite operations data.

## 2. Security Principles

| Principle | Implementation |
|-----------|----------------|
| **Zero Trust** | Verify every request, assume breach |
| **Least Privilege** | Minimal permissions by default |
| **Defense in Depth** | Multiple security layers |
| **Secure by Default** | Security enabled out of box |
| **Audit Everything** | Complete audit trail |

## 3. Authentication

### 3.1 Authentication Flow

```
┌──────────┐     ┌──────────┐     ┌──────────┐     ┌──────────┐
│  Client  │     │   API    │     │ Identity │     │  User    │
│          │     │ Gateway  │     │ Service  │     │   DB     │
└────┬─────┘     └────┬─────┘     └────┬─────┘     └────┬─────┘
     │                │                │                │
     │ 1. Login       │                │                │
     │───────────────►│                │                │
     │                │ 2. Authenticate│                │
     │                │───────────────►│                │
     │                │                │ 3. Verify      │
     │                │                │───────────────►│
     │                │                │ 4. User        │
     │                │                │◄───────────────│
     │                │                │                │
     │                │                │ 5. Check MFA   │
     │                │                │──┐             │
     │                │                │◄─┘             │
     │                │ 6. MFA Challenge (if enabled)   │
     │◄───────────────│◄───────────────│                │
     │                │                │                │
     │ 7. MFA Code    │                │                │
     │───────────────►│───────────────►│                │
     │                │                │                │
     │                │ 8. TokenPair   │                │
     │◄───────────────│◄───────────────│                │
     │                │                │                │
```

### 3.2 Token Structure

```
Access Token (JWT, 15 min):
{
  "iss": "https://auth.p9e.space",
  "sub": "user_uuid",
  "aud": ["p9e-api"],
  "exp": 1735300800,
  "iat": 1735299900,
  "tenant_id": "tenant_uuid",
  "roles": ["operator", "analyst"],
  "permissions": ["pass.schedule", "telemetry.read"],
  "session_id": "session_uuid"
}

Refresh Token (Opaque, 7 days):
- Stored in Redis with session metadata
- Single use with rotation
- Bound to device fingerprint
```

### 3.3 MFA Support

| Method | Implementation | Recovery |
|--------|----------------|----------|
| **TOTP** | RFC 6238, 30-second window | Backup codes (10) |
| **WebAuthn** | FIDO2 hardware keys | Secondary method |
| **SMS** | AWS SNS (backup only) | Email verification |

### 3.4 OIDC Federation

```yaml
# Tenant IdP Configuration
tenant_id: "abc123"
idp_config:
  type: "oidc"
  issuer: "https://okta.example.com"
  client_id: "p9e-space-client"
  client_secret: "${VAULT:okta_secret}"
  scopes: ["openid", "profile", "email", "groups"]
  claims_mapping:
    email: "email"
    name: "name"
    groups: "groups"
    tenant_id: "custom:tenant_id"
```

## 4. Authorization

### 4.1 Three-Layer Model

```
┌─────────────────────────────────────────────────────────────────┐
│ LAYER 1: IAM (Identity & Access Management)                     │
│ ┌─────────────────────────────────────────────────────────────┐ │
│ │ • User exists and is active                                 │ │
│ │ • Session is valid                                          │ │
│ │ • Tenant membership verified                                │ │
│ │ • MFA completed (if required)                               │ │
│ └─────────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────────┤
│ LAYER 2: RBAC (Role-Based Access Control)                       │
│ ┌─────────────────────────────────────────────────────────────┐ │
│ │ • User has required role                                    │ │
│ │ • Role grants permission for action                         │ │
│ │ • Module-level access control                               │ │
│ └─────────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────────┤
│ LAYER 3: Policy Engine (Fine-Grained)                           │
│ ┌─────────────────────────────────────────────────────────────┐ │
│ │ • Resource ownership                                        │ │
│ │ • Time-based restrictions                                   │ │
│ │ • Classification levels                                     │ │
│ │ • Custom business rules                                     │ │
│ └─────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

### 4.2 Role Hierarchy

```
System Administrator
    └── Tenant Administrator
            ├── Mission Manager
            │       ├── Ground Station Operator
            │       ├── Flight Dynamics Engineer
            │       ├── EO Analyst
            │       └── Intelligence Analyst
            └── Auditor (read-only)
```

### 4.3 Permission Model

```
Permission Format: {module}.{resource}.{action}

Examples:
- platform.users.create
- platform.users.read
- groundstation.passes.schedule
- groundstation.commands.approve
- satellite.maneuvers.create
- eo.items.read
- eo.processing.execute
- geoint.reports.publish
```

### 4.4 Policy Engine (OPA/Cedar)

```cedar
// Allow operator to schedule pass for owned satellites
permit(
    principal in Role::"operator",
    action == Action::"pass.schedule",
    resource
) when {
    resource.tenant_id == principal.tenant_id &&
    resource.satellite_id in principal.assigned_satellites
};

// Require two-person auth for critical commands
permit(
    principal in Role::"operator",
    action == Action::"command.approve",
    resource
) when {
    resource.hazard_level >= HazardLevel::Critical &&
    resource.submitted_by != principal.user_id &&
    principal has Permission::"command.approve"
};
```

## 5. Data Protection

### 5.1 Encryption

| Scope | Algorithm | Key Management |
|-------|-----------|----------------|
| **In Transit** | TLS 1.3 | Auto-rotated certificates |
| **At Rest (DB)** | AES-256-GCM | Vault-managed DEK |
| **At Rest (S3)** | SSE-KMS | AWS KMS / Vault Transit |
| **Secrets** | AES-256-GCM | HashiCorp Vault |

### 5.2 Tenant Isolation

```sql
-- Row-Level Security (RLS) Policy
CREATE POLICY tenant_isolation ON satellites
    USING (tenant_id = current_setting('app.tenant_id')::uuid);

-- All queries automatically filtered
SET app.tenant_id = 'tenant-uuid';
SELECT * FROM satellites; -- Only returns tenant's satellites
```

### 5.3 Classification Levels

| Level | Description | Controls |
|-------|-------------|----------|
| **UNCLASSIFIED** | Public data | Standard access |
| **RESTRICTED** | Internal only | Tenant boundary |
| **CONFIDENTIAL** | Sensitive ops | Role + need-to-know |
| **SECRET** | Critical intelligence | Policy engine + audit |

## 6. Network Security

### 6.1 Network Segmentation

```
┌─────────────────────────────────────────────────────────────────┐
│ PUBLIC ZONE (DMZ)                                               │
│ ┌─────────────┐ ┌─────────────┐                                │
│ │   Ingress   │ │     WAF     │                                │
│ └──────┬──────┘ └──────┬──────┘                                │
└────────┼───────────────┼────────────────────────────────────────┘
         │               │
┌────────┼───────────────┼────────────────────────────────────────┐
│ APPLICATION ZONE       │                                        │
│ ┌──────┴──────┐ ┌──────┴──────┐ ┌─────────────┐               │
│ │ API Gateway │ │  Services   │ │   Workers   │               │
│ └─────────────┘ └─────────────┘ └─────────────┘               │
└─────────────────────────────────────────────────────────────────┘
         │
┌────────┼────────────────────────────────────────────────────────┐
│ DATA ZONE (Restricted)                                          │
│ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐               │
│ │  PostgreSQL │ │    Redis    │ │    Vault    │               │
│ └─────────────┘ └─────────────┘ └─────────────┘               │
└─────────────────────────────────────────────────────────────────┘
```

### 6.2 Network Policies

```yaml
# Allow only API Gateway to reach services
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: allow-gateway-only
spec:
  podSelector:
    matchLabels:
      tier: service
  ingress:
    - from:
        - podSelector:
            matchLabels:
              app: api-gateway
      ports:
        - port: 8080
```

## 7. Audit & Compliance

### 7.1 Audit Log Structure

```json
{
  "id": "audit-uuid",
  "timestamp": "2025-12-27T10:30:00Z",
  "tenant_id": "tenant-uuid",
  "user_id": "user-uuid",
  "session_id": "session-uuid",
  "action": "command.approve",
  "resource_type": "Command",
  "resource_id": "cmd-uuid",
  "outcome": "success",
  "ip_address": "203.0.113.45",
  "user_agent": "Mozilla/5.0...",
  "details": {
    "command_mnemonic": "SAFE_MODE",
    "satellite_id": "sat-uuid",
    "hazard_level": "CRITICAL"
  },
  "signature": "sha256:abc123..."  // Hash chain
}
```

### 7.2 Compliance Controls

| Framework | Controls | Status |
|-----------|----------|--------|
| **SOC 2 Type II** | Access control, encryption, audit | Ready |
| **ISO 27001** | ISMS policies, risk management | Aligned |
| **ITAR** | Export control, access restrictions | Aware |
| **GDPR** | Data privacy, right to erasure | Compliant |

### 7.3 Security Monitoring

| Category | Tool | Alerts |
|----------|------|--------|
| **Intrusion Detection** | Falco | Syscall anomalies |
| **Vulnerability Scanning** | Trivy | CVE detection |
| **Secret Scanning** | GitLeaks | Credential leaks |
| **SIEM Integration** | Splunk/Elastic | CEF events |

## 8. Secrets Management

### 8.1 Vault Integration

```
┌─────────────────────────────────────────────────────────────────┐
│                     HASHICORP VAULT                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐            │
│  │   KV v2     │  │   Transit   │  │  Database   │            │
│  │  (Secrets)  │  │ (Encryption)│  │ (Dynamic)   │            │
│  └─────────────┘  └─────────────┘  └─────────────┘            │
│                                                                 │
│  ┌─────────────┐  ┌─────────────┐                              │
│  │    PKI      │  │    OIDC     │                              │
│  │(Certificates)│ │   (Auth)    │                              │
│  └─────────────┘  └─────────────┘                              │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 8.2 Secret Types

| Type | Path | Rotation |
|------|------|----------|
| API Keys | `secret/data/{env}/api-keys/*` | 90 days |
| DB Credentials | `database/creds/*` | Dynamic (1 hour) |
| JWT Signing Key | `transit/keys/jwt-signing` | 30 days |
| TLS Certificates | `pki/issue/*` | 30 days |
| Encryption Keys | `transit/keys/*` | Annual |

## 9. Security Checklist

### 9.1 Authentication
- [ ] Password hashing with Argon2id
- [ ] MFA enforcement for privileged users
- [ ] Session timeout (15 min idle, 8 hour max)
- [ ] Brute force protection (5 attempts, 15 min lockout)
- [ ] OIDC federation with PKCE

### 9.2 Authorization
- [ ] Tenant isolation via RLS
- [ ] RBAC with role hierarchy
- [ ] Policy engine for fine-grained access
- [ ] Two-person authorization for critical ops

### 9.3 Data Protection
- [ ] TLS 1.3 everywhere
- [ ] AES-256 at rest
- [ ] Field-level encryption for PII
- [ ] Secure key management (Vault)

### 9.4 Operations
- [ ] Audit logging with hash chain
- [ ] SIEM integration
- [ ] Vulnerability scanning in CI/CD
- [ ] Incident response procedures

## 10. Related Documents

- [System Overview](./system-overview.md)
- [Data Architecture](./data-architecture.md)
- Module-specific security in each module's documentation
