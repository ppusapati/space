# System Overview

> P9E Space Technology Platform - Enterprise Architecture

## 1. Introduction

The P9E Space Platform is a cloud-native, multi-tenant satellite operations platform designed for commercial and government space operators. It provides comprehensive capabilities across the satellite lifecycle from mission planning through decommissioning.

## 2. Business Context

### 2.1 Target Users

| Actor | Description | Primary Modules |
|-------|-------------|-----------------|
| **System Administrator** | Platform configuration, tenant management | Platform |
| **Tenant Administrator** | Organization settings, user management | Platform |
| **Ground Station Operator** | Pass scheduling, TM/TC operations | Ground Station |
| **Flight Dynamics Engineer** | Orbit determination, maneuver planning | Satellite |
| **EO Analyst** | Imagery search, processing, ML inference | EO |
| **Intelligence Analyst** | AOI monitoring, pattern analysis, reporting | GEOINT |
| **Mission Manager** | Cross-functional oversight | All |

### 2.2 Key Capabilities

1. **Multi-Tenant Operations**: Complete tenant isolation with configurable quotas
2. **Ground Station Network**: Support for owned and partner ground stations
3. **Real-Time Telemetry**: Sub-second latency from antenna to dashboard
4. **Command & Control**: Two-person authorization for critical operations
5. **Earth Observation**: STAC-compliant catalog with processing pipelines
6. **Geospatial Intelligence**: Automated monitoring and change detection
7. **ML/AI Integration**: Model deployment and inference at scale

## 3. System Architecture

### 3.1 High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           PRESENTATION LAYER                                │
├─────────────────────────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐        │
│  │  Web App    │  │ Desktop App │  │ Mobile App  │  │  CLI Tool   │        │
│  │ (SvelteKit) │  │  (Tauri)    │  │  (Tauri)    │  │    (Go)     │        │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘        │
│         │                │                │                │               │
│         └────────────────┴────────────────┴────────────────┘               │
│                                   │                                        │
│                          ┌────────┴────────┐                               │
│                          │   API Gateway   │                               │
│                          │  (ConnectRPC)   │                               │
│                          └────────┬────────┘                               │
└──────────────────────────────────┼─────────────────────────────────────────┘
                                   │
┌──────────────────────────────────┼─────────────────────────────────────────┐
│                           SERVICE LAYER                                    │
├──────────────────────────────────┼─────────────────────────────────────────┤
│         ┌────────────────────────┴────────────────────────┐                │
│         │                                                 │                │
│  ┌──────┴──────┐  ┌─────────────┐  ┌─────────────┐  ┌────┴────────┐       │
│  │  Platform   │  │Ground Station│  │  Satellite  │  │     EO      │       │
│  │  Module     │  │   Module    │  │   Module    │  │   Module    │       │
│  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘       │
│                                                                            │
│  ┌─────────────┐  ┌─────────────┐                                         │
│  │   GEOINT    │  │   Common    │                                         │
│  │   Module    │  │  Services   │                                         │
│  └─────────────┘  └─────────────┘                                         │
└───────────────────────────────────────────────────────────────────────────┘
                                   │
┌──────────────────────────────────┼─────────────────────────────────────────┐
│                           DATA LAYER                                       │
├──────────────────────────────────┼─────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐       │
│  │ PostgreSQL  │  │ TimescaleDB │  │   Redis     │  │    NATS     │       │
│  │  + PostGIS  │  │ (Telemetry) │  │   Cache     │  │  JetStream  │       │
│  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘       │
│                                                                            │
│  ┌─────────────┐  ┌─────────────┐                                         │
│  │  S3/MinIO   │  │    Vault    │                                         │
│  │  (Objects)  │  │  (Secrets)  │                                         │
│  └─────────────┘  └─────────────┘                                         │
└───────────────────────────────────────────────────────────────────────────┘
```

### 3.2 Module Responsibilities

| Module | Bounded Context | Key Aggregates |
|--------|-----------------|----------------|
| **Platform** | Identity & Access | User, Tenant, Session, AuditLog |
| **Ground Station** | Satellite Operations | Pass, Command, TelemetryStream |
| **Satellite** | Spacecraft Management | Spacecraft, OrbitState, Conjunction |
| **EO** | Earth Observation | Collection, Item, ProcessingJob, Model |
| **GEOINT** | Intelligence Analysis | Workspace, AOI, Observation, Report |
| **Common** | Shared Utilities | Export, Dashboard, Schedule |

### 3.3 Communication Patterns

| Pattern | Usage | Technology |
|---------|-------|------------|
| **Synchronous** | API requests, queries | ConnectRPC (gRPC/HTTP) |
| **Async Events** | Domain events, notifications | NATS JetStream |
| **Streaming** | Telemetry, alerts | gRPC streams, WebSocket, SSE |
| **Batch** | Data export, bulk operations | Background jobs + S3 |

## 4. Deployment Architecture

### 4.1 Kubernetes Topology

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         KUBERNETES CLUSTER                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ INGRESS NAMESPACE                                                    │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐                  │   │
│  │  │   Traefik   │  │ Cert-Manager│  │  External   │                  │   │
│  │  │   Ingress   │  │    (TLS)    │  │     DNS     │                  │   │
│  │  └─────────────┘  └─────────────┘  └─────────────┘                  │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ APPLICATION NAMESPACE (p9e-space)                                    │   │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐  │   │
│  │  │ Platform │ │Ground Stn│ │ Satellite│ │    EO    │ │  GEOINT  │  │   │
│  │  │ Service  │ │ Service  │ │ Service  │ │ Service  │ │ Service  │  │   │
│  │  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘  │   │
│  │                                                                      │   │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐               │   │
│  │  │  Common  │ │  Worker  │ │ Scheduler│ │WebSocket │               │   │
│  │  │ Service  │ │  Pools   │ │  (Cron)  │ │ Gateway  │               │   │
│  │  └──────────┘ └──────────┘ └──────────┘ └──────────┘               │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ DATA NAMESPACE (p9e-data)                                            │   │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐  │   │
│  │  │PostgreSQL│ │Timescale │ │  Redis   │ │   NATS   │ │  MinIO   │  │   │
│  │  │ Primary  │ │   DB     │ │ Cluster  │ │ JetStream│ │ Cluster  │  │   │
│  │  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘  │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ OBSERVABILITY NAMESPACE (p9e-monitoring)                             │   │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐  │   │
│  │  │Prometheus│ │ Grafana  │ │   Loki   │ │  Tempo   │ │Alertmgr  │  │   │
│  │  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘  │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 4.2 Environment Tiers

| Environment | Purpose | Cluster Size | Data |
|-------------|---------|--------------|------|
| **Development** | Local development | Single node (Kind/K3s) | Synthetic |
| **Staging** | Integration testing | 3 nodes | Anonymized production |
| **Production** | Live operations | 5+ nodes (HA) | Real |
| **DR** | Disaster recovery | 3 nodes (standby) | Replicated |

## 5. Key Design Decisions

### 5.1 Architecture Decision Records

| ADR | Decision | Rationale |
|-----|----------|-----------|
| [ADR-001](./adr/ADR-001-sveltekit-tauri.md) | SvelteKit + Tauri | Unified codebase for web/desktop |
| [ADR-002](./adr/ADR-002-connectrpc.md) | ConnectRPC over pure gRPC | Browser compatibility + type safety |
| [ADR-003](./adr/ADR-003-clean-architecture.md) | Clean Architecture | Testability, maintainability |
| [ADR-004](./adr/ADR-004-timescaledb.md) | TimescaleDB for telemetry | Time-series optimization |
| [ADR-005](./adr/ADR-005-nats-jetstream.md) | NATS JetStream | Lightweight, persistent messaging |
| [ADR-006](./adr/ADR-006-multi-tenancy.md) | Row-level multi-tenancy | Cost efficiency, simpler ops |
| [ADR-007](./adr/ADR-007-hybrid-auth.md) | Hybrid RBAC + ABAC + Policy | Flexible authorization |

### 5.2 Non-Functional Requirements

| Requirement | Target | Approach |
|-------------|--------|----------|
| **Availability** | 99.9% (8.76h/year downtime) | HA deployment, health checks |
| **Latency (API)** | p95 < 200ms | Caching, connection pooling |
| **Latency (Telemetry)** | < 1 second end-to-end | NATS streaming |
| **Throughput** | 10,000 TM frames/second | Horizontal scaling |
| **Storage** | 10+ PB imagery | S3 tiering |
| **Recovery (RPO)** | 1 hour | Streaming replication |
| **Recovery (RTO)** | 4 hours | Automated failover |

## 6. Integration Points

### 6.1 External Systems

| System | Purpose | Protocol |
|--------|---------|----------|
| Space-Track.org | TLE, CDM data | REST API |
| Sentinel Hub | Satellite imagery | REST API (OAuth) |
| AWS Ground Station | Antenna access | AWS SDK |
| External IdP | SSO federation | OIDC/SAML |
| Stripe | Billing | REST API + Webhooks |
| AWS SES/SNS | Notifications | AWS SDK |

### 6.2 Hardware Interfaces

| Hardware | Purpose | Protocol |
|----------|---------|----------|
| SDR (USRP, RTL-SDR) | RF reception | ZMQ, GNU Radio |
| Antenna Rotator | Tracking | Hamlib/Serial |
| TNC | Packet radio | KISS protocol |

## 7. Security Overview

- **Authentication**: JWT + MFA + OIDC federation
- **Authorization**: Hybrid IAM + RBAC + Policy Engine
- **Data Protection**: TLS 1.3, AES-256 at rest, tenant isolation
- **Compliance**: SOC 2 Type II ready, ITAR-aware design

See [Security Architecture](./security-architecture.md) for details.

## 8. Related Documents

- [Data Architecture](./data-architecture.md)
- [Security Architecture](./security-architecture.md)
- [Integration Patterns](./integration-patterns.md)
- [Observability](./observability.md)
