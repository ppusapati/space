# Observability

> P9E Space Platform - Logging, Metrics, Tracing & Alerting

## 1. Overview

The P9E Space Platform implements comprehensive observability using the OpenTelemetry standard, providing unified logging, metrics, and distributed tracing across all services.

## 2. Observability Stack

| Component | Tool | Purpose |
|-----------|------|---------|
| **Metrics** | Prometheus + Grafana | Time-series metrics, dashboards |
| **Logging** | Loki + Grafana | Log aggregation, search |
| **Tracing** | Tempo + Grafana | Distributed tracing |
| **Alerting** | Alertmanager | Alert routing, notification |
| **Profiling** | Parca | Continuous profiling |

## 3. Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         APPLICATION SERVICES                                │
├─────────────────────────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐        │
│  │  Platform   │  │Ground Station│  │     EO      │  │   GEOINT    │        │
│  │  Service    │  │   Service   │  │   Service   │  │   Service   │        │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘        │
│         │                │                │                │               │
│         └────────────────┴────────────────┴────────────────┘               │
│                                   │                                        │
│                    ┌──────────────┴──────────────┐                         │
│                    │   OpenTelemetry Collector   │                         │
│                    └──────────────┬──────────────┘                         │
└───────────────────────────────────┼─────────────────────────────────────────┘
                                    │
         ┌──────────────────────────┼──────────────────────────┐
         │                          │                          │
         ▼                          ▼                          ▼
┌─────────────────┐      ┌─────────────────┐      ┌─────────────────┐
│   Prometheus    │      │      Loki       │      │     Tempo       │
│   (Metrics)     │      │    (Logging)    │      │   (Tracing)     │
└────────┬────────┘      └────────┬────────┘      └────────┬────────┘
         │                        │                        │
         └────────────────────────┼────────────────────────┘
                                  │
                         ┌────────┴────────┐
                         │     Grafana     │
                         │  (Dashboards)   │
                         └────────┬────────┘
                                  │
                         ┌────────┴────────┐
                         │  Alertmanager   │
                         └─────────────────┘
```

## 4. Metrics

### 4.1 Standard Metrics (RED Method)

```prometheus
# Rate - Requests per second
http_requests_total{service, method, path, status}

# Errors - Error rate
http_requests_total{status=~"5.."}

# Duration - Latency
http_request_duration_seconds{service, method, path}
```

### 4.2 Service-Specific Metrics

```prometheus
# Platform
p9e_active_sessions{tenant_id}
p9e_auth_attempts_total{outcome, method}
p9e_api_keys_active{tenant_id}

# Ground Station
p9e_passes_scheduled_total{satellite_id, ground_station_id}
p9e_passes_executed_total{satellite_id, status}
p9e_telemetry_frames_total{satellite_id}
p9e_telemetry_latency_seconds{satellite_id}
p9e_commands_total{satellite_id, status}
p9e_alerts_active{satellite_id, severity}

# EO
p9e_catalog_items_total{collection_id}
p9e_processing_jobs_total{workflow_id, status}
p9e_processing_duration_seconds{workflow_id}
p9e_ml_inference_total{model_id}
p9e_ml_inference_latency_seconds{model_id}

# GEOINT
p9e_aois_total{workspace_id, status}
p9e_observations_total{workspace_id, type}
p9e_reports_total{workspace_id, status}
```

### 4.3 Infrastructure Metrics

```prometheus
# Database
pg_connections_active{database}
pg_transactions_total{database}
pg_replication_lag_seconds

# Redis
redis_connected_clients
redis_memory_used_bytes
redis_commands_total

# NATS
nats_msgs_total{subject}
nats_bytes_total{subject}
nats_pending_count{stream}

# S3/MinIO
s3_requests_total{bucket, operation}
s3_bytes_total{bucket, direction}
```

## 5. Logging

### 5.1 Log Format (Structured JSON)

```json
{
  "timestamp": "2025-12-27T10:30:00.123Z",
  "level": "info",
  "service": "platform",
  "trace_id": "abc123def456",
  "span_id": "789xyz",
  "tenant_id": "tenant-uuid",
  "user_id": "user-uuid",
  "request_id": "req-uuid",
  "message": "User logged in successfully",
  "attributes": {
    "email": "user@example.com",
    "mfa_used": true,
    "ip_address": "203.0.113.45"
  }
}
```

### 5.2 Log Levels

| Level | Usage | Examples |
|-------|-------|----------|
| **DEBUG** | Development only | Variable values, flow |
| **INFO** | Normal operations | User actions, API calls |
| **WARN** | Recoverable issues | Rate limits, retries |
| **ERROR** | Failures | API errors, exceptions |
| **FATAL** | Service termination | Startup failures |

### 5.3 Logging Guidelines

```go
// Good - Structured with context
log.Info("Pass scheduled",
    "satellite_id", pass.SatelliteID,
    "ground_station_id", pass.GroundStationID,
    "aos", pass.PredictedAOS,
    "los", pass.PredictedLOS,
)

// Bad - Unstructured string interpolation
log.Info(fmt.Sprintf("Pass scheduled for satellite %s", satelliteID))
```

## 6. Distributed Tracing

### 6.1 Trace Propagation

```go
// Incoming request extracts trace context
func (h *Handler) HandleRequest(ctx context.Context, req *Request) (*Response, error) {
    // Start span
    ctx, span := tracer.Start(ctx, "HandleRequest",
        trace.WithAttributes(
            attribute.String("tenant_id", req.TenantID),
            attribute.String("user_id", req.UserID),
        ),
    )
    defer span.End()
    
    // Call downstream services - context propagates trace
    result, err := h.service.Process(ctx, req)
    if err != nil {
        span.RecordError(err)
        span.SetStatus(codes.Error, err.Error())
        return nil, err
    }
    
    return result, nil
}
```

### 6.2 Span Naming Convention

```
{service}.{component}.{operation}

Examples:
- platform.identity.login
- groundstation.pass.schedule
- groundstation.telemetry.stream
- eo.catalog.search
- geoint.analysis.detect_changes
```

### 6.3 Important Spans

| Service | Key Spans |
|---------|-----------|
| Platform | `identity.login`, `identity.refresh_token`, `authz.check` |
| Ground Station | `pass.schedule`, `pass.execute`, `telemetry.ingest`, `command.send` |
| EO | `catalog.search`, `processing.execute`, `ml.inference` |
| GEOINT | `aoi.monitor`, `analysis.detect`, `report.generate` |

## 7. Alerting

### 7.1 Alert Severity Levels

| Severity | Response | Examples |
|----------|----------|----------|
| **Critical** | Page immediately | Service down, data loss |
| **Warning** | Review within 1h | High latency, errors |
| **Info** | Daily review | Capacity planning |

### 7.2 Critical Alerts

```yaml
groups:
  - name: critical-alerts
    rules:
      - alert: ServiceDown
        expr: up == 0
        for: 1m
        labels:
          severity: critical
        annotations:
          summary: "{{ $labels.service }} is down"
          
      - alert: HighErrorRate
        expr: |
          sum(rate(http_requests_total{status=~"5.."}[5m])) by (service)
          /
          sum(rate(http_requests_total[5m])) by (service)
          > 0.05
        for: 5m
        labels:
          severity: critical
        annotations:
          summary: "High error rate in {{ $labels.service }}"
          
      - alert: DatabaseDown
        expr: pg_up == 0
        for: 1m
        labels:
          severity: critical
        annotations:
          summary: "PostgreSQL is down"
```

### 7.3 Warning Alerts

```yaml
groups:
  - name: warning-alerts
    rules:
      - alert: HighLatency
        expr: |
          histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m]))
          > 1
        for: 10m
        labels:
          severity: warning
        annotations:
          summary: "High p95 latency in {{ $labels.service }}"
          
      - alert: TelemetryLag
        expr: p9e_telemetry_latency_seconds > 5
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "Telemetry lag for {{ $labels.satellite_id }}"
          
      - alert: DiskSpaceWarning
        expr: |
          (node_filesystem_avail_bytes / node_filesystem_size_bytes) < 0.2
        for: 15m
        labels:
          severity: warning
        annotations:
          summary: "Disk space below 20%"
```

### 7.4 Alert Routing

```yaml
route:
  receiver: default
  routes:
    - match:
        severity: critical
      receiver: pagerduty
      continue: true
      
    - match:
        severity: critical
      receiver: slack-critical
      
    - match:
        severity: warning
      receiver: slack-warning
      
receivers:
  - name: pagerduty
    pagerduty_configs:
      - service_key: "${PAGERDUTY_KEY}"
        
  - name: slack-critical
    slack_configs:
      - channel: "#alerts-critical"
        
  - name: slack-warning
    slack_configs:
      - channel: "#alerts-warning"
```

## 8. Dashboards

### 8.1 Dashboard Hierarchy

```
├── Executive Overview
│   ├── System Health Summary
│   ├── Key Business Metrics
│   └── SLA Compliance
│
├── Service Dashboards
│   ├── Platform Service
│   ├── Ground Station Service
│   ├── Satellite Service
│   ├── EO Service
│   └── GEOINT Service
│
├── Operations Dashboards
│   ├── Pass Operations
│   ├── Command & Control
│   ├── Telemetry Health
│   └── Processing Pipeline
│
└── Infrastructure Dashboards
    ├── Kubernetes Cluster
    ├── Database Performance
    ├── Cache Performance
    └── Storage Usage
```

### 8.2 Key Dashboard Panels

| Dashboard | Key Panels |
|-----------|------------|
| **Executive** | Uptime %, Error rate, Active users, Processing jobs |
| **Ground Station** | Pass timeline, TM rate, Command success rate, Alerts |
| **EO** | Items ingested, Processing queue, ML inference rate |
| **GEOINT** | AOI coverage, Observations/day, Reports generated |

## 9. SLIs/SLOs

### 9.1 Service Level Indicators

| SLI | Measurement |
|-----|-------------|
| **Availability** | `up{job="*"}` |
| **Latency** | `histogram_quantile(0.95, http_request_duration_seconds)` |
| **Error Rate** | `http_requests_total{status=~"5.."} / http_requests_total` |
| **Throughput** | `rate(http_requests_total[5m])` |

### 9.2 Service Level Objectives

| Service | Availability | Latency (p95) | Error Rate |
|---------|--------------|---------------|------------|
| API Gateway | 99.9% | < 100ms | < 0.1% |
| Platform | 99.9% | < 200ms | < 0.1% |
| Ground Station | 99.5% | < 500ms | < 0.5% |
| EO Processing | 99.0% | < 30s | < 1.0% |
| Telemetry Streaming | 99.9% | < 1s | < 0.1% |

## 10. Implementation

### 10.1 OpenTelemetry Setup

```go
func initTelemetry() (*sdktrace.TracerProvider, error) {
    // OTLP exporter
    exporter, err := otlptracegrpc.New(ctx,
        otlptracegrpc.WithEndpoint("otel-collector:4317"),
        otlptracegrpc.WithInsecure(),
    )
    
    // Trace provider
    tp := sdktrace.NewTracerProvider(
        sdktrace.WithBatcher(exporter),
        sdktrace.WithResource(resource.NewWithAttributes(
            semconv.SchemaURL,
            semconv.ServiceName("platform"),
            semconv.ServiceVersion("1.0.0"),
        )),
    )
    
    otel.SetTracerProvider(tp)
    otel.SetTextMapPropagator(propagation.TraceContext{})
    
    return tp, nil
}
```

### 10.2 Prometheus Metrics

```go
var (
    requestsTotal = prometheus.NewCounterVec(
        prometheus.CounterOpts{
            Name: "http_requests_total",
            Help: "Total HTTP requests",
        },
        []string{"service", "method", "path", "status"},
    )
    
    requestDuration = prometheus.NewHistogramVec(
        prometheus.HistogramOpts{
            Name:    "http_request_duration_seconds",
            Help:    "HTTP request duration",
            Buckets: prometheus.DefBuckets,
        },
        []string{"service", "method", "path"},
    )
)

func init() {
    prometheus.MustRegister(requestsTotal, requestDuration)
}
```

## 11. Related Documents

- [System Overview](./system-overview.md)
- [Security Architecture](./security-architecture.md)
- [Operations - Monitoring](../07-operations/monitoring.md)
