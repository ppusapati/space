# Data Architecture

> P9E Space Platform - Database Design & Data Management

## 1. Overview

The P9E Space Platform uses a polyglot persistence strategy optimized for different data access patterns across satellite operations, Earth observation, and geospatial intelligence.

## 2. Database Technologies

| Database | Purpose | Data Types |
|----------|---------|------------|
| **PostgreSQL 16** | Primary transactional data | Users, tenants, satellites, passes, configs |
| **TimescaleDB** | Time-series telemetry | Telemetry frames, metrics, events |
| **PostGIS** | Geospatial data | AOIs, imagery footprints, observations |
| **Redis 7** | Caching & sessions | Sessions, rate limits, hot data |
| **NATS JetStream** | Event streaming | Domain events, notifications |
| **S3/MinIO** | Object storage | Imagery, exports, ML artifacts |

## 3. Schema Overview

### 3.1 Module Distribution

```
┌─────────────────────────────────────────────────────────────────┐
│                    PostgreSQL Database                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐ │
│  │    PLATFORM     │  │  GROUNDSTATION  │  │    SATELLITE    │ │
│  │    SCHEMA       │  │     SCHEMA      │  │     SCHEMA      │ │
│  │                 │  │                 │  │                 │ │
│  │  • tenants      │  │  • satellites   │  │  • spacecraft   │ │
│  │  • users        │  │  • ground_stns  │  │  • subsystems   │ │
│  │  • roles        │  │  • passes       │  │  • orbit_states │ │
│  │  • sessions     │  │  • commands     │  │  • maneuvers    │ │
│  │  • audit_logs   │  │  • anomalies    │  │  • conjunctions │ │
│  │  • api_keys     │  │  • alerts       │  │                 │ │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘ │
│                                                                 │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐ │
│  │       EO        │  │     GEOINT      │  │     COMMON      │ │
│  │     SCHEMA      │  │     SCHEMA      │  │     SCHEMA      │ │
│  │                 │  │                 │  │                 │ │
│  │  • collections  │  │  • workspaces   │  │  • exports      │ │
│  │  • items        │  │  • aois         │  │  • dashboards   │ │
│  │  • assets       │  │  • observations │  │  • schedules    │ │
│  │  • jobs         │  │  • reports      │  │  • webhooks     │ │
│  │  • models       │  │  • templates    │  │  • settings     │ │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘ │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                  TimescaleDB Hypertables                        │
├─────────────────────────────────────────────────────────────────┤
│  • telemetry_raw (1 min chunks)                                │
│  • telemetry_1min (continuous aggregate)                       │
│  • telemetry_1hour (continuous aggregate)                      │
│  • events (system events)                                      │
│  • metrics (application metrics)                               │
└─────────────────────────────────────────────────────────────────┘
```

### 3.2 Table Count by Module

| Module | Tables | Key Tables |
|--------|--------|------------|
| Platform | 12 | tenants, users, roles, user_roles, sessions, audit_logs |
| Ground Station | 15 | satellites, ground_stations, passes, pass_executions, commands |
| Satellite | 8 | spacecraft, subsystems, orbit_states, maneuvers, conjunctions |
| EO | 10 | collections, items, assets, processing_jobs, models |
| GEOINT | 10 | workspaces, aois, observations, reports, workspace_members |
| Common | 7 | exports, dashboards, schedules, webhooks, settings |
| **Total** | **62** | |

## 4. Platform Schema

### 4.1 Core Tables

```sql
-- Tenants (Organizations)
CREATE TABLE platform.tenants (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name            VARCHAR(255) NOT NULL,
    slug            VARCHAR(100) NOT NULL UNIQUE,
    status          tenant_status NOT NULL DEFAULT 'pending',
    tier            subscription_tier NOT NULL DEFAULT 'free',
    settings        JSONB NOT NULL DEFAULT '{}',
    quotas          JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    CONSTRAINT valid_slug CHECK (slug ~ '^[a-z0-9-]+$')
);

-- Users
CREATE TABLE platform.users (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES platform.tenants(id),
    email           VARCHAR(255) NOT NULL,
    password_hash   VARCHAR(255),  -- NULL for SSO users
    first_name      VARCHAR(100),
    last_name       VARCHAR(100),
    status          user_status NOT NULL DEFAULT 'active',
    mfa_enabled     BOOLEAN NOT NULL DEFAULT FALSE,
    mfa_secret      VARCHAR(255),  -- Encrypted
    idp_subject     VARCHAR(255),  -- External IdP subject
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    CONSTRAINT unique_email_per_tenant UNIQUE (tenant_id, email)
);

-- Roles
CREATE TABLE platform.roles (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID REFERENCES platform.tenants(id),  -- NULL = system role
    name            VARCHAR(100) NOT NULL,
    description     TEXT,
    permissions     TEXT[] NOT NULL DEFAULT '{}',
    is_system       BOOLEAN NOT NULL DEFAULT FALSE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- User-Role Assignment
CREATE TABLE platform.user_roles (
    user_id         UUID NOT NULL REFERENCES platform.users(id) ON DELETE CASCADE,
    role_id         UUID NOT NULL REFERENCES platform.roles(id) ON DELETE CASCADE,
    assigned_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    assigned_by     UUID REFERENCES platform.users(id),
    
    PRIMARY KEY (user_id, role_id)
);

-- Sessions
CREATE TABLE platform.sessions (
    id              VARCHAR(64) PRIMARY KEY,
    user_id         UUID NOT NULL REFERENCES platform.users(id) ON DELETE CASCADE,
    tenant_id       UUID NOT NULL REFERENCES platform.tenants(id),
    refresh_token   VARCHAR(64) NOT NULL UNIQUE,
    ip_address      INET,
    user_agent      TEXT,
    device_id       VARCHAR(64),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at      TIMESTAMPTZ NOT NULL,
    last_active_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Audit Logs (Append-Only)
CREATE TABLE platform.audit_logs (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL,
    user_id         UUID,
    session_id      VARCHAR(64),
    action          VARCHAR(100) NOT NULL,
    resource_type   VARCHAR(100),
    resource_id     UUID,
    outcome         audit_outcome NOT NULL,
    details         JSONB,
    ip_address      INET,
    user_agent      TEXT,
    timestamp       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    signature       VARCHAR(64) NOT NULL  -- Hash chain
);

CREATE INDEX idx_audit_logs_tenant_time ON platform.audit_logs(tenant_id, timestamp DESC);
CREATE INDEX idx_audit_logs_user ON platform.audit_logs(user_id, timestamp DESC);
CREATE INDEX idx_audit_logs_resource ON platform.audit_logs(resource_type, resource_id);
```

### 4.2 Row-Level Security

```sql
-- Enable RLS on all tenant-scoped tables
ALTER TABLE platform.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE platform.audit_logs ENABLE ROW LEVEL SECURITY;

-- Tenant isolation policy
CREATE POLICY tenant_isolation ON platform.users
    USING (tenant_id = current_setting('app.tenant_id')::uuid);

CREATE POLICY tenant_isolation ON platform.audit_logs
    USING (tenant_id = current_setting('app.tenant_id')::uuid);

-- Application sets tenant context on each request
SET app.tenant_id = 'tenant-uuid';
```

## 5. Ground Station Schema

### 5.1 Core Tables

```sql
-- Satellites
CREATE TABLE groundstation.satellites (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES platform.tenants(id),
    norad_id        INTEGER NOT NULL,
    cospar_id       VARCHAR(20),
    name            VARCHAR(255) NOT NULL,
    mission_type    mission_type NOT NULL,
    status          satellite_status NOT NULL DEFAULT 'operational',
    spacecraft_id   UUID REFERENCES satellite.spacecraft(id),
    uplink_freq_mhz DECIMAL(10,4),
    downlink_freq_mhz DECIMAL(10,4),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    CONSTRAINT unique_norad_per_tenant UNIQUE (tenant_id, norad_id)
);

-- TLE History
CREATE TABLE groundstation.tle_history (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    satellite_id    UUID NOT NULL REFERENCES groundstation.satellites(id),
    line1           VARCHAR(69) NOT NULL,
    line2           VARCHAR(69) NOT NULL,
    epoch           TIMESTAMPTZ NOT NULL,
    source          VARCHAR(50) NOT NULL DEFAULT 'space-track',
    fetched_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    CONSTRAINT unique_tle_epoch UNIQUE (satellite_id, epoch)
);

-- Ground Stations
CREATE TABLE groundstation.ground_stations (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES platform.tenants(id),
    name            VARCHAR(255) NOT NULL,
    latitude        DECIMAL(9,6) NOT NULL,
    longitude       DECIMAL(9,6) NOT NULL,
    altitude_m      DECIMAL(10,2) NOT NULL DEFAULT 0,
    min_elevation   DECIMAL(5,2) NOT NULL DEFAULT 5.0,
    capabilities    TEXT[] NOT NULL DEFAULT '{}',
    status          gs_status NOT NULL DEFAULT 'operational',
    config          JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    CONSTRAINT valid_lat CHECK (latitude BETWEEN -90 AND 90),
    CONSTRAINT valid_lon CHECK (longitude BETWEEN -180 AND 180)
);

-- Pass Schedules
CREATE TABLE groundstation.pass_schedules (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES platform.tenants(id),
    satellite_id    UUID NOT NULL REFERENCES groundstation.satellites(id),
    ground_station_id UUID NOT NULL REFERENCES groundstation.ground_stations(id),
    predicted_aos   TIMESTAMPTZ NOT NULL,
    predicted_los   TIMESTAMPTZ NOT NULL,
    predicted_tca   TIMESTAMPTZ NOT NULL,
    max_elevation   DECIMAL(5,2) NOT NULL,
    aos_azimuth     DECIMAL(5,2),
    los_azimuth     DECIMAL(5,2),
    status          pass_status NOT NULL DEFAULT 'scheduled',
    priority        INTEGER NOT NULL DEFAULT 5,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by      UUID REFERENCES platform.users(id)
);

CREATE INDEX idx_passes_time ON groundstation.pass_schedules(predicted_aos, predicted_los);
CREATE INDEX idx_passes_satellite ON groundstation.pass_schedules(satellite_id, predicted_aos);

-- Pass Executions
CREATE TABLE groundstation.pass_executions (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    schedule_id     UUID NOT NULL REFERENCES groundstation.pass_schedules(id),
    actual_aos      TIMESTAMPTZ,
    actual_los      TIMESTAMPTZ,
    status          execution_status NOT NULL DEFAULT 'pending',
    telemetry_frames INTEGER NOT NULL DEFAULT 0,
    commands_sent   INTEGER NOT NULL DEFAULT 0,
    commands_acked  INTEGER NOT NULL DEFAULT 0,
    max_signal_strength DECIMAL(5,2),
    notes           TEXT,
    completed_at    TIMESTAMPTZ
);

-- Commands
CREATE TABLE groundstation.commands (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES platform.tenants(id),
    satellite_id    UUID NOT NULL REFERENCES groundstation.satellites(id),
    command_def_id  UUID NOT NULL REFERENCES groundstation.command_definitions(id),
    mnemonic        VARCHAR(50) NOT NULL,
    parameters      JSONB NOT NULL DEFAULT '{}',
    hazard_level    hazard_level NOT NULL,
    status          command_status NOT NULL DEFAULT 'pending',
    justification   TEXT,
    submitted_by    UUID NOT NULL REFERENCES platform.users(id),
    submitted_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    approved_by     UUID REFERENCES platform.users(id),
    approved_at     TIMESTAMPTZ,
    sent_at         TIMESTAMPTZ,
    acked_at        TIMESTAMPTZ,
    pass_id         UUID REFERENCES groundstation.pass_schedules(id),
    response        JSONB
);

CREATE INDEX idx_commands_satellite ON groundstation.commands(satellite_id, submitted_at DESC);
CREATE INDEX idx_commands_status ON groundstation.commands(status) WHERE status IN ('pending', 'awaiting_approval');
```

## 6. Telemetry Schema (TimescaleDB)

### 6.1 Hypertable Definition

```sql
-- Raw telemetry (1 minute chunks, 7 day retention before rollup)
CREATE TABLE groundstation.telemetry_raw (
    time            TIMESTAMPTZ NOT NULL,
    satellite_id    UUID NOT NULL,
    parameter_id    VARCHAR(50) NOT NULL,
    value           DOUBLE PRECISION NOT NULL,
    raw_value       BIGINT,
    quality         telemetry_quality NOT NULL DEFAULT 'good',
    
    PRIMARY KEY (satellite_id, parameter_id, time)
);

SELECT create_hypertable('groundstation.telemetry_raw', 'time',
    chunk_time_interval => INTERVAL '1 minute',
    partitioning_column => 'satellite_id',
    number_partitions => 4
);

-- Enable compression after 1 hour
ALTER TABLE groundstation.telemetry_raw SET (
    timescaledb.compress,
    timescaledb.compress_segmentby = 'satellite_id,parameter_id',
    timescaledb.compress_orderby = 'time DESC'
);

SELECT add_compression_policy('groundstation.telemetry_raw', INTERVAL '1 hour');

-- 1-minute continuous aggregate
CREATE MATERIALIZED VIEW groundstation.telemetry_1min
WITH (timescaledb.continuous) AS
SELECT
    time_bucket('1 minute', time) AS bucket,
    satellite_id,
    parameter_id,
    AVG(value) AS avg_value,
    MIN(value) AS min_value,
    MAX(value) AS max_value,
    COUNT(*) AS sample_count
FROM groundstation.telemetry_raw
GROUP BY bucket, satellite_id, parameter_id;

-- 1-hour continuous aggregate
CREATE MATERIALIZED VIEW groundstation.telemetry_1hour
WITH (timescaledb.continuous) AS
SELECT
    time_bucket('1 hour', bucket) AS bucket,
    satellite_id,
    parameter_id,
    AVG(avg_value) AS avg_value,
    MIN(min_value) AS min_value,
    MAX(max_value) AS max_value,
    SUM(sample_count) AS sample_count
FROM groundstation.telemetry_1min
GROUP BY time_bucket('1 hour', bucket), satellite_id, parameter_id;

-- Retention policies
SELECT add_retention_policy('groundstation.telemetry_raw', INTERVAL '7 days');
SELECT add_retention_policy('groundstation.telemetry_1min', INTERVAL '90 days');
SELECT add_retention_policy('groundstation.telemetry_1hour', INTERVAL '5 years');
```

## 7. EO Schema (PostGIS)

### 7.1 STAC Tables

```sql
-- Collections (STAC Collection)
CREATE TABLE eo.collections (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES platform.tenants(id),
    stac_id         VARCHAR(255) NOT NULL,
    title           VARCHAR(255) NOT NULL,
    description     TEXT,
    license         VARCHAR(100),
    extent_spatial  GEOMETRY(POLYGON, 4326),
    extent_temporal TSTZRANGE,
    providers       JSONB,
    summaries       JSONB,
    item_count      INTEGER NOT NULL DEFAULT 0,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    CONSTRAINT unique_stac_id UNIQUE (tenant_id, stac_id)
);

-- Items (STAC Item)
CREATE TABLE eo.items (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES platform.tenants(id),
    collection_id   UUID NOT NULL REFERENCES eo.collections(id),
    stac_id         VARCHAR(255) NOT NULL,
    geometry        GEOMETRY(GEOMETRY, 4326) NOT NULL,
    bbox            BOX2D NOT NULL,
    datetime        TIMESTAMPTZ NOT NULL,
    start_datetime  TIMESTAMPTZ,
    end_datetime    TIMESTAMPTZ,
    properties      JSONB NOT NULL DEFAULT '{}',
    processing_level processing_level NOT NULL,
    cloud_cover     DECIMAL(5,2),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    CONSTRAINT unique_item_stac_id UNIQUE (collection_id, stac_id)
);

-- Spatial index
CREATE INDEX idx_items_geometry ON eo.items USING GIST (geometry);
CREATE INDEX idx_items_bbox ON eo.items USING GIST (bbox);
CREATE INDEX idx_items_datetime ON eo.items (datetime DESC);
CREATE INDEX idx_items_cloud ON eo.items (cloud_cover) WHERE cloud_cover IS NOT NULL;

-- Assets
CREATE TABLE eo.assets (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    item_id         UUID NOT NULL REFERENCES eo.items(id) ON DELETE CASCADE,
    key             VARCHAR(100) NOT NULL,
    href            TEXT NOT NULL,
    type            VARCHAR(100),
    title           VARCHAR(255),
    roles           TEXT[] NOT NULL DEFAULT '{}',
    file_size       BIGINT,
    checksum        VARCHAR(64),
    
    CONSTRAINT unique_asset_key UNIQUE (item_id, key)
);
```

## 8. GEOINT Schema (PostGIS)

### 8.1 Core Tables

```sql
-- Workspaces
CREATE TABLE geoint.workspaces (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES platform.tenants(id),
    name            VARCHAR(255) NOT NULL,
    description     TEXT,
    status          workspace_status NOT NULL DEFAULT 'active',
    layers          JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by      UUID NOT NULL REFERENCES platform.users(id)
);

-- AOIs (Areas of Interest)
CREATE TABLE geoint.aois (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id    UUID NOT NULL REFERENCES geoint.workspaces(id),
    tenant_id       UUID NOT NULL REFERENCES platform.tenants(id),
    name            VARCHAR(255) NOT NULL,
    description     TEXT,
    geometry        GEOMETRY(GEOMETRY, 4326) NOT NULL,
    bbox            BOX2D GENERATED ALWAYS AS (Box2D(geometry)) STORED,
    status          aoi_status NOT NULL DEFAULT 'active',
    priority        priority_level NOT NULL DEFAULT 'medium',
    classification  classification_level NOT NULL DEFAULT 'unclassified',
    monitoring_enabled BOOLEAN NOT NULL DEFAULT FALSE,
    monitoring_config JSONB,
    tags            TEXT[] NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by      UUID NOT NULL REFERENCES platform.users(id)
);

CREATE INDEX idx_aois_geometry ON geoint.aois USING GIST (geometry);
CREATE INDEX idx_aois_bbox ON geoint.aois USING GIST (bbox);

-- Observations
CREATE TABLE geoint.observations (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    aoi_id          UUID NOT NULL REFERENCES geoint.aois(id),
    tenant_id       UUID NOT NULL REFERENCES platform.tenants(id),
    item_id         UUID REFERENCES eo.items(id),
    type            observation_type NOT NULL,
    title           VARCHAR(255) NOT NULL,
    description     TEXT,
    location        GEOMETRY(POINT, 4326) NOT NULL,
    observed_at     TIMESTAMPTZ NOT NULL,
    confidence      DECIMAL(5,4),
    source          observation_source NOT NULL,
    attributes      JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by      UUID NOT NULL REFERENCES platform.users(id)
);

CREATE INDEX idx_observations_location ON geoint.observations USING GIST (location);
CREATE INDEX idx_observations_aoi ON geoint.observations(aoi_id, observed_at DESC);

-- Reports
CREATE TABLE geoint.reports (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id    UUID NOT NULL REFERENCES geoint.workspaces(id),
    tenant_id       UUID NOT NULL REFERENCES platform.tenants(id),
    type            report_type NOT NULL,
    title           VARCHAR(255) NOT NULL,
    summary         TEXT,
    body            TEXT,
    aoi_ids         UUID[] NOT NULL DEFAULT '{}',
    observation_ids UUID[] NOT NULL DEFAULT '{}',
    classification  classification_level NOT NULL DEFAULT 'unclassified',
    status          report_status NOT NULL DEFAULT 'draft',
    pdf_url         TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by      UUID NOT NULL REFERENCES platform.users(id),
    published_at    TIMESTAMPTZ
);
```

## 9. Data Retention

| Data Type | Hot | Warm | Cold | Archive |
|-----------|-----|------|------|---------|
| **Telemetry Raw** | 7 days | - | - | Deleted |
| **Telemetry 1min** | 90 days | - | - | Deleted |
| **Telemetry 1hour** | 5 years | - | - | S3 Glacier |
| **Audit Logs** | 90 days | 1 year | 7 years | S3 Glacier |
| **Imagery (Assets)** | 90 days | 1 year | - | S3 Glacier |
| **Session Data** | Active | - | - | Deleted on logout |
| **Exports** | 7 days | - | - | Deleted |

## 10. Backup & Recovery

### 10.1 Backup Strategy

| Component | Method | Frequency | Retention |
|-----------|--------|-----------|-----------|
| PostgreSQL | pg_dump + WAL | Continuous | 30 days |
| TimescaleDB | Native backup | Daily | 30 days |
| Redis | RDB + AOF | Hourly | 7 days |
| S3 | Cross-region replication | Continuous | Indefinite |

### 10.2 Recovery Objectives

| Metric | Target |
|--------|--------|
| **RPO** (Recovery Point Objective) | 1 hour |
| **RTO** (Recovery Time Objective) | 4 hours |

## 11. Related Documents

- [System Overview](./system-overview.md)
- [Security Architecture](./security-architecture.md)
- Module-specific data models in each module's `data-model.md`
