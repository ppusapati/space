# Satellite Module

> Spacecraft Management, Flight Dynamics & Conjunction Assessment

## Overview

The Satellite module manages spacecraft configuration, subsystem health, orbit determination, maneuver planning, and collision avoidance (conjunction assessment).

## Services

| Service | RPCs | Description |
|---------|------|-------------|
| [SpacecraftService](./api/spacecraft-service.md) | 8 | Spacecraft configuration, subsystems |
| [FlightDynamicsService](./api/flightdynamics-service.md) | 10 | Orbits, maneuvers, conjunctions |
| **Total** | **18** | |

## Key Concepts

### Spacecraft Aggregate
- Spacecraft configuration (bus, mass, dimensions)
- Subsystem catalog (ADCS, EPS, CDH, COMMS, THERMAL, PAYLOAD)
- Health status tracking
- Power budget management

### Flight Dynamics
- Orbit state vectors (position, velocity)
- Keplerian elements
- Covariance matrices
- Maneuver planning (station-keeping, collision avoidance)

### Conjunction Assessment
- CDM (Conjunction Data Message) ingestion
- Collision probability calculation
- Miss distance analysis
- CAM (Collision Avoidance Maneuver) planning

## State Machines

### Conjunction Assessment States
```
INITIAL_SCREENING → DISMISSED (Pc < 1e-7)
                  → MONITORING (Pc >= 1e-7)
                     → ELEVATED (Pc >= 1e-4)
                        → MITIGATING (TCA < 72h AND Pc >= 1e-3)
                           → MANEUVER_PLANNED
                           → ACCEPTED_RISK
                           → RESOLVED
```

## Related Documents
- [Ground Station Module](../02-groundstation/README.md)
- [Integration - Space-Track](./integrations/space-track-cdm.md)
