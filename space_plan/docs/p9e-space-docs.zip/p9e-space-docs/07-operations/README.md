# Operations

> Deployment, Monitoring & Operational Procedures

## Overview

This section covers deployment procedures, configuration management, monitoring setup, and operational runbooks for the P9E Space Platform.

## Contents

| Document | Description |
|----------|-------------|
| [Deployment](./deployment.md) | Kubernetes deployment guide |
| [Configuration](./configuration.md) | Environment configuration |
| [Monitoring](./monitoring.md) | Observability setup |
| [Troubleshooting](./troubleshooting.md) | Common issues and solutions |

## Runbooks

| Runbook | Scenario |
|---------|----------|
| [Incident Response](./runbooks/incident-response.md) | Handling production incidents |
| [Disaster Recovery](./runbooks/disaster-recovery.md) | DR procedures |
| [Scaling](./runbooks/scaling.md) | Horizontal/vertical scaling |

## Environment Tiers

| Environment | Purpose | Cluster | Data |
|-------------|---------|---------|------|
| **Development** | Local dev | Kind/K3s | Synthetic |
| **Staging** | Integration testing | 3-node | Anonymized |
| **Production** | Live operations | 5+ nodes HA | Real |
| **DR** | Disaster recovery | 3-node standby | Replicated |

## Quick Reference

### Health Endpoints

| Endpoint | Purpose | Expected |
|----------|---------|----------|
| `/healthz` | Liveness probe | `200 OK` |
| `/readyz` | Readiness probe | `200 OK` |
| `/v1/health` | Detailed health | JSON status |
| `/metrics` | Prometheus metrics | Text format |

### Key Metrics

```prometheus
# Availability
up{job="*"}

# Request rate
rate(http_requests_total[5m])

# Error rate
rate(http_requests_total{status=~"5.."}[5m])

# Latency (p95)
histogram_quantile(0.95, http_request_duration_seconds)

# Telemetry rate
rate(p9e_telemetry_frames_total[5m])
```

### Alert Severity

| Severity | Response Time | Channels |
|----------|---------------|----------|
| **Critical** | Immediate (< 15 min) | PagerDuty, Slack #critical |
| **Warning** | < 1 hour | Slack #alerts |
| **Info** | Daily review | Email digest |

## Deployment Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         KUBERNETES CLUSTER                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌───────────────────────────────────────────────────────────────────────┐ │
│  │ INGRESS (traefik)                                                     │ │
│  │  ├── api.p9e.space      → API Gateway                                │ │
│  │  ├── app.p9e.space      → Web App                                    │ │
│  │  └── grafana.p9e.space  → Monitoring                                 │ │
│  └───────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│  ┌───────────────────────────────────────────────────────────────────────┐ │
│  │ NAMESPACE: p9e-space                                                  │ │
│  │                                                                       │ │
│  │  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐    │ │
│  │  │   platform  │ │ groundstn   │ │  satellite  │ │     eo      │    │ │
│  │  │   (3 pods)  │ │  (3 pods)   │ │  (2 pods)   │ │  (3 pods)   │    │ │
│  │  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘    │ │
│  │                                                                       │ │
│  │  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐                    │ │
│  │  │   geoint    │ │   common    │ │   worker    │                    │ │
│  │  │  (2 pods)   │ │  (2 pods)   │ │  (5 pods)   │                    │ │
│  │  └─────────────┘ └─────────────┘ └─────────────┘                    │ │
│  └───────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│  ┌───────────────────────────────────────────────────────────────────────┐ │
│  │ NAMESPACE: p9e-data                                                   │ │
│  │                                                                       │ │
│  │  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐    │ │
│  │  │  postgres   │ │   redis     │ │    nats     │ │   minio     │    │ │
│  │  │ (HA 3-node) │ │ (3-node)    │ │ (3-node)    │ │ (4-node)    │    │ │
│  │  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘    │ │
│  └───────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│  ┌───────────────────────────────────────────────────────────────────────┐ │
│  │ NAMESPACE: p9e-monitoring                                             │ │
│  │                                                                       │ │
│  │  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐    │ │
│  │  │ prometheus  │ │   grafana   │ │    loki     │ │   tempo     │    │ │
│  │  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘    │ │
│  └───────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Configuration Management

### Environment Variables

```bash
# Core
P9E_ENV=production
P9E_LOG_LEVEL=info
P9E_LOG_FORMAT=json

# Database
DATABASE_URL=postgres://user:pass@host:5432/p9e?sslmode=require
REDIS_URL=redis://host:6379
NATS_URL=nats://host:4222

# Security
JWT_SECRET=${VAULT:jwt-secret}
ENCRYPTION_KEY=${VAULT:encryption-key}

# External Services
SPACETRACK_USERNAME=${VAULT:spacetrack-user}
SPACETRACK_PASSWORD=${VAULT:spacetrack-pass}
STRIPE_SECRET_KEY=${VAULT:stripe-key}
```

### Secrets Management

All secrets stored in HashiCorp Vault:

```
vault/
├── secret/data/production/
│   ├── database          # DB credentials
│   ├── redis             # Redis password
│   ├── jwt               # JWT signing key
│   ├── encryption        # Data encryption key
│   ├── spacetrack        # Space-Track credentials
│   ├── stripe            # Stripe API keys
│   └── aws               # AWS credentials
└── pki/                  # TLS certificates
```

## Scaling Guidelines

### Horizontal Pod Autoscaler

```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: platform-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: platform
  minReplicas: 3
  maxReplicas: 10
  metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: 70
    - type: Resource
      resource:
        name: memory
        target:
          type: Utilization
          averageUtilization: 80
```

### Scaling Triggers

| Service | Scale Up When | Scale Down When |
|---------|--------------|-----------------|
| Platform | CPU > 70% or p95 > 200ms | CPU < 30% for 10 min |
| Ground Station | Active passes > 5 | Active passes < 2 |
| EO Processing | Queue depth > 100 | Queue empty for 5 min |
| Workers | Queue depth > 50 | Queue empty for 5 min |

## Backup & Recovery

### Backup Schedule

| Component | Method | Frequency | Retention |
|-----------|--------|-----------|-----------|
| PostgreSQL | pg_dump + WAL | Continuous | 30 days |
| TimescaleDB | Native | Daily | 30 days |
| Redis | RDB + AOF | Hourly | 7 days |
| S3/MinIO | Cross-region | Continuous | Indefinite |
| Vault | Snapshot | Daily | 30 days |

### Recovery Procedures

See [Disaster Recovery Runbook](./runbooks/disaster-recovery.md)

| Scenario | RTO | RPO |
|----------|-----|-----|
| Single pod failure | Immediate | 0 |
| Single node failure | < 5 min | 0 |
| Zone failure | < 15 min | < 1 min |
| Region failure | < 4 hours | < 1 hour |
| Database corruption | < 4 hours | < 1 hour |

## Maintenance Windows

| Activity | Window | Duration | Frequency |
|----------|--------|----------|-----------|
| Minor updates | Rolling | 0 downtime | Weekly |
| Major upgrades | 02:00-06:00 UTC | < 30 min | Monthly |
| Database maintenance | 02:00-04:00 UTC | < 1 hour | Weekly |
| DR testing | 10:00-14:00 UTC | 4 hours | Quarterly |

## Related Documents

- [Observability](../00-architecture/observability.md)
- [Security Architecture](../00-architecture/security-architecture.md)
- [Integration Patterns](../00-architecture/integration-patterns.md)
