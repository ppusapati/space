# GEOINT Module

> Geospatial Intelligence - AOI Monitoring, Analysis & Reporting

## Overview

The GEOINT (Geospatial Intelligence) module provides capabilities for area-of-interest monitoring, pattern analysis, change detection, observation management, and intelligence report generation.

## Services

| Service | RPCs | Description |
|---------|------|-------------|
| [AOIService](./api/aoi-service.md) | 8 | Area of Interest management |
| [AnalysisService](./api/analysis-service.md) | 7 | Pattern and change detection |
| [ReportService](./api/report-service.md) | 8 | Intelligence report generation |
| [WorkspaceService](./api/workspace-service.md) | 9 | Collaborative workspaces |
| **Total** | **32** | |

## Key Concepts

### Workspaces
- Collaborative project spaces
- Member management (Viewer, Editor, Admin)
- Shared AOIs and reports
- Layer configuration

### Areas of Interest (AOIs)
- Geographic regions for monitoring
- Priority levels (LOW, MEDIUM, HIGH, CRITICAL)
- Classification levels
- Automated monitoring configuration
- Alert rules

### Observations
- Point/polygon annotations
- Types: Vehicle, Vessel, Aircraft, Structure, Activity, Change
- Sources: ML_AUTO, HUMAN, VALIDATED
- Confidence scores

### Analysis
- Temporal pattern detection
- Change detection (SAR coherence, optical differencing)
- Object tracking across time

### Reports
- Types: SPOT, SITREP, CHANGE, ASSESSMENT
- Markdown body with embedded observations
- PDF generation
- Classification handling

## Workspace Aggregate
```
WorkspaceAggregate
├── Workspace (root)
├── Members[] (user access)
├── AOIs[] (monitored areas)
└── Reports[] (generated reports)
```

## Related Documents
- [EO Module](../04-eo/README.md)
- [Security Architecture](../00-architecture/security-architecture.md)
