# Platform Module - Data Model

## Overview

The Platform module uses PostgreSQL with Row-Level Security (RLS) for multi-tenant data isolation.

## Schema: `platform`

### Entity Relationship Diagram

```
┌───────────────┐       ┌───────────────┐       ┌───────────────┐
│    tenants    │       │     users     │       │    sessions   │
├───────────────┤       ├───────────────┤       ├───────────────┤
│ id (PK)       │◄──────│ tenant_id (FK)│       │ id (PK)       │
│ name          │       │ id (PK)       │◄──────│ user_id (FK)  │
│ slug (UNIQUE) │       │ email         │       │ tenant_id (FK)│
│ status        │       │ password_hash │       │ refresh_token │
│ tier          │       │ first_name    │       │ ip_address    │
│ settings      │       │ last_name     │       │ user_agent    │
│ quotas        │       │ status        │       │ expires_at    │
│ created_at    │       │ mfa_enabled   │       │ created_at    │
└───────────────┘       │ created_at    │       └───────────────┘
                        └───────────────┘
                               │
                               │ user_roles
                               ▼
┌───────────────┐       ┌───────────────┐       ┌───────────────┐
│     roles     │◄──────│  user_roles   │       │  audit_logs   │
├───────────────┤       ├───────────────┤       ├───────────────┤
│ id (PK)       │       │ user_id (FK)  │       │ id (PK)       │
│ tenant_id (FK)│       │ role_id (FK)  │       │ tenant_id     │
│ name          │       │ assigned_at   │       │ user_id       │
│ description   │       │ assigned_by   │       │ action        │
│ permissions[] │       └───────────────┘       │ resource_type │
│ is_system     │                               │ resource_id   │
│ created_at    │                               │ outcome       │
└───────────────┘                               │ details       │
                                                │ signature     │
                                                │ timestamp     │
                                                └───────────────┘
```

## Tables

### tenants

Multi-tenant organizations.

```sql
CREATE TABLE platform.tenants (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name            VARCHAR(255) NOT NULL,
    slug            VARCHAR(100) NOT NULL UNIQUE,
    status          tenant_status NOT NULL DEFAULT 'pending',
    tier            subscription_tier NOT NULL DEFAULT 'free',
    settings        JSONB NOT NULL DEFAULT '{}',
    quotas          JSONB NOT NULL DEFAULT '{}',
    stripe_customer_id VARCHAR(100),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    CONSTRAINT valid_slug CHECK (slug ~ '^[a-z0-9-]+$')
);

CREATE INDEX idx_tenants_slug ON platform.tenants(slug);
CREATE INDEX idx_tenants_status ON platform.tenants(status);
```

| Column | Type | Description |
|--------|------|-------------|
| `id` | UUID | Primary key |
| `name` | VARCHAR(255) | Display name |
| `slug` | VARCHAR(100) | URL-safe identifier (unique) |
| `status` | tenant_status | pending, active, suspended, deleted |
| `tier` | subscription_tier | free, starter, professional, enterprise |
| `settings` | JSONB | Tenant-specific configuration |
| `quotas` | JSONB | Resource quotas (users, satellites, storage) |

### users

User accounts.

```sql
CREATE TABLE platform.users (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES platform.tenants(id),
    email           VARCHAR(255) NOT NULL,
    password_hash   VARCHAR(255),  -- NULL for SSO users
    first_name      VARCHAR(100),
    last_name       VARCHAR(100),
    status          user_status NOT NULL DEFAULT 'active',
    mfa_enabled     BOOLEAN NOT NULL DEFAULT FALSE,
    mfa_secret      VARCHAR(255),  -- Encrypted TOTP secret
    mfa_backup_codes TEXT[],       -- Encrypted backup codes
    idp_subject     VARCHAR(255),  -- External IdP subject
    last_login_at   TIMESTAMPTZ,
    password_changed_at TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    CONSTRAINT unique_email_per_tenant UNIQUE (tenant_id, email)
);

CREATE INDEX idx_users_email ON platform.users(email);
CREATE INDEX idx_users_tenant ON platform.users(tenant_id);
CREATE INDEX idx_users_idp ON platform.users(idp_subject) WHERE idp_subject IS NOT NULL;

-- Row-Level Security
ALTER TABLE platform.users ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON platform.users
    USING (tenant_id = current_setting('app.tenant_id')::uuid);
```

| Column | Type | Description |
|--------|------|-------------|
| `id` | UUID | Primary key |
| `tenant_id` | UUID | Foreign key to tenants |
| `email` | VARCHAR(255) | Email address (unique per tenant) |
| `password_hash` | VARCHAR(255) | Argon2id hash (NULL for SSO) |
| `status` | user_status | pending, active, locked, disabled |
| `mfa_enabled` | BOOLEAN | Whether MFA is enabled |
| `idp_subject` | VARCHAR(255) | External IdP subject ID |

### roles

Permission groups.

```sql
CREATE TABLE platform.roles (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID REFERENCES platform.tenants(id),  -- NULL = system role
    name            VARCHAR(100) NOT NULL,
    description     TEXT,
    permissions     TEXT[] NOT NULL DEFAULT '{}',
    is_system       BOOLEAN NOT NULL DEFAULT FALSE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    CONSTRAINT unique_role_name UNIQUE (tenant_id, name)
);

-- System roles (tenant_id = NULL)
INSERT INTO platform.roles (id, name, permissions, is_system) VALUES
    ('00000000-0000-0000-0000-000000000001', 'system_admin', ARRAY['*'], true),
    ('00000000-0000-0000-0000-000000000002', 'tenant_admin', ARRAY['tenant.*', 'users.*'], true),
    ('00000000-0000-0000-0000-000000000003', 'operator', ARRAY['passes.*', 'telemetry.*', 'commands.*'], true),
    ('00000000-0000-0000-0000-000000000004', 'analyst', ARRAY['catalog.read', 'processing.*', 'geoint.*'], true),
    ('00000000-0000-0000-0000-000000000005', 'viewer', ARRAY['*.read'], true);
```

### user_roles

User-role assignments.

```sql
CREATE TABLE platform.user_roles (
    user_id         UUID NOT NULL REFERENCES platform.users(id) ON DELETE CASCADE,
    role_id         UUID NOT NULL REFERENCES platform.roles(id) ON DELETE CASCADE,
    assigned_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    assigned_by     UUID REFERENCES platform.users(id),
    
    PRIMARY KEY (user_id, role_id)
);
```

### sessions

Active user sessions.

```sql
CREATE TABLE platform.sessions (
    id              VARCHAR(64) PRIMARY KEY,
    user_id         UUID NOT NULL REFERENCES platform.users(id) ON DELETE CASCADE,
    tenant_id       UUID NOT NULL REFERENCES platform.tenants(id),
    refresh_token   VARCHAR(64) NOT NULL UNIQUE,
    ip_address      INET,
    user_agent      TEXT,
    device_id       VARCHAR(64),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at      TIMESTAMPTZ NOT NULL,
    last_active_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_sessions_user ON platform.sessions(user_id);
CREATE INDEX idx_sessions_expires ON platform.sessions(expires_at);
CREATE INDEX idx_sessions_refresh ON platform.sessions(refresh_token);
```

### audit_logs

Immutable audit trail with hash chain.

```sql
CREATE TABLE platform.audit_logs (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL,
    user_id         UUID,
    session_id      VARCHAR(64),
    action          VARCHAR(100) NOT NULL,
    resource_type   VARCHAR(100),
    resource_id     UUID,
    outcome         audit_outcome NOT NULL,  -- success, failure, denied
    details         JSONB,
    ip_address      INET,
    user_agent      TEXT,
    timestamp       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    signature       VARCHAR(64) NOT NULL  -- SHA-256 hash chain
);

CREATE INDEX idx_audit_tenant_time ON platform.audit_logs(tenant_id, timestamp DESC);
CREATE INDEX idx_audit_user ON platform.audit_logs(user_id, timestamp DESC);
CREATE INDEX idx_audit_resource ON platform.audit_logs(resource_type, resource_id);
CREATE INDEX idx_audit_action ON platform.audit_logs(action, timestamp DESC);

-- Row-Level Security
ALTER TABLE platform.audit_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON platform.audit_logs
    USING (tenant_id = current_setting('app.tenant_id')::uuid);
```

### api_keys

API key management.

```sql
CREATE TABLE platform.api_keys (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES platform.tenants(id),
    user_id         UUID NOT NULL REFERENCES platform.users(id),
    name            VARCHAR(100) NOT NULL,
    key_hash        VARCHAR(64) NOT NULL,  -- SHA-256 of key
    key_prefix      VARCHAR(8) NOT NULL,   -- First 8 chars for identification
    permissions     TEXT[] NOT NULL DEFAULT '{}',
    expires_at      TIMESTAMPTZ,
    last_used_at    TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    revoked_at      TIMESTAMPTZ,
    
    CONSTRAINT unique_key_name UNIQUE (user_id, name)
);

CREATE INDEX idx_api_keys_hash ON platform.api_keys(key_hash);
CREATE INDEX idx_api_keys_prefix ON platform.api_keys(key_prefix);
```

## Enums

```sql
CREATE TYPE tenant_status AS ENUM ('pending', 'active', 'suspended', 'deleted');
CREATE TYPE subscription_tier AS ENUM ('free', 'starter', 'professional', 'enterprise');
CREATE TYPE user_status AS ENUM ('pending', 'active', 'locked', 'disabled');
CREATE TYPE audit_outcome AS ENUM ('success', 'failure', 'denied');
CREATE TYPE mfa_method AS ENUM ('totp', 'webauthn', 'sms');
```

## Row-Level Security

All tenant-scoped tables use RLS:

```sql
-- Enable RLS
ALTER TABLE platform.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE platform.audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE platform.api_keys ENABLE ROW LEVEL SECURITY;

-- Application sets tenant context on each request
SET app.tenant_id = 'tenant-uuid';

-- All queries automatically filtered
SELECT * FROM platform.users;  -- Only returns current tenant's users
```

## Indexes Summary

| Table | Index | Columns | Purpose |
|-------|-------|---------|---------|
| tenants | idx_tenants_slug | slug | Lookup by slug |
| users | idx_users_email | email | Login lookup |
| users | idx_users_tenant | tenant_id | Tenant filtering |
| sessions | idx_sessions_refresh | refresh_token | Token validation |
| audit_logs | idx_audit_tenant_time | tenant_id, timestamp | Audit queries |
| api_keys | idx_api_keys_hash | key_hash | Key validation |
