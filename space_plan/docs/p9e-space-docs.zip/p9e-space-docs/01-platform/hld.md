# Platform Module - High-Level Design

## 1. Module Overview

The Platform module is the foundational layer providing identity, access control, multi-tenancy, and audit capabilities for the entire P9E Space Platform.

## 2. Design Goals

| Goal | Description |
|------|-------------|
| **Multi-Tenancy** | Complete data isolation between organizations |
| **Security** | Defense-in-depth authentication and authorization |
| **Compliance** | SOC 2, ISO 27001 audit requirements |
| **Scalability** | Support 1000+ tenants, 100K+ users |
| **Extensibility** | Plugin external IdPs, notification channels |

## 3. Component Design

### 3.1 Identity Component

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  IDENTITY COMPONENT                                                        │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌──────────────────────┐       ┌──────────────────────┐                   │
│  │   IdentityService    │       │   «interface»        │                   │
│  │   (Application)      │       │   UserRepository     │                   │
│  ├──────────────────────┤       ├──────────────────────┤                   │
│  │ - userRepo           │──────►│ + FindByID()         │                   │
│  │ - sessionStore       │       │ + FindByEmail()      │                   │
│  │ - tokenGenerator     │       │ + Create()           │                   │
│  │ - passwordHasher     │       │ + Update()           │                   │
│  │ - mfaProvider        │       └──────────────────────┘                   │
│  ├──────────────────────┤                                                  │
│  │ + Login()            │       ┌──────────────────────┐                   │
│  │ + Logout()           │       │   «interface»        │                   │
│  │ + RefreshToken()     │       │   SessionStore       │                   │
│  │ + EnrollMFA()        │──────►├──────────────────────┤                   │
│  │ + VerifyMFA()        │       │ + Create()           │                   │
│  │ + ResetPassword()    │       │ + Get()              │                   │
│  └──────────────────────┘       │ + Delete()           │                   │
│                                 │ + Extend()           │                   │
│                                 └──────────────────────┘                   │
│                                           ▲                                │
│                                           │ implements                     │
│                                 ┌──────────────────────┐                   │
│                                 │   RedisSessionStore  │                   │
│                                 └──────────────────────┘                   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 3.2 Tenant Component

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  TENANT COMPONENT                                                          │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌──────────────────────┐       ┌──────────────────────┐                   │
│  │   Tenant (Entity)    │       │   TenantSlug (VO)    │                   │
│  ├──────────────────────┤       ├──────────────────────┤                   │
│  │ - ID: UUID           │       │ - value: string      │                   │
│  │ - Name: string       │◄──────├──────────────────────┤                   │
│  │ - Slug: TenantSlug   │       │ + Validate() error   │                   │
│  │ - Status: TenantStat │       │ + String() string    │                   │
│  │ - Tier: SubTier      │       └──────────────────────┘                   │
│  │ - Settings: Settings │                                                  │
│  │ - Quotas: Quotas     │       ┌──────────────────────┐                   │
│  ├──────────────────────┤       │   TenantService      │                   │
│  │ + Activate()         │◄──────├──────────────────────┤                   │
│  │ + Suspend()          │       │ - tenantRepo         │                   │
│  │ + UpdateTier(tier)   │       │ - quotaService       │                   │
│  └──────────────────────┘       │ - eventPublisher     │                   │
│                                 ├──────────────────────┤                   │
│                                 │ + CreateTenant()     │                   │
│                                 │ + GetTenant()        │                   │
│                                 │ + UpdateSettings()   │                   │
│                                 │ + CheckQuota()       │                   │
│                                 └──────────────────────┘                   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 4. Data Flow

### 4.1 Login Sequence

```
┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐
│  Client  │  │  Gateway │  │ Identity │  │  Redis   │  │ Postgres │
└────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘
     │             │             │             │             │
     │ POST /login │             │             │             │
     │────────────►│             │             │             │
     │             │ Login()     │             │             │
     │             │────────────►│             │             │
     │             │             │ FindByEmail()            │
     │             │             │────────────────────────────►
     │             │             │ User                     │
     │             │             │◄────────────────────────────
     │             │             │             │             │
     │             │             │ Verify password          │
     │             │             │──┐          │             │
     │             │             │◄─┘          │             │
     │             │             │             │             │
     │             │             │ Create session           │
     │             │             │────────────►│             │
     │             │             │ OK          │             │
     │             │             │◄────────────│             │
     │             │             │             │             │
     │             │ TokenPair   │             │             │
     │◄────────────│◄────────────│             │             │
     │             │             │             │             │
```

### 4.2 Authorization Flow

```
┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐
│  Client  │  │  Gateway │  │ AuthZ MW │  │  Redis   │  │ Postgres │
└────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘
     │             │             │             │             │
     │ GET /api/... │            │             │             │
     │ + Bearer JWT│             │             │             │
     │────────────►│             │             │             │
     │             │ Validate JWT│             │             │
     │             │────────────►│             │             │
     │             │             │ Verify sig  │             │
     │             │             │──┐          │             │
     │             │             │◄─┘          │             │
     │             │             │             │             │
     │             │             │ Check session             │
     │             │             │────────────►│             │
     │             │             │ Session     │             │
     │             │             │◄────────────│             │
     │             │             │             │             │
     │             │             │ SET app.tenant_id        │
     │             │             │────────────────────────────►
     │             │             │             │             │
     │             │             │ Check RBAC  │             │
     │             │             │──┐          │             │
     │             │ Allowed     │◄─┘          │             │
     │             │◄────────────│             │             │
     │             │             │             │             │
     │             │ Continue to handler       │             │
     │             │────────────────────────────────────────►
     │             │             │             │             │
```

## 5. Security Design

### 5.1 Authentication Mechanisms

| Mechanism | Implementation |
|-----------|----------------|
| Password | Argon2id (memory=64MB, iterations=3, parallelism=4) |
| MFA - TOTP | RFC 6238, 30-second window, SHA-1 |
| MFA - WebAuthn | FIDO2, resident keys supported |
| Session | Redis with encrypted payload |
| JWT | RS256, 15-minute expiry |
| Refresh Token | Opaque, 7-day expiry, single-use with rotation |

### 5.2 Authorization Layers

```
Layer 1: IAM
├── User exists and is active
├── Session is valid (not expired, not revoked)
├── Tenant membership verified
└── MFA completed (if required)

Layer 2: RBAC
├── User has required role
├── Role grants permission for action
└── Module-level access control

Layer 3: Policy Engine
├── Resource ownership
├── Time-based restrictions
├── Classification levels
└── Custom business rules
```

## 6. Multi-Tenancy Design

### 6.1 Isolation Strategy

| Strategy | Approach |
|----------|----------|
| **Data** | Row-Level Security (RLS) on all tables |
| **Schema** | Shared schema with `tenant_id` column |
| **Compute** | Shared services with tenant context |
| **Storage** | Shared buckets with tenant prefix |

### 6.2 RLS Implementation

```sql
-- Enable RLS
ALTER TABLE platform.users ENABLE ROW LEVEL SECURITY;

-- Tenant isolation policy
CREATE POLICY tenant_isolation ON platform.users
    USING (tenant_id = current_setting('app.tenant_id')::uuid);

-- Application sets context
SET app.tenant_id = 'tenant-uuid';
SELECT * FROM users; -- Only returns tenant's users
```

## 7. Audit Design

### 7.1 Audit Log Structure

```json
{
  "id": "uuid",
  "tenant_id": "uuid",
  "user_id": "uuid",
  "session_id": "string",
  "action": "user.login",
  "resource_type": "User",
  "resource_id": "uuid",
  "outcome": "success",
  "details": {
    "ip_address": "203.0.113.45",
    "user_agent": "Mozilla/5.0...",
    "mfa_used": true
  },
  "timestamp": "2025-12-27T10:30:00Z",
  "signature": "sha256:abc123..."
}
```

### 7.2 Hash Chain Integrity

```go
func (s *AuditService) Log(ctx context.Context, entry AuditEntry) error {
    // Get previous signature
    prevSig, _ := s.repo.GetLastSignature(ctx, entry.TenantID)
    
    log := &entity.AuditLog{
        ID:        uuid.New(),
        Timestamp: time.Now(),
        // ... copy fields
    }
    
    // Create hash chain signature
    data := prevSig + log.String()
    log.Signature = sha256.Sum256([]byte(data))
    
    return s.repo.Append(ctx, log)
}
```

## 8. Scalability Considerations

| Component | Scaling Strategy |
|-----------|------------------|
| Identity Service | Horizontal (stateless) |
| Session Store | Redis Cluster |
| User Database | Read replicas |
| Audit Logs | TimescaleDB partitioning |
| Token Validation | JWT (no DB lookup) |

## 9. Related Documents

- [API - Identity Service](./api/identity-service.md)
- [API - Tenant Service](./api/tenant-service.md)
- [Data Model](./data-model.md)
- [Security Architecture](../00-architecture/security-architecture.md)
