# Identity Service API

> Package: `platform.v1`

## Overview

The Identity Service handles authentication, session management, MFA enrollment, and password management.

## Service Definition

```protobuf
service IdentityService {
  // Authentication
  rpc Login(LoginRequest) returns (LoginResponse);
  rpc RefreshToken(RefreshTokenRequest) returns (TokenPair);
  rpc Logout(LogoutRequest) returns (google.protobuf.Empty);
  
  // Password Management
  rpc RequestPasswordReset(RequestPasswordResetRequest) returns (google.protobuf.Empty);
  rpc ResetPassword(ResetPasswordRequest) returns (google.protobuf.Empty);
  rpc ChangePassword(ChangePasswordRequest) returns (google.protobuf.Empty);
  
  // MFA
  rpc EnrollMFA(EnrollMFARequest) returns (EnrollMFAResponse);
  rpc VerifyMFA(VerifyMFARequest) returns (TokenPair);
  rpc DisableMFA(DisableMFARequest) returns (google.protobuf.Empty);
  
  // Session Management
  rpc GetCurrentUser(google.protobuf.Empty) returns (User);
  rpc ListSessions(ListSessionsRequest) returns (ListSessionsResponse);
  rpc RevokeSession(RevokeSessionRequest) returns (google.protobuf.Empty);
}
```

## RPCs

### Login

Authenticates a user with email and password.

**Request:**
```protobuf
message LoginRequest {
  string email = 1 [(validate.rules).string.email = true];
  string password = 2 [(validate.rules).string.min_len = 8];
  string device_id = 3;  // Optional device fingerprint
}
```

**Response:**
```protobuf
message LoginResponse {
  oneof result {
    TokenPair tokens = 1;        // Success - no MFA required
    MFAChallenge mfa_challenge = 2;  // MFA required
  }
}

message TokenPair {
  string access_token = 1;   // JWT, 15 min expiry
  string refresh_token = 2;  // Opaque, 7 day expiry
  int32 expires_in = 3;      // Seconds until access_token expires
  string token_type = 4;     // "Bearer"
}

message MFAChallenge {
  string session_id = 1;     // Temporary session for MFA flow
  MFAMethod method = 2;      // TOTP, WEBAUTHN
}
```

**HTTP Mapping:**
```
POST /v1/auth/login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "secretpassword"
}
```

**Errors:**
| Code | Description |
|------|-------------|
| `INVALID_ARGUMENT` | Invalid email format or password too short |
| `UNAUTHENTICATED` | Invalid credentials |
| `FAILED_PRECONDITION` | User account locked or inactive |

---

### RefreshToken

Exchanges a refresh token for a new token pair.

**Request:**
```protobuf
message RefreshTokenRequest {
  string refresh_token = 1 [(validate.rules).string.min_len = 1];
}
```

**Response:** `TokenPair`

**HTTP Mapping:**
```
POST /v1/auth/refresh
Content-Type: application/json

{
  "refresh_token": "opaque-refresh-token"
}
```

**Behavior:**
- Refresh token is single-use (rotation)
- New refresh token returned with each refresh
- Old refresh token invalidated

**Errors:**
| Code | Description |
|------|-------------|
| `UNAUTHENTICATED` | Invalid or expired refresh token |
| `FAILED_PRECONDITION` | Session revoked |

---

### Logout

Invalidates the current session and refresh token.

**Request:**
```protobuf
message LogoutRequest {
  bool all_sessions = 1;  // Logout from all devices
}
```

**HTTP Mapping:**
```
POST /v1/auth/logout
Authorization: Bearer <access_token>

{
  "all_sessions": false
}
```

---

### EnrollMFA

Initiates MFA enrollment for the current user.

**Request:**
```protobuf
message EnrollMFARequest {
  MFAMethod method = 1;  // TOTP or WEBAUTHN
}
```

**Response:**
```protobuf
message EnrollMFAResponse {
  string secret = 1;           // TOTP secret (base32)
  string qr_code_uri = 2;      // otpauth:// URI for QR code
  repeated string backup_codes = 3;  // 10 backup codes
}
```

**HTTP Mapping:**
```
POST /v1/auth/mfa/enroll
Authorization: Bearer <access_token>

{
  "method": "MFA_METHOD_TOTP"
}
```

---

### VerifyMFA

Completes MFA challenge during login.

**Request:**
```protobuf
message VerifyMFARequest {
  string session_id = 1;  // From MFAChallenge
  string code = 2;        // 6-digit TOTP code
}
```

**Response:** `TokenPair`

**HTTP Mapping:**
```
POST /v1/auth/mfa/verify

{
  "session_id": "temp-session-id",
  "code": "123456"
}
```

**Errors:**
| Code | Description |
|------|-------------|
| `UNAUTHENTICATED` | Invalid or expired code |
| `RESOURCE_EXHAUSTED` | Too many failed attempts |

---

### RequestPasswordReset

Initiates password reset flow.

**Request:**
```protobuf
message RequestPasswordResetRequest {
  string email = 1 [(validate.rules).string.email = true];
}
```

**HTTP Mapping:**
```
POST /v1/auth/password/reset-request

{
  "email": "user@example.com"
}
```

**Behavior:**
- Always returns success (prevents email enumeration)
- Sends reset link via email
- Reset token valid for 1 hour

---

### ResetPassword

Completes password reset with token.

**Request:**
```protobuf
message ResetPasswordRequest {
  string token = 1;        // From email link
  string new_password = 2 [(validate.rules).string.min_len = 12];
}
```

**HTTP Mapping:**
```
POST /v1/auth/password/reset

{
  "token": "reset-token-from-email",
  "new_password": "newSecurePassword123!"
}
```

**Password Requirements:**
- Minimum 12 characters
- At least 1 uppercase letter
- At least 1 lowercase letter
- At least 1 number
- At least 1 special character
- Not in common password list
- Not similar to email

---

### ChangePassword

Changes password for authenticated user.

**Request:**
```protobuf
message ChangePasswordRequest {
  string current_password = 1;
  string new_password = 2 [(validate.rules).string.min_len = 12];
}
```

**HTTP Mapping:**
```
POST /v1/auth/password/change
Authorization: Bearer <access_token>

{
  "current_password": "currentPassword",
  "new_password": "newSecurePassword123!"
}
```

---

### GetCurrentUser

Returns the authenticated user's profile.

**HTTP Mapping:**
```
GET /v1/auth/me
Authorization: Bearer <access_token>
```

**Response:** `User` (see User Service)

---

### ListSessions

Lists all active sessions for the current user.

**Request:**
```protobuf
message ListSessionsRequest {
  common.v1.PageRequest pagination = 1;
}
```

**Response:**
```protobuf
message ListSessionsResponse {
  repeated Session sessions = 1;
  common.v1.PageInfo page_info = 2;
}

message Session {
  string id = 1;
  string device_id = 2;
  string ip_address = 3;
  string user_agent = 4;
  google.protobuf.Timestamp created_at = 5;
  google.protobuf.Timestamp last_active_at = 6;
  bool is_current = 7;
}
```

**HTTP Mapping:**
```
GET /v1/auth/sessions
Authorization: Bearer <access_token>
```

---

### RevokeSession

Revokes a specific session.

**Request:**
```protobuf
message RevokeSessionRequest {
  string session_id = 1 [(validate.rules).string.min_len = 1];
}
```

**HTTP Mapping:**
```
DELETE /v1/auth/sessions/{session_id}
Authorization: Bearer <access_token>
```

## Authentication

- `Login`, `RefreshToken`, `RequestPasswordReset`, `ResetPassword`, `VerifyMFA` - No authentication required
- All other endpoints require valid Bearer token

## Rate Limiting

| Endpoint | Limit |
|----------|-------|
| `Login` | 10 requests/minute per IP |
| `VerifyMFA` | 5 requests/minute per session |
| `RequestPasswordReset` | 3 requests/hour per email |
| Others | Standard API limits |

## Related

- [Tenant Service](./tenant-service.md)
- [User Service](./user-service.md)
- [Security Architecture](../../00-architecture/security-architecture.md)
