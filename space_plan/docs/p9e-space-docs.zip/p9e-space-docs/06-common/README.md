# Common Module

> Shared Services, Types & Patterns

## Overview

The Common module provides shared services and utilities used across all other modules, including data export, dashboards, scheduling, and health checks.

## Services

| Service | RPCs | Description |
|---------|------|-------------|
| [ExportService](./api/export-service.md) | 5 | Large data export to S3 |
| [DashboardService](./api/dashboard-service.md) | 7 | Custom dashboard management |
| [SchedulerService](./api/scheduler-service.md) | 9 | Cron job management |
| [HealthService](./api/health-service.md) | 4 | Service health checks |
| **Total** | **25** | |

## Common Types

### Identifiers

```protobuf
// Universally unique identifier
message UUID {
  string value = 1 [(validate.rules).string.uuid = true];
}
```

### Pagination

```protobuf
message PageRequest {
  int32 page_size = 1 [(validate.rules).int32 = {gte: 1, lte: 100}];
  string page_token = 2;  // Opaque cursor
}

message PageInfo {
  string next_page_token = 1;
  int32 total_count = 2;
  bool has_more = 3;
}
```

### Time Ranges

```protobuf
message TimeRange {
  google.protobuf.Timestamp start = 1;
  google.protobuf.Timestamp end = 2;
}

message DateRange {
  google.type.Date start = 1;
  google.type.Date end = 2;
}
```

### Geometry

```protobuf
message BoundingBox {
  double min_lon = 1 [(validate.rules).double = {gte: -180, lte: 180}];
  double min_lat = 2 [(validate.rules).double = {gte: -90, lte: 90}];
  double max_lon = 3 [(validate.rules).double = {gte: -180, lte: 180}];
  double max_lat = 4 [(validate.rules).double = {gte: -90, lte: 90}];
}

message Point {
  double longitude = 1;
  double latitude = 2;
  double altitude = 3;  // Optional, meters
}

message GeoJSON {
  string type = 1;      // "Point", "Polygon", etc.
  bytes coordinates = 2; // JSON-encoded coordinates
}
```

### Errors

```protobuf
message ErrorDetail {
  string code = 1;           // Machine-readable code
  string message = 2;        // Human-readable message
  string field = 3;          // Field that caused error
  map<string, string> metadata = 4;
}

message ValidationError {
  repeated FieldError field_errors = 1;
}

message FieldError {
  string field = 1;
  string code = 2;      // "required", "invalid_format", "out_of_range"
  string message = 3;
  string constraint = 4;
}
```

### Sorting & Filtering

```protobuf
message SortOrder {
  string field = 1;
  Direction direction = 2;
  
  enum Direction {
    DIRECTION_UNSPECIFIED = 0;
    DIRECTION_ASC = 1;
    DIRECTION_DESC = 2;
  }
}
```

## Patterns

### Error Handling

See [Error Handling Pattern](./patterns/error-handling.md)

```go
// Domain error interface
type Error interface {
    error
    Code() string
    Message() string
    HTTPStatus() int
    GRPCCode() codes.Code
    WithDetails(details map[string]string) Error
}

// Standard errors
var (
    ErrNotFound         = NewError("NOT_FOUND", "Resource not found", 404)
    ErrAlreadyExists    = NewError("ALREADY_EXISTS", "Resource already exists", 409)
    ErrInvalidArgument  = NewError("INVALID_ARGUMENT", "Invalid argument", 400)
    ErrPermissionDenied = NewError("PERMISSION_DENIED", "Permission denied", 403)
    ErrUnauthenticated  = NewError("UNAUTHENTICATED", "Not authenticated", 401)
)
```

### Resilience

See [Resilience Pattern](./patterns/resilience.md)

- **Circuit Breaker**: 5 failures → open, 30s timeout, 3 half-open calls
- **Retry**: 3 attempts, exponential backoff (100ms → 10s), 30% jitter
- **Timeout**: Configurable per operation
- **Bulkhead**: Semaphore-based concurrency limiting

### Pagination

See [Pagination Pattern](./patterns/pagination.md)

```go
// Cursor-based pagination
func (r *Repository) List(ctx context.Context, pageSize int, cursor string) (items []Item, nextCursor string, err error) {
    // Decode cursor
    var lastID uuid.UUID
    if cursor != "" {
        lastID, _ = decodeCursor(cursor)
    }
    
    // Query with cursor
    query := `SELECT * FROM items WHERE id > $1 ORDER BY id LIMIT $2`
    rows, _ := r.db.Query(ctx, query, lastID, pageSize+1)
    
    // Check for more
    if len(items) > pageSize {
        items = items[:pageSize]
        nextCursor = encodeCursor(items[len(items)-1].ID)
    }
    
    return items, nextCursor, nil
}
```

### Streaming

See [Streaming Pattern](./patterns/streaming.md)

| Protocol | Use Case | Implementation |
|----------|----------|----------------|
| **gRPC Streaming** | Server-to-server | Bidirectional streams |
| **WebSocket** | Browser real-time | Gorilla WebSocket |
| **SSE** | Browser one-way | Server-Sent Events |

## Export Service

### Asynchronous Export Flow

```
1. Client calls CreateExport(query, format)
2. Server returns Export with status=PENDING

3. Background worker:
   ├── Executes query in batches
   ├── Writes to S3 (streaming)
   └── Updates status=COMPLETED

4. Client polls GetExport() or subscribes to webhook
5. Client downloads from presigned URL
```

### Supported Formats

| Format | Extension | Use Case |
|--------|-----------|----------|
| CSV | `.csv` | Spreadsheet import |
| JSON | `.json` | API integration |
| Parquet | `.parquet` | Big data / analytics |
| GeoJSON | `.geojson` | GIS tools |

## Dashboard Service

### Dashboard Structure

```json
{
  "id": "uuid",
  "name": "Operations Dashboard",
  "layout": {
    "type": "grid",
    "columns": 12,
    "rows": "auto"
  },
  "widgets": [
    {
      "id": "w1",
      "type": "metric",
      "title": "Active Passes",
      "query": "p9e_passes_active",
      "position": {"x": 0, "y": 0, "w": 3, "h": 2}
    },
    {
      "id": "w2",
      "type": "timeseries",
      "title": "Telemetry Rate",
      "query": "rate(p9e_telemetry_frames_total[5m])",
      "position": {"x": 3, "y": 0, "w": 6, "h": 3}
    }
  ]
}
```

## Scheduler Service

### Cron Expression Support

```
┌───────────── minute (0 - 59)
│ ┌───────────── hour (0 - 23)
│ │ ┌───────────── day of month (1 - 31)
│ │ │ ┌───────────── month (1 - 12)
│ │ │ │ ┌───────────── day of week (0 - 6)
│ │ │ │ │
* * * * *

Examples:
- "0 */6 * * *"   → Every 6 hours
- "0 0 * * *"     → Daily at midnight
- "*/5 * * * *"   → Every 5 minutes
```

### Built-in Jobs

| Job | Schedule | Description |
|-----|----------|-------------|
| `tle_refresh` | `0 */6 * * *` | Refresh TLEs from Space-Track |
| `pass_prediction` | `0 0 * * *` | Predict passes for next 7 days |
| `telemetry_rollup` | `*/15 * * * *` | Aggregate telemetry |
| `export_cleanup` | `0 3 * * *` | Delete expired exports |
| `session_cleanup` | `*/10 * * * *` | Remove expired sessions |

## Health Service

### Health Check Levels

| Endpoint | Purpose | Checks |
|----------|---------|--------|
| `/healthz` | Liveness | Process running |
| `/readyz` | Readiness | DB, Redis, NATS connected |
| `/v1/health` | Detailed | All dependencies with status |

### Health Response

```json
{
  "status": "healthy",
  "version": "1.0.0",
  "uptime_seconds": 86400,
  "checks": {
    "database": {"status": "healthy", "latency_ms": 2},
    "redis": {"status": "healthy", "latency_ms": 1},
    "nats": {"status": "healthy", "latency_ms": 1},
    "space_track": {"status": "degraded", "message": "Rate limited"}
  }
}
```

## Related Documents

- [Integration Patterns](../00-architecture/integration-patterns.md)
- [Observability](../00-architecture/observability.md)
